# KisanSetu - Simple & Fast Mandi Token System

A clean, warm, human-crafted website designed for farmers, mandi authorities, and district officers:
**Farmer Portal ➔ Mandi Center Official Desk ➔ District Officer Portal**

---

## 🌟 What Makes This Design Special (Human-Made & Kid-Simple)

1. **100% Full Translation in All 7 Languages**:
   - **English**
   - **हिंदी (Hindi)**
   - **मराठी (Marathi)**
   - **ਪੰਜਾਬੀ (Punjabi)**
   - **ગુજરાતી (Gujarati)**
   - **বাংলা (Bengali)**
   - **தமிழ் (Tamil)**
   - *Everything* on screen updates when you switch language — headings, buttons, crops, vehicles, table headers, and voice assistance.

2. **No Complicated Graphs or Techno-Jargon**:
   - Complex chart canvases have been completely removed.
   - Clean, large numbers, clear tables, and straightforward notices that anyone can understand in 5 seconds.

3. **Kid-Simple 4-Step Booking for Farmers**:
   - **Step 1**: Click your crop (🌾 Soybean, 🌾 Wheat, 🫘 Chana, 🌼 Mustard, 🌾 Paddy).
   - **Step 2**: Enter quantity in Quintals with big `+` and `-` buttons. Instant price calculation.
   - **Step 3**: Click your vehicle (🚜 Tractor Trolley, 🛻 Bolero Pickup, 🚚 6-Wheel Truck, 🐂 Bullock Cart).
   - **Step 4**: Pick Mandi & Time Slot.
   - Click the big green button: **"✅ Confirm & Get My Token"**.

4. **Authentic Crop Transportation Vehicles Only**:
   - 🚜 Tractor Trolley (2-Wheel) — 30 to 50 Quintals
   - 🚜 Tractor Trolley (4-Wheel Heavy) — 60 to 100 Quintals
   - 🛻 Pickup / Bolero Truck — 20 to 35 Quintals
   - 🚚 Medium Truck (6-Tyre) — 90 to 140 Quintals
   - 🚛 Big Heavy Truck (10-14 Tyre) — 200 to 350 Quintals
   - 🐂 Bullock Cart (Bail Gaadi) — 10 to 18 Quintals

5. **Human-Made Aesthetics**:
   - Crisp white and gentle slate backgrounds with warm emerald green accents.
   - Large, touch-friendly rounded buttons (minimum 52px height).
   - Real-world government receipt slip ready for printing.
   - Soft, pleasant audio chime when calling vehicles.

---

## ⚡ How to Run

1. Open [`index.html`](file:///c:/Users/HP/Desktop/SIH/index.html) in any web browser.
2. Select your language from the top dropdown (English, हिंदी, मराठी, ਪੰਜਾਬੀ, ગુજરાતી, বাংলা, தமிழ்).
3. Click any of the 3 large cards on the Gateway:
   - **Farmer**
   - **Mandi Official**
   - **District Officer**
4. Enjoy the clean, friendly, kid-simple experience!
