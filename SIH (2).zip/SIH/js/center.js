/**
 * KisanSetu - Human-Made Center Official Desk
 * Clean, simple, friendly UI. Fully translated into all 7 Indian languages via window.t().
 */

class CenterDeskController {
  constructor() {
    this.activeTab = 'queue'; // 'queue', 'qc', 'slots', 'dbt', 'parking'
    this.selectedToken = 'A-018';
    this.dbtFilter = 'all'; // 'all', 'awaiting', 'settled'
    this.dbtSearch = '';
    this.modalDisbursementMode = 'instant'; // 'instant', '15day'
    this.activeDbtToken = null;
  }

  init() {
    this.render();
    window.KisanStore.subscribe(() => {
      this.render();
    });
  }

  setTab(tab) {
    this.activeTab = tab;
    this.render();
  }

  setDbtFilter(filter) {
    this.dbtFilter = filter;
    this.render();
  }

  handleDbtSearch(query) {
    this.dbtSearch = (query || '').toLowerCase().trim();
    this.render();
  }

  openDbtModal(tokenOrRef) {
    const state = window.KisanStore.getState();
    const list = state.center.payments.recentList || [];
    const item = list.find(p => p.token === tokenOrRef || p.txnRef === tokenOrRef) || list[0];
    if (!item) return;

    this.activeDbtToken = item.token;
    this.modalDisbursementMode = 'instant';

    const modal = document.getElementById('govt-dbt-modal');
    const content = document.getElementById('govt-dbt-modal-content');
    if (!modal || !content) return;

    content.innerHTML = this.renderDbtModalContent(item);
    modal.classList.remove('hidden');
  }

  closeDbtModal() {
    const modal = document.getElementById('govt-dbt-modal');
    if (modal) modal.classList.add('hidden');
  }

  setModalDisbursementMode(mode) {
    this.modalDisbursementMode = mode;
    const state = window.KisanStore.getState();
    const list = state.center.payments.recentList || [];
    const item = list.find(p => p.token === this.activeDbtToken) || list[0];
    const content = document.getElementById('govt-dbt-modal-content');
    if (content && item) {
      content.innerHTML = this.renderDbtModalContent(item);
    }
  }

  handleAuthorizeDbt(tokenOrRef) {
    const mode = this.modalDisbursementMode === 'instant' 
      ? 'Instant Transfer (Real-time NEFT credit)' 
      : '15-Day MSP Cycle (Standard Govt batch)';

    const res = window.KisanStore.processSingleDBT(tokenOrRef, mode);
    if (window.AppAudio && typeof window.AppAudio.playSuccess === 'function') {
      window.AppAudio.playSuccess();
    }
    this.closeDbtModal();
    this.render();
  }

  exportApmcReportCsv() {
    const state = window.KisanStore.getState();
    const center = state.center;
    const csvRows = [
      ['KisanSetu APMC Daily Procurement & DBT Audit Report'],
      ['Generated On', new Date().toLocaleString()],
      ['Center', center.centerName || 'Indore / Pune APMC Hub'],
      ['Today Bookings', center.kpis.todaysBookings],
      ['Gate Verified', center.kpis.tokenedIn],
      ['Procured Qtl', '51.4 Qtl'],
      [''],
      ['Token', 'Txn Ref', 'Farmer Name', 'Bank Name', 'Account', 'IFSC', 'Amount (INR)', 'Status']
    ];

    (center.payments.recentList || []).forEach(p => {
      csvRows.push([
        p.token,
        p.txnRef || 'N/A',
        `"${p.farmer}"`,
        `"${p.bank || 'State Bank of India'}"`,
        `"${p.account || '****4837'}"`,
        p.ifsc || 'SBIN0000324',
        p.amount,
        p.status
      ]);
    });

    const csvContent = 'data:text/csv;charset=utf-8,' + csvRows.map(e => e.join(',')).join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `APMC_Audit_Report_${Date.now()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    if (window.KisanSetuApi && typeof window.KisanSetuApi.showToast === 'function') {
      window.KisanSetuApi.showToast('📥 APMC CSV Audit Report downloaded successfully!', 'success');
    }
  }

  renderDbtModalContent(item) {
    const isInstant = this.modalDisbursementMode === 'instant';
    const amt = Number(item.amount) || 94764.60;

    return `
      <div class="bg-white rounded-3xl p-6 sm:p-7 border border-slate-200 shadow-2xl space-y-5 text-left animate-in fade-in zoom-in duration-150">
        <!-- Modal Top Bar -->
        <div class="flex items-start justify-between border-b border-slate-100 pb-4">
          <div class="flex items-center gap-3">
            <div class="w-10 h-10 rounded-2xl bg-emerald-50 text-emerald-800 border border-emerald-200 flex items-center justify-center text-xl flex-shrink-0">
              🏛️
            </div>
            <div>
              <h3 class="text-base sm:text-lg font-black text-slate-900 leading-tight">Initiate Govt Bank Transfer</h3>
              <p class="text-xs text-slate-500 mt-0.5">Direct Benefit Transfer via PFMS Portal</p>
            </div>
          </div>
          <button onclick="CenterDesk.closeDbtModal()" class="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-500 hover:text-slate-800 flex items-center justify-center font-bold text-sm transition">
            ✕
          </button>
        </div>

        <!-- Green Transfer Amount Banner (Matching Image 2) -->
        <div class="p-4 rounded-2xl bg-emerald-50/70 border border-emerald-200 space-y-1">
          <span class="text-[10px] font-black uppercase tracking-wider text-emerald-800">TRANSFER AMOUNT</span>
          <div class="text-2xl sm:text-3xl font-black text-emerald-950 font-mono">
            ₹${amt.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </div>
          <p class="text-xs font-semibold text-emerald-800 pt-0.5">
            Token: <span class="font-mono font-bold">${item.token}</span> • Farmer: <span class="font-bold">${item.farmer}</span>
          </p>
        </div>

        <!-- Beneficiary Bank Details Box (Matching Image 2) -->
        <div class="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-2.5 text-xs">
          <div class="flex justify-between items-center">
            <span class="text-slate-500 font-medium">Beneficiary Bank:</span>
            <span class="font-bold text-slate-900 text-right">${item.bank || 'State Bank of India (Baramati)'}</span>
          </div>
          <div class="flex justify-between items-center">
            <span class="text-slate-500 font-medium">Account Number:</span>
            <span class="font-mono font-bold text-slate-900">${item.account || '••••4837'}</span>
          </div>
          <div class="flex justify-between items-center">
            <span class="text-slate-500 font-medium">IFSC Code:</span>
            <span class="font-mono font-bold text-slate-900">${item.ifsc || 'SBIN0000324'}</span>
          </div>
          <div class="flex justify-between items-center pt-1 border-t border-slate-200/60">
            <span class="text-slate-500 font-medium">Aadhaar Status:</span>
            <span class="font-bold text-emerald-700 flex items-center gap-1">
              ✅ NPCI Aadhaar Bridge Linked
            </span>
          </div>
        </div>

        <!-- Disbursement Mode Selector (Matching Image 2) -->
        <div class="space-y-2">
          <label class="block text-xs font-bold text-slate-700">Disbursement Mode:</label>
          <div class="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
            <!-- Mode 1: Instant Transfer -->
            <button type="button" onclick="CenterDesk.setModalDisbursementMode('instant')" class="p-3 rounded-2xl text-left border-2 transition ${isInstant ? 'border-emerald-600 bg-emerald-50/60 shadow-xs' : 'border-slate-200 bg-white hover:bg-slate-50'}">
              <div class="flex items-center gap-1.5">
                <span class="text-sm">⚡</span>
                <strong class="text-xs font-black ${isInstant ? 'text-emerald-950' : 'text-slate-800'}">Instant Transfer</strong>
              </div>
              <p class="text-[11px] ${isInstant ? 'text-emerald-800' : 'text-slate-500'} mt-0.5">Real-time NEFT credit</p>
            </button>

            <!-- Mode 2: 15-Day MSP Cycle -->
            <button type="button" onclick="CenterDesk.setModalDisbursementMode('15day')" class="p-3 rounded-2xl text-left border-2 transition ${!isInstant ? 'border-emerald-600 bg-emerald-50/60 shadow-xs' : 'border-slate-200 bg-white hover:bg-slate-50'}">
              <div class="flex items-center gap-1.5">
                <span class="text-sm">📅</span>
                <strong class="text-xs font-black ${!isInstant ? 'text-emerald-950' : 'text-slate-800'}">15-Day MSP Cycle</strong>
              </div>
              <p class="text-[11px] ${!isInstant ? 'text-emerald-800' : 'text-slate-500'} mt-0.5">Standard Govt batch</p>
            </button>
          </div>
        </div>

        <!-- Modal Action Buttons (Matching Image 2) -->
        <div class="flex items-center gap-3 pt-2">
          <button type="button" onclick="CenterDesk.handleAuthorizeDbt('${item.token}')" class="flex-1 py-3 px-4 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white text-xs sm:text-sm font-bold shadow-md transition flex items-center justify-center gap-2">
            <span>✈️</span>
            <span>Authorize & Transfer to Bank</span>
          </button>
          <button type="button" onclick="CenterDesk.closeDbtModal()" class="py-3 px-5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs sm:text-sm font-bold transition">
            Cancel
          </button>
        </div>
      </div>
    `;
  }

  handleCallNext() {
    const nextVeh = window.KisanStore.callNextToken();
    if (window.AppAudio) window.AppAudio.playBuzzer();
    if (nextVeh) {
      this.selectedToken = nextVeh.token;
      if (window.KisanSetuApi && typeof window.KisanSetuApi.showToast === 'function') {
        window.KisanSetuApi.showToast(`📢 Token ${nextVeh.token} called to Weighbridge Bay 1! (${nextVeh.farmer})`, 'info');
      }
    }
    this.render();
  }

  handleGateCheckIn(scannedText) {
    if (scannedText) {
      this.executeGateCheckin(scannedText);
      return;
    }
    this.openGateScannerModal();
  }

  openGateScannerModal() {
    const modal = document.getElementById('gate-scanner-modal');
    const content = document.getElementById('gate-scanner-modal-content');
    if (!modal || !content) return;

    const state = window.KisanStore.getState();
    const activeToken = state.farmer?.activeToken;
    const currentQueue = state.center?.queue || [];
    const waitingToken = currentQueue.find(q => q.status === 'Waiting' || q.status === 'Checked-In') || { token: 'A-023', farmer: 'Suresh Patil' };

    content.innerHTML = `
      <div class="bg-white rounded-3xl p-6 sm:p-7 border border-slate-200 shadow-2xl space-y-5 text-left animate-in fade-in zoom-in duration-150">
        <!-- Header -->
        <div class="flex items-start justify-between border-b border-slate-100 pb-4">
          <div class="flex items-center gap-3">
            <div class="w-11 h-11 rounded-2xl bg-blue-50 text-blue-700 border border-blue-200 flex items-center justify-center text-2xl flex-shrink-0">
              📷
            </div>
            <div>
              <h3 class="text-base sm:text-lg font-black text-slate-900 leading-tight">Mandi Gate QR Code Scanner</h3>
              <p class="text-xs text-slate-500 mt-0.5">High-speed optical entry check-in for arriving farm vehicles</p>
            </div>
          </div>
          <button onclick="CenterDesk.closeGateScannerModal()" class="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-500 hover:text-slate-800 flex items-center justify-center font-bold text-sm transition">
            ✕
          </button>
        </div>

        <!-- Scanner Viewfinder Box -->
        <div class="relative bg-slate-950 rounded-3xl p-6 text-center overflow-hidden border-2 border-slate-800">
          <!-- Laser Beam Animation -->
          <div class="absolute inset-x-0 h-1 bg-gradient-to-r from-transparent via-emerald-400 to-transparent shadow-[0_0_15px_#10b981] animate-pulse top-1/2 -translate-y-1/2"></div>
          
          <!-- Viewfinder Target Reticle -->
          <div class="w-44 h-44 mx-auto border-2 border-dashed border-emerald-400/80 rounded-2xl relative flex items-center justify-center p-3">
            <div class="absolute -top-1 -left-1 w-4 h-4 border-t-2 border-l-2 border-emerald-400"></div>
            <div class="absolute -top-1 -right-1 w-4 h-4 border-t-2 border-r-2 border-emerald-400"></div>
            <div class="absolute -bottom-1 -left-1 w-4 h-4 border-b-2 border-l-2 border-emerald-400"></div>
            <div class="absolute -bottom-1 -right-1 w-4 h-4 border-b-2 border-r-2 border-emerald-400"></div>

            <img src="https://api.qrserver.com/v1/create-qr-code/?size=120x120&margin=2&data=${encodeURIComponent(`KISANSETU:TOKEN:${activeToken?.id || 'A12'}:GATE:INTAKE`)}" 
                 alt="Target QR" class="w-28 h-28 opacity-80 rounded-lg filter invert" />
          </div>

          <p class="text-[11px] font-mono text-emerald-400 font-bold mt-3">
            ◉ SENSOR ACTIVE: Point handheld gun or mobile pass
          </p>
        </div>

        <!-- One-Click Instant Simulation Buttons -->
        <div class="space-y-2">
          <label class="block text-xs font-bold text-slate-700">Simulate Optical Scan (Tap to Admit):</label>
          <div class="grid grid-cols-1 sm:grid-cols-2 gap-2">
            ${activeToken && activeToken.id ? `
              <button onclick="CenterDesk.executeGateCheckin('${activeToken.id}')" class="p-3 bg-emerald-50 hover:bg-emerald-100 border border-emerald-300 rounded-2xl text-left transition flex items-center gap-2.5">
                <span class="text-xl">🚜</span>
                <div>
                  <strong class="text-xs font-black text-emerald-950 block">Scan ${activeToken.id} (Ramesh Patel)</strong>
                  <span class="text-[10px] text-emerald-700 font-medium">Lane: ${activeToken.parkingLane || 'Lane TT-04'}</span>
                </div>
              </button>
            ` : ''}

            <button onclick="CenterDesk.executeGateCheckin('${waitingToken.token || 'A-023'}')" class="p-3 bg-blue-50 hover:bg-blue-100 border border-blue-300 rounded-2xl text-left transition flex items-center gap-2.5">
              <span class="text-xl">🛻</span>
              <div>
                <strong class="text-xs font-black text-blue-950 block">Scan ${waitingToken.token || 'A-023'}</strong>
                <span class="text-[10px] text-blue-700 font-medium">Standard Arrival</span>
              </div>
            </button>
          </div>
        </div>

        <!-- Manual Barcode / Token Entry Field -->
        <div class="pt-2 border-t border-slate-100 space-y-2">
          <label class="block text-xs font-bold text-slate-700">Manual Scanner / Barcode Input:</label>
          <div class="flex gap-2">
            <input type="text" id="manual-gate-token-input" placeholder="e.g. A12 or scan QR text..." value="${activeToken?.id || 'A12'}" class="flex-1 p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs font-mono font-bold text-slate-900 focus:outline-none focus:border-blue-600">
            <button onclick="CenterDesk.executeGateCheckin(document.getElementById('manual-gate-token-input').value)" class="px-5 py-3 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-xl shadow-sm transition">
              Verify Pass
            </button>
          </div>
        </div>
      </div>
    `;

    modal.classList.remove('hidden');
  }

  closeGateScannerModal() {
    const modal = document.getElementById('gate-scanner-modal');
    if (modal) modal.classList.add('hidden');
  }

  executeGateCheckin(scannedInput) {
    let token = (scannedInput || '').trim();
    if (!token) return;

    // Parse token if full QR text was scanned
    const tokenMatch = token.match(/TOKEN:\s*([A-Za-z0-9-]+)/i) || token.match(/Token:\s*([A-Za-z0-9-]+)/i) || token.match(/KISANSETU:.*?([A-Za-z0-9-]+):/i);
    if (tokenMatch) {
      token = tokenMatch[1].trim();
    }

    window.KisanStore.performGateCheckin(token);
    if (window.AppAudio && typeof window.AppAudio.playSuccess === 'function') {
      window.AppAudio.playSuccess();
    }
    this.closeGateScannerModal();

    if (window.KisanSetuApi && typeof window.KisanSetuApi.showToast === 'function') {
      window.KisanSetuApi.showToast(`✅ Gate Entry Verified! Token ${token} admitted to parking yard.`, 'success');
    } else {
      alert(`✅ Gate Entry Verified!\nToken: ${token}\nVehicle admitted to designated intake lane.`);
    }

    this.render();
  }

  handleBulkDBT() {
    const state = window.KisanStore.getState();
    if (state.center.payments.pendingCount === 0) {
      alert('All payments have already been disbursed!');
      return;
    }

    const totalAmt = window.KisanStore.processBulkDBT();
    if (window.AppAudio) window.AppAudio.playSuccess();
    alert(`🎉 Payments Sent Successfully!\nTotal: ₹${totalAmt.toLocaleString('en-IN')} sent directly to farmers via DBT bank transfer.`);
    this.render();
  }

  handleSaveQC(e, isReject = false) {
    if (e) e.preventDefault();
    const token = document.getElementById('qc-token')?.value || this.selectedToken;
    const moisture = parseFloat(document.getElementById('qc-moisture')?.value) || 8.5;
    const grade = isReject ? 'Reject' : (document.getElementById('qc-grade')?.value || 'A');
    const netQty = parseFloat(document.getElementById('qc-qty')?.value) || 50;
    const assessedRate = parseFloat(document.getElementById('qc-rate')?.value) || (grade === 'A' ? 2275 : 2150);

    if (isReject || grade === 'Reject' || moisture > 14.0) {
      alert(`❌ Produce REJECTED for Token ${token}!\nMoisture (${moisture}%) exceeds the 12% FAQ standard.\nRejection slip issued.`);
      return;
    }

    window.KisanStore.saveQCAndWeighment({
      token,
      moisture,
      grade,
      acceptedQty: netQty,
      rejectedQty: 0,
      assessedRate
    });

    if (window.AppAudio) window.AppAudio.playSuccess();
    const totalPayable = Math.round(netQty * assessedRate);
    alert(`✅ Quality & Weighment Approved for Token ${token}!\n• Net Certified Weight: ${netQty} Qtl\n• Ground Rate Assessed: ₹${assessedRate}/Qtl\n• Final Amount Approved: ₹${totalPayable.toLocaleString('en-IN')}\n\n👉 Tracking System & Mandi Bill updated in real-time!`);
    this.openPrintSlipModal(token);
    this.render();
  }

  openPrintSlipModal(tokenId) {
    const state = window.KisanStore.getState();
    const token = tokenId || state.farmer.activeToken.id;
    const qItem = state.center.queue.find(q => q.token === token) || state.farmer.activeToken;
    const farmer = state.farmer;

    const modal = document.getElementById('mandi-receipt-modal');
    if (!modal) return;

    const crop = qItem.crop || 'Soybean';
    const qty = qItem.qty || qItem.qtyQuintal || 50;
    const rate = qItem.assessedRate || qItem.finalRate || (crop === 'Soybean' ? 4850 : crop === 'Wheat' ? 2275 : 5440);
    const total = qItem.finalAmount || (qty * rate);

    const content = document.getElementById('receipt-modal-content');
    if (content) {
      content.innerHTML = `
        <div class="border-2 border-slate-900 p-6 sm:p-8 bg-white rounded-3xl text-slate-900 font-sans max-w-lg mx-auto shadow-xl space-y-4">
          <!-- Official Mandi Heading -->
          <div class="text-center pb-4 border-b border-slate-300">
            <h2 class="text-xl font-black text-slate-900 uppercase">KisanSetu • Mandi Slip</h2>
            <p class="text-xs text-slate-600">Indore Mandi Hub • Certified Weighbridge Receipt</p>
            <p class="text-xs font-mono font-bold text-slate-500 mt-1">Receipt No: REC-${Date.now().toString().slice(-6)}</p>
          </div>

          <!-- Farmer & Vehicle Details -->
          <div class="grid grid-cols-2 gap-4 text-xs">
            <div>
              <p class="text-slate-500">Token:</p>
              <p class="text-lg font-black font-mono text-emerald-700">${token}</p>
              <p class="text-slate-500 mt-2">Farmer:</p>
              <p class="font-bold text-slate-900">${qItem.farmer || farmer.name}</p>
              <p class="text-slate-500">${farmer.village || farmer.residence?.village || 'Indore Region'}</p>
            </div>
            <div class="text-right">
              <p class="text-slate-500">Date:</p>
              <p class="font-bold">${new Date().toLocaleDateString('en-GB')}</p>
              <p class="text-slate-500 mt-2">Vehicle:</p>
              <p class="font-bold">${qItem.vehicle || 'Tractor Trolley'}</p>
              <p class="font-mono text-slate-600">${qItem.vehicleNo || 'MP-09-AB-1234'}</p>
            </div>
          </div>

          <!-- Weight & Price Table -->
          <div class="bg-slate-50 p-4 rounded-2xl border border-slate-200 text-xs space-y-2">
            <div class="flex justify-between">
              <span>Crop Name:</span>
              <strong class="text-slate-900">${crop} (Grade A)</strong>
            </div>
            <div class="flex justify-between">
              <span>Net Certified Weight:</span>
              <strong class="text-slate-900">${qty} Quintals</strong>
            </div>
            <div class="flex justify-between">
              <span>Assessed Ground Rate:</span>
              <span class="font-bold text-slate-900">₹${rate}/Quintal</span>
            </div>
            <div class="pt-2 border-t border-slate-300 flex justify-between text-sm font-black">
              <span>Total Payment:</span>
              <span class="text-emerald-700 font-mono">₹${total.toLocaleString('en-IN')}</span>
            </div>
          </div>

          <!-- Direct Bank Deposit Notice -->
          <div class="text-xs text-slate-600 bg-emerald-50 p-3 rounded-xl border border-emerald-200">
            <p class="font-bold text-emerald-900">Direct Bank Transfer (DBT):</p>
            <p>Will be deposited to Bank of India (A/C •••• 4821)</p>
          </div>

          <!-- Government QR Verification Stamp (Scannable via Mobile) -->
          <div class="flex items-center gap-3 p-3 bg-slate-50 rounded-xl border border-slate-200">
            <img src="https://api.qrserver.com/v1/create-qr-code/?size=100x100&margin=4&data=${encodeURIComponent(`🌾 KISANSETU VERIFIED MANDI RECEIPT\nReceipt: REC-${token}\nTotal MSP: Rs. ${total.toLocaleString('en-IN')}\nStatus: DBT PENDING / APPROVED\nMandi: Indore Super APMC`)}" 
                 alt="Certified Mandi QR" class="w-16 h-16 rounded-lg border border-slate-300 bg-white flex-shrink-0" />
            <div class="text-[11px] text-slate-500">
              <p class="font-bold text-slate-800">Official APMC Audit Stamp</p>
              <p>Tamper-proof weighbridge digital certificate.</p>
              <p class="font-mono text-emerald-700 font-bold mt-0.5">📷 Scannable with any smartphone</p>
            </div>
          </div>

          <!-- Buttons -->
          <div class="flex gap-2 pt-2 no-print">
            <button onclick="window.print()" class="btn-large flex-1 bg-emerald-600 hover:bg-emerald-700 text-white text-sm">
              🖨️ Print Mandi Slip
            </button>
            <button onclick="document.getElementById('mandi-receipt-modal').classList.add('hidden')" class="btn-large px-5 bg-slate-200 hover:bg-slate-300 text-slate-800 text-sm">
              Close
            </button>
          </div>
        </div>
      `;
    }

    modal.classList.remove('hidden');
    try { if (window.lucide && typeof window.lucide.createIcons === 'function') window.lucide.createIcons(); } catch (e) {}
  }

  render() {
    const container = document.getElementById('section-center-desk');
    if (!container) return;

    const state = window.KisanStore.getState();
    const center = state.center;
    const kpis = center.kpis;
    const t = window.t;

    const currentState = state.selectedState || 'All India';

    container.innerHTML = `
      <div class="space-y-6">
        <!-- Center Header Banner -->
        <div class="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-sm flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div class="flex items-center gap-4">
            <div class="w-16 h-16 rounded-2xl bg-blue-100 text-blue-700 text-2xl font-black flex items-center justify-center flex-shrink-0">
              🏢
            </div>
            <div>
              <div class="flex items-center gap-2 flex-wrap">
                <h2 class="text-2xl sm:text-3xl font-black text-slate-900">${center.centerName || 'Pune APMC (Gultekdi Central Market Yard)'}</h2>
                <span class="px-2.5 py-0.5 rounded-full text-xs font-bold bg-blue-50 text-blue-800 border border-blue-200">
                  ${currentState} APMC Hub
                </span>
              </div>
              <p class="text-xs sm:text-sm text-slate-600 mt-0.5">${center.operatorName || 'Suresh Deshmukh (APMC Superintendent)'} • ${t('centerSubtitle')}</p>
            </div>
          </div>

          <!-- Big Action Buttons -->
          <div class="flex items-center gap-2 flex-wrap">
            <button onclick="App.openGlobalHeatmap('All', '${currentState}')" class="btn-large px-4 bg-amber-400 hover:bg-amber-300 text-amber-950 font-bold text-xs shadow-sm">
              🗺️ ${t('heatmapTitle')}
            </button>
            <button onclick="CenterDesk.handleCallNext()" class="btn-large px-5 bg-blue-600 hover:bg-blue-700 text-white shadow-md text-sm">
              ${t('btnCallNext')}
            </button>
            <button onclick="CenterDesk.handleGateCheckIn()" class="btn-large px-4 bg-slate-100 hover:bg-slate-200 text-slate-800 text-sm">
              ${t('btnGateCheckin')}
            </button>
            <button onclick="CenterDesk.handleBulkDBT()" class="btn-large px-4 bg-emerald-600 hover:bg-emerald-700 text-white text-sm">
              ${t('btnBulkPay')}
            </button>
          </div>
        </div>

        <!-- 4 Big KPI Counter Cards -->
        <div class="grid grid-cols-2 sm:grid-cols-4 gap-4">
          <div class="bg-white p-5 rounded-3xl border border-slate-200 shadow-sm">
            <span class="text-xs font-bold text-slate-500 uppercase">${t('kpiBookings')}</span>
            <div class="text-3xl sm:text-4xl font-black text-slate-900 font-mono mt-1">${kpis.todaysBookings.toLocaleString('en-IN')}</div>
          </div>

          <div class="bg-white p-5 rounded-3xl border border-slate-200 shadow-sm">
            <span class="text-xs font-bold text-slate-500 uppercase">${t('kpiGateIn')}</span>
            <div class="text-3xl sm:text-4xl font-black text-emerald-600 font-mono mt-1">${kpis.tokenedIn.toLocaleString('en-IN')}</div>
          </div>

          <div class="bg-white p-5 rounded-3xl border border-slate-200 shadow-sm">
            <span class="text-xs font-bold text-slate-500 uppercase">${t('kpiInLine')}</span>
            <div class="text-3xl sm:text-4xl font-black text-amber-600 font-mono mt-1">${kpis.inQueue.toLocaleString('en-IN')}</div>
          </div>

          <div class="bg-white p-5 rounded-3xl border border-slate-200 shadow-sm">
            <span class="text-xs font-bold text-slate-500 uppercase">${t('kpiDone')}</span>
            <div class="text-3xl sm:text-4xl font-black text-blue-600 font-mono mt-1">${kpis.completed.toLocaleString('en-IN')}</div>
          </div>
        </div>

        <!-- Navigation Tabs -->
        <div class="flex items-center gap-2 border-b border-slate-200 pb-3 overflow-x-auto">
          <button onclick="CenterDesk.setTab('queue')" class="px-5 py-2.5 rounded-2xl text-sm font-bold transition whitespace-nowrap ${this.activeTab === 'queue' ? 'bg-blue-600 text-white shadow-sm' : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-50'}">
            ${t('queueTab')} (${center.queue.length})
          </button>
          <button onclick="CenterDesk.setTab('qc')" class="px-5 py-2.5 rounded-2xl text-sm font-bold transition whitespace-nowrap ${this.activeTab === 'qc' ? 'bg-blue-600 text-white shadow-sm' : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-50'}">
            ${t('qcTab')}
          </button>
          <button onclick="CenterDesk.setTab('slots')" class="px-5 py-2.5 rounded-2xl text-sm font-bold transition whitespace-nowrap ${this.activeTab === 'slots' ? 'bg-blue-600 text-white shadow-sm' : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-50'}">
            🤖 AI Slot & Capacity
          </button>
          <button onclick="CenterDesk.setTab('dbt')" class="px-5 py-2.5 rounded-2xl text-sm font-bold transition whitespace-nowrap ${this.activeTab === 'dbt' ? 'bg-blue-600 text-white shadow-sm' : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-50'}">
            🏛️ Govt DBT / PFMS
          </button>
          <button onclick="CenterDesk.setTab('parking')" class="px-5 py-2.5 rounded-2xl text-sm font-bold transition whitespace-nowrap ${this.activeTab === 'parking' ? 'bg-blue-600 text-white shadow-sm' : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-50'}">
            ${t('parkingTab')}
          </button>
        </div>

        <!-- Tab Content -->
        <div>
          ${this.renderActiveTab(t, center)}
        </div>
      </div>
    `;

    try { if (window.lucide && typeof window.lucide.createIcons === 'function') window.lucide.createIcons(); } catch (e) {}
  }

  renderActiveTab(t, center) {
    if (this.activeTab === 'qc') {
      return this.renderQCTab(t, center);
    } else if (this.activeTab === 'slots') {
      return this.renderSlotsTab(t, center);
    } else if (this.activeTab === 'dbt') {
      return this.renderDbtTab(t, center);
    } else if (this.activeTab === 'parking') {
      return this.renderParkingTab(t, center);
    } else {
      return this.renderQueueTab(t, center);
    }
  }

  renderQueueTab(t, center) {
    return `
      <div class="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
        <div class="p-5 border-b border-slate-200 flex justify-between items-center bg-slate-50">
          <h3 class="font-black text-slate-900 text-base">${t('queueTab')}</h3>
          <button onclick="CenterDesk.handleCallNext()" class="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5">
            📢 ${t('btnCallNext')}
          </button>
        </div>

        <div class="overflow-x-auto">
          <table class="w-full text-left text-xs sm:text-sm">
            <thead>
              <tr class="border-b border-slate-200 text-slate-500 font-bold bg-slate-50">
                <th class="py-3 px-4">${t('colToken')}</th>
                <th class="py-3 px-4">${t('colFarmer')}</th>
                <th class="py-3 px-4">${t('colCrop')}</th>
                <th class="py-3 px-4">${t('colVehicle')}</th>
                <th class="py-3 px-4">${t('colBay')}</th>
                <th class="py-3 px-4">${t('colStatus')}</th>
                <th class="py-3 px-4 text-right">${t('colAction')}</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-100">
              ${center.queue.map(item => {
                const isServing = item.status === 'Serving';
                return `
                  <tr class="hover:bg-slate-50 ${isServing ? 'bg-blue-50/50' : ''}">
                    <td class="py-3.5 px-4 font-mono font-black text-slate-900">${item.token}</td>
                    <td class="py-3.5 px-4 font-bold text-slate-900">${item.farmer}</td>
                    <td class="py-3.5 px-4 text-slate-600">${item.crop} (${item.qty} Qtl)</td>
                    <td class="py-3.5 px-4 text-slate-600">
                      <div class="flex items-center gap-2">
                        <span class="w-7 h-7 rounded-lg bg-slate-100 text-slate-700 flex items-center justify-center border border-slate-200 flex-shrink-0 shadow-xs">
                          ${window.getVehicleSvgLogo ? window.getVehicleSvgLogo(item.vehicle, 18) : (item.vehicleIcon || '🚜')}
                        </span>
                        <span class="truncate max-w-[160px] font-medium text-slate-900">${item.vehicle}</span>
                      </div>
                    </td>
                    <td class="py-3.5 px-4"><span class="px-2 py-0.5 rounded bg-slate-100 text-slate-700 font-mono text-xs">${item.lane}</span></td>
                    <td class="py-3.5 px-4">
                      <span class="inline-block px-2.5 py-1 rounded-full text-xs font-bold ${isServing ? 'bg-blue-100 text-blue-800' : 'bg-amber-100 text-amber-800'}">
                        ${isServing ? 'Now Serving' : 'Waiting in Line'}
                      </span>
                    </td>
                    <td class="py-3.5 px-4 text-right">
                      ${isServing ? `
                        <button onclick="CenterDesk.selectedToken = '${item.token}'; CenterDesk.setTab('qc')" class="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold">
                          ${t('actionInspect')}
                        </button>
                      ` : `
                        <button onclick="CenterDesk.handleCallNext()" class="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold">
                          ${t('actionCall')}
                        </button>
                      `}
                    </td>
                  </tr>
                `;
              }).join('')}
            </tbody>
          </table>
        </div>
      </div>
    `;
  }

  renderQCTab(t, center) {
    const item = center.queue.find(q => q.token === this.selectedToken) || center.queue[0];

    return `
      <div class="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-sm max-w-2xl mx-auto space-y-6">
        <div>
          <h3 class="text-xl font-black text-slate-900">${t('qcHeading')}</h3>
          <p class="text-xs text-slate-500 mt-1">Simple electronic weighbridge slip entry</p>
        </div>

        <form onsubmit="CenterDesk.handleSaveQC(event)" class="space-y-4">
          <div>
            <label class="block text-xs font-bold text-slate-700 mb-1">Farmer Token</label>
            <select id="qc-token" class="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl font-bold text-sm">
              ${center.queue.map(q => `
                <option value="${q.token}" ${q.token === this.selectedToken ? 'selected' : ''}>
                  ${q.token} - ${q.farmer} (${q.crop}, ${q.qty} Qtl)
                </option>
              `).join('')}
            </select>
          </div>

          <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label class="block text-xs font-bold text-slate-700 mb-1">${t('qcMoisture')}</label>
              <input type="number" step="0.1" id="qc-moisture" value="8.5" class="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl font-bold text-sm">
              <span class="text-[11px] text-slate-500">${t('qcMoistureHelp')}</span>
            </div>

            <div>
              <label class="block text-xs font-bold text-slate-700 mb-1">${t('qcGrade')}</label>
              <select id="qc-grade" class="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl font-bold text-sm">
                <option value="A" selected>${t('gradeA')}</option>
                <option value="B">${t('gradeB')}</option>
                <option value="Reject">${t('gradeReject')}</option>
              </select>
            </div>
          </div>

          <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label class="block text-xs font-bold text-slate-700 mb-1">${t('qcNetWeight')}</label>
              <input type="number" id="qc-qty" value="${item ? item.qty : 50}" oninput="document.getElementById('qc-live-total').innerText = '₹' + Math.round((parseFloat(this.value)||0) * (parseFloat(document.getElementById('qc-rate').value)||0)).toLocaleString('en-IN')" class="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl font-bold text-sm text-emerald-700 font-mono">
            </div>

            <div>
              <label class="block text-xs font-bold text-slate-700 mb-1">Assessed Ground Rate (₹/Qtl)</label>
              <input type="number" id="qc-rate" value="${item && item.crop === 'Soybean' ? 4850 : 2275}" oninput="document.getElementById('qc-live-total').innerText = '₹' + Math.round((parseFloat(this.value)||0) * (parseFloat(document.getElementById('qc-qty').value)||0)).toLocaleString('en-IN')" class="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl font-bold text-sm text-emerald-700 font-mono">
              <span class="text-[10px] text-slate-400">Decided on ground based on physical FAQ sample</span>
            </div>
          </div>

          <!-- Live Total Payable Calculation -->
          <div class="p-3.5 bg-emerald-50 rounded-2xl border border-emerald-200 text-xs flex justify-between items-center">
            <div>
              <span class="font-black text-emerald-900 block">Total Certified Payable:</span>
              <span class="text-[10px] text-emerald-700">Net Weight × Ground Assessed Rate</span>
            </div>
            <span id="qc-live-total" class="font-black text-emerald-800 font-mono text-lg">
              ₹${Math.round((item ? item.qty : 50) * (item && item.crop === 'Soybean' ? 4850 : 2275)).toLocaleString('en-IN')}
            </span>
          </div>

          <div class="pt-4 border-t border-slate-100 flex flex-col sm:flex-row gap-2.5">
            <button type="submit" class="btn-large flex-1 bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-bold shadow-md">
              ✅ Approve Produce & Fix Rate
            </button>
            <button type="button" onclick="CenterDesk.handleSaveQC(event, true)" class="btn-large px-4 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 text-xs font-bold">
              ❌ Reject Produce
            </button>
            <button type="button" onclick="CenterDesk.openPrintSlipModal('${this.selectedToken}')" class="btn-large px-4 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold">
              View Slip
            </button>
          </div>
        </form>
      </div>
    `;
  }

  renderParkingTab(t, center) {
    const lanes = center.parkingLanes;

    const laneCards = [
      { lane: lanes.tractorTrolley, badge: 'Standard Farm' },
      { lane: lanes.pickupBolero, badge: 'Quick Delivery' },
      { lane: lanes.truck6Tyre, badge: 'Commercial' },
      { lane: lanes.heavyHauler, badge: 'Heavy Haul' },
      { lane: lanes.bullockCart, badge: 'Traditional' }
    ];

    return `
      <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
        ${laneCards.map(c => `
          <div class="bg-white p-5 rounded-3xl border border-slate-200 shadow-sm space-y-4 overflow-hidden hover:border-emerald-300 transition group">
            <div class="flex items-center justify-between">
              <div class="w-12 h-12 rounded-2xl bg-emerald-50 text-emerald-800 border border-emerald-200 flex items-center justify-center shadow-xs group-hover:scale-105 transition">
                ${window.getVehicleSvgLogo ? window.getVehicleSvgLogo(c.lane.name, 26) : '<span class="text-2xl">🚜</span>'}
              </div>
              <span class="px-2.5 py-1 rounded-full text-xs font-black bg-slate-100 text-slate-700 border border-slate-200">
                ${c.lane.occupied} / ${c.lane.total} Bays
              </span>
            </div>
            <div>
              <div class="flex items-center justify-between">
                <h4 class="font-black text-slate-900 text-sm">${c.lane.name}</h4>
                <span class="text-[10px] font-bold uppercase tracking-wider text-slate-400">${c.badge}</span>
              </div>
              <div class="w-full bg-slate-100 h-2 rounded-full overflow-hidden mt-3">
                <div class="bg-emerald-600 h-full rounded-full transition-all duration-500" style="width: ${Math.min(100, Math.round((c.lane.occupied / c.lane.total) * 100))}%"></div>
              </div>
              <p class="text-xs text-emerald-700 font-bold mt-2 flex justify-between">
                <span>Occupancy</span>
                <span>${Math.round((c.lane.occupied / c.lane.total) * 100)}%</span>
              </p>
            </div>
          </div>
        `).join('')}
      </div>
    `;
  }

  // =========================================================================
  // AI Slot Allocation & Capacity Control Tab
  // =========================================================================
  renderSlotsTab(t, center) {
    const capacity = center.capacity || { hourlyCapacity: 50, bookedSlots: 42, availableSlots: 8, isBlocked: false };
    const isBlocked = capacity.isBlocked;
    const hourlyCap = capacity.hourlyCapacity || 50;
    const booked = capacity.bookedSlots || 42;
    const available = capacity.availableSlots || 8;

    const hourlySchedule = [
      { slot: '09:00 - 10:00 AM', booked: 28, max: hourlyCap, tractors: 16, trucks: 8, bolero: 4, status: 'Peak Rush', statusClass: 'bg-rose-100 text-rose-800' },
      { slot: '10:00 - 11:00 AM', booked: 6, max: hourlyCap, tractors: 4, trucks: 0, bolero: 2, status: 'AI Optimal (Fast Pass)', statusClass: 'bg-emerald-100 text-emerald-800 font-bold' },
      { slot: '11:00 - 12:00 PM', booked: 19, max: hourlyCap, tractors: 10, trucks: 3, bolero: 6, status: 'Normal Flow', statusClass: 'bg-amber-100 text-amber-800' },
      { slot: '12:00 - 01:00 PM', booked: 29, max: hourlyCap, tractors: 14, trucks: 11, bolero: 4, status: 'Heavy Haulers Wave', statusClass: 'bg-rose-100 text-rose-800' },
      { slot: '02:00 - 03:00 PM', booked: 9, max: hourlyCap, tractors: 5, trucks: 1, bolero: 3, status: 'Clear Window', statusClass: 'bg-emerald-100 text-emerald-800' },
      { slot: '03:00 - 04:00 PM', booked: 14, max: hourlyCap, tractors: 8, trucks: 2, bolero: 4, status: 'Normal Flow', statusClass: 'bg-slate-100 text-slate-700' }
    ];

    return `
      <div class="space-y-6 text-left">
        <!-- AI Slot Allocation & Capacity Control Header -->
        <div class="bg-gradient-to-r from-blue-900 via-indigo-900 to-slate-900 rounded-3xl p-6 sm:p-7 text-white shadow-md flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border border-blue-700/40">
          <div class="flex items-center gap-3">
            <div class="w-12 h-12 rounded-2xl bg-blue-500/20 text-blue-300 border border-blue-400/30 flex items-center justify-center text-2xl flex-shrink-0 shadow-inner">
              🤖
            </div>
            <div>
              <div class="flex items-center gap-2">
                <h3 class="text-lg sm:text-xl font-black">AI Mandi Slot & Yard Capacity Control</h3>
                <span class="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-400/30 text-[10px] font-black">
                  Neural Load Balancer Active
                </span>
              </div>
              <p class="text-xs text-blue-200 mt-1">Real-time dynamic slot throttling between tractors, light pickups, and heavy haulers.</p>
            </div>
          </div>

          <div class="flex items-center gap-2.5">
            <button onclick="CenterDesk.handleAiRebalance()" class="px-4 py-2.5 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-bold shadow-md transition flex items-center gap-1.5 whitespace-nowrap">
              <span>⚡</span> Rebalance with AI
            </button>
            <button onclick="CenterDesk.handleToggleSlotBlock()" class="px-4 py-2.5 ${isBlocked ? 'bg-emerald-600 hover:bg-emerald-700' : 'bg-rose-600 hover:bg-rose-700'} text-white rounded-xl text-xs font-bold shadow-md transition flex items-center gap-1.5 whitespace-nowrap">
              <span>${isBlocked ? '🔓' : '🚫'}</span> ${isBlocked ? 'Unblock Current Slot' : 'Block Current Slot'}
            </button>
          </div>
        </div>

        <!-- 3 Metric Tiles -->
        <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <!-- Hourly Capacity -->
          <div class="bg-white p-5 rounded-3xl border border-slate-200 shadow-sm">
            <div class="flex items-center justify-between">
              <span class="text-xs font-bold text-slate-500 uppercase">Hourly Gate Limit</span>
              <div class="flex items-center gap-1">
                <button onclick="CenterDesk.handleAdjustCapacity(-5)" class="w-7 h-7 rounded-lg bg-slate-100 hover:bg-slate-200 font-black text-slate-800 text-xs flex items-center justify-center">-</button>
                <button onclick="CenterDesk.handleAdjustCapacity(5)" class="w-7 h-7 rounded-lg bg-slate-100 hover:bg-slate-200 font-black text-slate-800 text-xs flex items-center justify-center">+</button>
              </div>
            </div>
            <div class="text-3xl font-black text-slate-900 font-mono mt-2">${hourlyCap} <span class="text-xs font-bold text-slate-400">vehicles/hr</span></div>
            <p class="text-[11px] text-slate-500 mt-1">Mandi weighbridge processing limit</p>
          </div>

          <!-- Booked vs Available -->
          <div class="bg-white p-5 rounded-3xl border border-slate-200 shadow-sm">
            <span class="text-xs font-bold text-slate-500 uppercase">Today's Booked Quota</span>
            <div class="text-3xl font-black text-blue-600 font-mono mt-2">${booked} <span class="text-xs font-bold text-slate-400">/ ${hourlyCap} filled</span></div>
            <div class="w-full bg-slate-100 rounded-full h-2 mt-2.5 overflow-hidden">
              <div class="h-full rounded-full ${booked > 40 ? 'bg-amber-500' : 'bg-blue-600'}" style="width: ${(booked / hourlyCap) * 100}%"></div>
            </div>
          </div>

          <!-- AI Status -->
          <div class="bg-white p-5 rounded-3xl border border-slate-200 shadow-sm">
            <span class="text-xs font-bold text-slate-500 uppercase">AI Load Balancing</span>
            <div class="text-xl font-black text-emerald-700 mt-2 flex items-center gap-2">
              <span class="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse"></span>
              Optimal Turnaround
            </div>
            <p class="text-[11px] text-slate-500 mt-1.5">Auto-separating heavy 14-tyre trucks from light tractor lanes</p>
          </div>
        </div>

        <!-- Hourly Schedule Spectrum Table -->
        <div class="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
          <div class="p-5 border-b border-slate-200 flex justify-between items-center bg-slate-50">
            <div>
              <h4 class="font-black text-slate-900 text-base">Mandi Hourly Slot Allocation Matrix</h4>
              <p class="text-xs text-slate-500 mt-0.5">Real-time vehicle category distribution per appointment window</p>
            </div>
            <span class="px-3 py-1 rounded-full bg-blue-50 text-blue-800 border border-blue-200 text-xs font-extrabold">
              Today: 15 Oct 2025
            </span>
          </div>

          <div class="overflow-x-auto">
            <table class="w-full text-left text-xs sm:text-sm">
              <thead>
                <tr class="border-b border-slate-200 text-slate-500 font-bold bg-slate-50">
                  <th class="py-3 px-4">Time Window</th>
                  <th class="py-3 px-4">Booked / Cap</th>
                  <th class="py-3 px-4">Vehicle Composition</th>
                  <th class="py-3 px-4">AI Traffic Rating</th>
                  <th class="py-3 px-4 text-right">Yard Action</th>
                </tr>
              </thead>
              <tbody class="divide-y divide-slate-100">
                ${hourlySchedule.map(h => `
                  <tr class="hover:bg-slate-50">
                    <td class="py-3.5 px-4 font-mono font-black text-slate-900">${h.slot}</td>
                    <td class="py-3.5 px-4">
                      <span class="font-mono font-bold text-slate-800">${h.booked} / ${h.max}</span>
                      <div class="w-24 bg-slate-100 rounded-full h-1.5 mt-1 overflow-hidden">
                        <div class="h-full rounded-full ${h.booked > 25 ? 'bg-rose-500' : h.booked > 15 ? 'bg-amber-500' : 'bg-emerald-500'}" style="width: ${(h.booked / h.max) * 100}%"></div>
                      </div>
                    </td>
                    <td class="py-3.5 px-4 text-slate-600 text-xs">
                      <span>🚜 ${h.tractors} Tractors</span> • 
                      <span>🛻 ${h.bolero} Bolero</span> • 
                      <span>🚚 ${h.trucks} Trucks</span>
                    </td>
                    <td class="py-3.5 px-4">
                      <span class="px-2.5 py-1 rounded-full text-[10px] font-extrabold border ${h.statusClass}">
                        ${h.status}
                      </span>
                    </td>
                    <td class="py-3.5 px-4 text-right">
                      <button onclick="alert('Priority ramp for ${h.slot} re-allocated.')" class="px-3 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-lg transition">
                        Inspect
                      </button>
                    </td>
                  </tr>
                `).join('')}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    `;
  }

  handleToggleSlotBlock() {
    if (window.KisanStore && typeof window.KisanStore.toggleSlotBlock === 'function') {
      const isBlocked = window.KisanStore.toggleSlotBlock();
      this.render();
      if (window.App && typeof window.App.showToast === 'function') {
        window.App.showToast(isBlocked ? '🚫 Current hourly slot blocked for arrivals.' : '🔓 Hourly slot unblocked for bookings.', isBlocked ? 'warning' : 'success');
      }
    }
  }

  handleAdjustCapacity(delta) {
    if (window.KisanStore && typeof window.KisanStore.adjustHourlyCapacity === 'function') {
      const cap = window.KisanStore.adjustHourlyCapacity(delta);
      this.render();
      if (window.App && typeof window.App.showToast === 'function') {
        window.App.showToast(`Mandi hourly capacity adjusted to ${cap} vehicles/hour.`, 'info');
      }
    }
  }

  handleAiRebalance() {
    if (window.App && typeof window.App.showToast === 'function') {
      window.App.showToast('🤖 AI dynamic load rebalancing completed: 12 heavy trucks diverted to bypass ramp.', 'success');
    }
    this.render();
  }

  renderDbtTab(t, center) {
    const list = center.payments?.recentList || [];
    const query = (this.dbtSearch || '').toLowerCase().trim();
    const filter = this.dbtFilter || 'all';

    // Calculate live aggregates
    const pendingItems = list.filter(p => p.status === 'Processing' || p.status === 'Pending');
    const settledItems = list.filter(p => p.status === 'Settled' || p.status === 'Success');
    
    const toBePaidTotal = pendingItems.reduce((acc, p) => acc + (Number(p.amount) || 0), 0);
    const paidTodayTotal = settledItems.reduce((acc, p) => acc + (Number(p.amount) || 0), 0);

    // Filter items
    let filtered = list;
    if (filter === 'awaiting') {
      filtered = filtered.filter(p => p.status === 'Processing' || p.status === 'Pending');
    } else if (filter === 'settled') {
      filtered = filtered.filter(p => p.status === 'Settled' || p.status === 'Success');
    }

    if (query) {
      filtered = filtered.filter(p => 
        (p.token && p.token.toLowerCase().includes(query)) ||
        (p.farmer && p.farmer.toLowerCase().includes(query)) ||
        (p.txnRef && p.txnRef.toLowerCase().includes(query)) ||
        (p.bank && p.bank.toLowerCase().includes(query)) ||
        (p.account && p.account.toLowerCase().includes(query)) ||
        (p.location && p.location.toLowerCase().includes(query))
      );
    }

    return `
      <div class="space-y-6">
        <!-- Main Console Card (Matching Image 1) -->
        <div class="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-sm space-y-6">
          
          <!-- Treasury Header -->
          <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-5">
            <div class="flex items-center gap-3.5">
              <div class="w-12 h-12 rounded-2xl bg-emerald-50 text-emerald-800 border border-emerald-200 flex items-center justify-center text-2xl flex-shrink-0">
                🏛️
              </div>
              <div>
                <div class="flex items-center gap-2 flex-wrap">
                  <h3 class="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
                    GOVT BANK-TO-BANK TRANSFER (DBT / PFMS)
                  </h3>
                  <span class="px-2.5 py-0.5 rounded-full text-[10px] font-black bg-emerald-50 text-emerald-800 border border-emerald-200 uppercase tracking-wide">
                    PFMS Direct Benefit Transfer
                  </span>
                </div>
                <p class="text-xs text-slate-500 mt-1">Official Treasury Direct Bank Transfer & Settlement Console</p>
              </div>
            </div>

            <button onclick="CenterDesk.handleBulkDBT()" class="btn-large px-4 bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold shadow-sm whitespace-nowrap">
              ⚡ Bulk Release All DBT
            </button>
          </div>

          <!-- 2 Live Balances KPI Cards (Matching Image 1) -->
          <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <!-- TO BE PAID -->
            <div class="p-5 rounded-2xl border border-slate-200 bg-slate-50/70 space-y-1">
              <div class="flex items-center justify-between text-xs font-bold text-slate-500">
                <span>TO BE PAID</span>
                <span class="text-slate-400">🕒</span>
              </div>
              <div class="text-2xl sm:text-3xl font-black text-slate-900 font-mono">
                ₹${toBePaidTotal.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </div>
              <p class="text-xs text-slate-500">
                ${pendingItems.length} farmers awaiting DBT...
              </p>
            </div>

            <!-- PAID TODAY -->
            <div class="p-5 rounded-2xl border border-slate-200 bg-slate-50/70 space-y-1">
              <div class="flex items-center justify-between text-xs font-bold text-slate-500">
                <span>PAID TODAY</span>
                <span class="text-emerald-600">✅</span>
              </div>
              <div class="text-2xl sm:text-3xl font-black text-slate-900 font-mono">
                ₹${paidTodayTotal.toLocaleString('en-IN', { minimumFractionDigits: 0, maximumFractionDigits: 2 })}
              </div>
              <p class="text-xs text-slate-500">
                ${settledItems.length} farmers transferred vi...
              </p>
            </div>
          </div>

          <!-- Search Bar (Matching Image 1) -->
          <div class="relative">
            <span class="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400 text-sm">
              🔍
            </span>
            <input 
              type="text" 
              value="${this.dbtSearch || ''}" 
              oninput="CenterDesk.handleDbtSearch(this.value)" 
              placeholder="Search token, farmer name, txn ref, UTR..." 
              class="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-2xl text-xs sm:text-sm font-medium text-slate-900 focus:outline-none focus:border-emerald-600 transition"
            />
          </div>

          <!-- 3 Filter Pills (Matching Image 1) -->
          <div class="flex items-center gap-2 flex-wrap">
            <button onclick="CenterDesk.setDbtFilter('all')" class="px-4 py-2 rounded-xl text-xs font-bold transition ${filter === 'all' ? 'bg-emerald-800 text-white shadow-xs' : 'bg-slate-100 text-slate-700 hover:bg-slate-200'}">
              All (${list.length})
            </button>
            <button onclick="CenterDesk.setDbtFilter('awaiting')" class="px-4 py-2 rounded-xl text-xs font-bold transition ${filter === 'awaiting' ? 'bg-emerald-800 text-white shadow-xs' : 'bg-slate-100 text-slate-700 hover:bg-slate-200'}">
              Awaiting DBT Release (${pendingItems.length})
            </button>
            <button onclick="CenterDesk.setDbtFilter('settled')" class="px-4 py-2 rounded-xl text-xs font-bold transition ${filter === 'settled' ? 'bg-emerald-800 text-white shadow-xs' : 'bg-slate-100 text-slate-700 hover:bg-slate-200'}">
              Bank Settled (${settledItems.length})
            </button>
          </div>

          <!-- Farmer Cards List (Matching Image 1 & Image 3) -->
          <div class="space-y-3.5">
            ${filtered.length === 0 ? `
              <div class="p-8 text-center text-slate-400 bg-slate-50 rounded-2xl border border-slate-200 text-xs">
                No DBT records matching your search.
              </div>
            ` : filtered.map(item => {
              const isSettled = item.status === 'Settled' || item.status === 'Success';
              const amt = Number(item.amount) || 0;
              return `
                <div class="p-5 rounded-2xl border border-slate-200 bg-white hover:border-slate-300 transition space-y-3">
                  <!-- Top Token & Txn ID -->
                  <div class="flex items-center justify-between text-xs">
                    <span class="font-mono font-black text-slate-800">${item.token}</span>
                    <span class="font-mono font-bold text-slate-400 text-[11px]">${item.txnRef || 'PF-TXN-1000'}</span>
                  </div>

                  <!-- Farmer & Location -->
                  <div>
                    <h4 class="font-black text-slate-900 text-sm sm:text-base">${item.farmer} <span class="text-xs font-normal text-slate-500">(${item.location || 'Baramati'})</span></h4>
                  </div>

                  <!-- Bank & Account Details -->
                  <div class="text-xs space-y-1 text-slate-600">
                    <div class="flex items-center gap-1.5 font-bold text-slate-800">
                      <span>🏛️</span>
                      <span>${item.bank || 'State Bank of India (Baramati)'}</span>
                    </div>
                    <div class="text-slate-500 font-mono text-[11px]">
                      A/c: <strong>${item.account || '••••4837'}</strong> • IFSC: <strong>${item.ifsc || 'SBIN0000324'}</strong> • 
                      <span class="text-emerald-700 font-sans font-bold">Aadhaar Linked</span>
                    </div>
                  </div>

                  <!-- Bottom Row: Amount & Action Button -->
                  <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 pt-2 border-t border-slate-100">
                    <div class="flex items-center gap-2">
                      <span class="text-base sm:text-lg font-black font-mono text-slate-900">
                        ₹${amt.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                      </span>
                      <span class="px-2 py-0.5 rounded-full text-[10px] font-bold ${isSettled ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'}">
                        ${isSettled ? 'Settled' : 'Processing'}
                      </span>
                    </div>

                    <div>
                      ${isSettled ? `
                        <div class="flex items-center gap-2 text-xs">
                          <span class="px-3 py-1.5 rounded-xl bg-slate-100 text-slate-600 font-mono text-[11px] font-bold">
                            UTR: ${item.utr || 'PFMS' + Date.now().toString().slice(-7)}
                          </span>
                          <span class="text-emerald-600 font-bold text-xs">✅ Credited</span>
                        </div>
                      ` : `
                        <button onclick="CenterDesk.openDbtModal('${item.token}')" class="px-4 py-2 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs shadow-xs flex items-center gap-1.5 transition">
                          <span>🏛️</span>
                          <span>Govt Bank Transfer</span>
                        </button>
                      `}
                    </div>
                  </div>
                </div>
              `;
            }).join('')}
          </div>

        </div>
      </div>
    `;
  }
}

window.CenterDesk = new CenterDeskController();
