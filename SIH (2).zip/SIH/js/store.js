/**
 * KisanSetu - Centralized Reactive State Store
 * Synchronizes state across Farmer Portal, Center Official Desk, and District Command Center.
 * Supports 7 Indian Languages, Real Crop Transportation Vehicles, and Role-Based Authentication.
 */

const STORAGE_KEY = 'KISANSETU_APP_STATE_V7';

// Official Vector Vehicle Logos Generator (Clean SVG Emblems)
function getVehicleSvgLogo(name, size = 28) {
  const n = (name || '').toLowerCase();
  const cls = `w-${size <= 24 ? '6' : '7'} h-${size <= 24 ? '6' : '7'}`;

  if (n.includes('heavy') || (n.includes('tractor') && n.includes('4-wheel'))) {
    // Tractor Heavy (4-Wheel Heavy Duty) Logo
    return `<svg class="${cls}" viewBox="0 0 32 32" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
      <path d="M3 13h9v7H3z" fill="currentColor" fill-opacity="0.18"/>
      <circle cx="5.5" cy="22.5" r="2.5" fill="currentColor" fill-opacity="0.3"/>
      <circle cx="10" cy="22.5" r="2.5" fill="currentColor" fill-opacity="0.3"/>
      <path d="M12 17h3"/>
      <circle cx="19" cy="21.5" r="4.5" fill="currentColor" fill-opacity="0.3"/>
      <circle cx="19" cy="21.5" r="1.5" fill="currentColor"/>
      <circle cx="28" cy="23" r="2.5" fill="currentColor" fill-opacity="0.3"/>
      <path d="M16 17v-8h5.5v8h6.5v3.5h-2"/>
      <path d="M21.5 9V5.5"/>
    </svg>`;
  } else if (n.includes('tractor')) {
    // Tractor Trolley (2-Wheel Standard) Logo
    return `<svg class="${cls}" viewBox="0 0 32 32" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
      <path d="M4 14h7v6H4z" fill="currentColor" fill-opacity="0.18"/>
      <circle cx="7.5" cy="22" r="2.5" fill="currentColor" fill-opacity="0.3"/>
      <path d="M11 17h4"/>
      <circle cx="19" cy="21.5" r="4.5" fill="currentColor" fill-opacity="0.3"/>
      <circle cx="19" cy="21.5" r="1.5" fill="currentColor"/>
      <circle cx="27.5" cy="23" r="2.5" fill="currentColor" fill-opacity="0.3"/>
      <path d="M16 17v-7h5v7h6.5v3.5h-2"/>
      <path d="M21 10V6"/>
    </svg>`;
  } else if (n.includes('pickup') || n.includes('bolero')) {
    // Pickup / Bolero Maxi Truck Logo
    return `<svg class="${cls}" viewBox="0 0 32 32" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
      <path d="M3 14h11v6H3z" fill="currentColor" fill-opacity="0.18"/>
      <path d="M14 14h6l4 3.5v2.5h-10v-6z" fill="currentColor" fill-opacity="0.22"/>
      <circle cx="8" cy="22.5" r="2.8" fill="currentColor" fill-opacity="0.3"/>
      <circle cx="22" cy="22.5" r="2.8" fill="currentColor" fill-opacity="0.3"/>
      <path d="M11 22.5h8M3 20v-6M24 20h4.5v-2l-2.5-2H20"/>
    </svg>`;
  } else if (n.includes('6-tyre') || n.includes('medium') || (n.includes('truck') && !n.includes('pickup') && !n.includes('heavy') && !n.includes('hauler'))) {
    // Medium Truck (6-Tyre Eicher/Tata) Logo
    return `<svg class="${cls}" viewBox="0 0 32 32" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
      <path d="M3 10h15v10H3z" fill="currentColor" fill-opacity="0.18"/>
      <path d="M18 13h5.5l4 3.5v3.5h-9.5V13z" fill="currentColor" fill-opacity="0.22"/>
      <circle cx="7" cy="22.5" r="2.7" fill="currentColor" fill-opacity="0.3"/>
      <circle cx="14" cy="22.5" r="2.7" fill="currentColor" fill-opacity="0.3"/>
      <circle cx="24" cy="22.5" r="2.7" fill="currentColor" fill-opacity="0.3"/>
      <path d="M10 22.5h1.2M17 22.5h4.2M27 20h2"/>
    </svg>`;
  } else if (n.includes('heavy') || n.includes('hauler') || n.includes('multi-axle') || n.includes('10-14')) {
    // Heavy Multi-Axle Hauler (10-14 Tyre) Logo
    return `<svg class="${cls}" viewBox="0 0 32 32" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
      <path d="M2 9h16v11H2z" fill="currentColor" fill-opacity="0.18"/>
      <path d="M18 11h6.5l4 4.5v4.5h-10.5V11z" fill="currentColor" fill-opacity="0.22"/>
      <circle cx="5" cy="22.5" r="2.5" fill="currentColor" fill-opacity="0.3"/>
      <circle cx="10" cy="22.5" r="2.5" fill="currentColor" fill-opacity="0.3"/>
      <circle cx="15" cy="22.5" r="2.5" fill="currentColor" fill-opacity="0.3"/>
      <circle cx="25" cy="22.5" r="2.5" fill="currentColor" fill-opacity="0.3"/>
      <path d="M7.5 22.5h0.2M12.5 22.5h0.2M17.5 22.5h5M27.5 20h2.5"/>
    </svg>`;
  } else {
    // Bullock Cart (Bail Gaadi / Traditional) Logo
    return `<svg class="${cls}" viewBox="0 0 32 32" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
      <circle cx="11" cy="20.5" r="5" fill="currentColor" fill-opacity="0.2"/>
      <circle cx="11" cy="20.5" r="1.5" fill="currentColor"/>
      <path d="M11 15.5v10M6 20.5h10M7.5 17l7 7M7.5 24l7-7" stroke-width="1.2"/>
      <path d="M4 15h14l8-2.5v3h-4"/>
      <path d="M22 13.5c1.5-2.5 3.5-2.5 4.5-.5s1.5 2.5 1 4-3.5 2-5.5 1"/>
      <path d="M25 10.5l2-2.5M27.5 12l2.5-.5"/>
    </svg>`;
  }
}
window.getVehicleSvgLogo = getVehicleSvgLogo;

// 6 Real Agricultural Crop Transportation Vehicles
const REAL_FARM_VEHICLES = [
  { id: 'tractor_trolley', name: 'Tractor Trolley (2-Wheel)', icon: '🚜', capacityQtl: '30 - 50 Qtl', type: 'Tractor Trolley', lane: 'Lane TT-01' },
  { id: 'tractor_heavy', name: 'Tractor Trolley (4-Wheel Heavy)', icon: '🚜', capacityQtl: '60 - 100 Qtl', type: 'Tractor Heavy', lane: 'Lane TH-02' },
  { id: 'pickup_bolero', name: 'Pickup / Bolero Maxi Truck', icon: '🛻', capacityQtl: '20 - 35 Qtl', type: 'Pickup Truck', lane: 'Lane PK-01' },
  { id: 'truck_6tyre', name: 'Medium Truck (6-Tyre Eicher/Tata)', icon: '🚚', capacityQtl: '90 - 140 Qtl', type: '6-Tyre Truck', lane: 'Lane TR-03' },
  { id: 'truck_heavy', name: 'Heavy Multi-Axle Hauler (10-14 Tyre)', icon: '🚛', capacityQtl: '200 - 350 Qtl', type: 'Heavy Hauler', lane: 'Lane HH-01' },
  { id: 'bullock_cart', name: 'Bullock Cart (Bail Gaadi / Traditional)', icon: '🐂', capacityQtl: '10 - 18 Qtl', type: 'Bullock Cart', lane: 'Lane BC-01' }
];

// Comprehensive Pan-India States & Districts Directory
const INDIAN_STATES = [
  { id: 'all', name: 'All India', zone: 'National', code: 'IN' },
  { 
    id: 'Maharashtra', 
    name: 'Maharashtra', 
    nativeName: 'महाराष्ट्र', 
    zone: 'West', 
    regionalLang: 'mr', 
    code: 'MH', 
    districts: [
      'Ahmednagar (Ahilyanagar)',
      'Akola',
      'Amravati',
      'Chhatrapati Sambhaji Nagar (Aurangabad)',
      'Beed',
      'Bhandara',
      'Buldhana',
      'Chandrapur',
      'Dhule',
      'Gadchiroli',
      'Gondia',
      'Hingoli',
      'Jalgaon',
      'Jalna',
      'Kolhapur',
      'Latur',
      'Mumbai City',
      'Mumbai Suburban',
      'Nagpur',
      'Nanded',
      'Nandurbar',
      'Nashik',
      'Dharashiv (Osmanabad)',
      'Palghar',
      'Parbhani',
      'Pune',
      'Raigad',
      'Ratnagiri',
      'Sangli',
      'Satara',
      'Sindhudurg',
      'Solapur',
      'Thane',
      'Wardha',
      'Washim',
      'Yavatmal'
    ] 
  },
  { id: 'Punjab', name: 'Punjab', zone: 'North', regionalLang: 'pa', code: 'PB', districts: ['Ludhiana', 'Khanna', 'Bathinda', 'Amritsar', 'Jalandhar', 'Patiala', 'Sangrur', 'Firozpur', 'Moga'] },
  { id: 'Madhya Pradesh', name: 'Madhya Pradesh', zone: 'Central', regionalLang: 'hi', code: 'MP', districts: ['Indore', 'Ujjain', 'Dewas', 'Bhopal', 'Sehore', 'Hoshangabad', 'Dhar', 'Khandwa', 'Khargone', 'Gwalior'] },
  { id: 'Gujarat', name: 'Gujarat', zone: 'West', regionalLang: 'gu', code: 'GJ', districts: ['Mehsana', 'Rajkot', 'Gondal', 'Surat', 'Ahmedabad', 'Amreli', 'Junagadh', 'Bhavnagar', 'Vadodara', 'Patan'] },
  { id: 'Uttar Pradesh', name: 'Uttar Pradesh', zone: 'North', regionalLang: 'hi', code: 'UP', districts: ['Muzaffarnagar', 'Bareilly', 'Varanasi', 'Aligarh', 'Mathura', 'Meerut', 'Agra', 'Gorakhpur', 'Prayagraj', 'Kanpur'] },
  { id: 'Haryana', name: 'Haryana', zone: 'North', regionalLang: 'hi', code: 'HR', districts: ['Karnal', 'Kurukshetra', 'Sirsa', 'Ambala', 'Rohtak', 'Hisar', 'Panipat', 'Fatehabad', 'Jind'] },
  { id: 'Rajasthan', name: 'Rajasthan', zone: 'North', regionalLang: 'hi', code: 'RJ', districts: ['Kota', 'Sri Ganganagar', 'Jaipur', 'Bikaner', 'Jodhpur', 'Alwar', 'Hanumangarh', 'Baran', 'Nagaur'] },
  { id: 'West Bengal', name: 'West Bengal', zone: 'East', regionalLang: 'bn', code: 'WB', districts: ['Burdwan', 'Hooghly', 'Siliguri', 'Nadia', 'Murshidabad', 'North 24 Parganas', 'Malda', 'Bankura'] },
  { id: 'Tamil Nadu', name: 'Tamil Nadu', zone: 'South', regionalLang: 'ta', code: 'TN', districts: ['Erode', 'Thanjavur', 'Coimbatore', 'Madurai', 'Salem', 'Tiruppur', 'Dindigul', 'Tiruchirappalli', 'Tirunelveli'] },
  { id: 'Karnataka', name: 'Karnataka', zone: 'South', regionalLang: 'en', code: 'KA', districts: ['Hubballi-Dharwad', 'Davanagere', 'Shimoga', 'Mysuru', 'Belagavi', 'Bellary', 'Raichur', 'Haveri', 'Kalaburagi'] },
  { id: 'Andhra Pradesh', name: 'Andhra Pradesh', zone: 'South', regionalLang: 'en', code: 'AP', districts: ['Guntur', 'Vijayawada', 'Kurnool', 'Anantapur', 'Nellore', 'Chittoor', 'Eluru'] },
  { id: 'Telangana', name: 'Telangana', zone: 'South', regionalLang: 'en', code: 'TS', districts: ['Warangal', 'Nizamabad', 'Khammam', 'Karimnagar', 'Nalgonda', 'Mahabubnagar'] },
  { id: 'Bihar', name: 'Bihar', zone: 'East', regionalLang: 'hi', code: 'BR', districts: ['Purnea', 'Patna', 'Muzaffarpur', 'Bhagalpur', 'Gaya', 'Begusarai', 'Samastipur'] },
  { id: 'Odisha', name: 'Odisha', zone: 'East', regionalLang: 'en', code: 'OD', districts: ['Bargarh', 'Sambalpur', 'Cuttack', 'Balasore', 'Bhadrak', 'Ganjam'] },
  { id: 'Chhattisgarh', name: 'Chhattisgarh', zone: 'Central', regionalLang: 'hi', code: 'CG', districts: ['Raipur', 'Rajnandgaon', 'Bilaspur', 'Durg', 'Dhamtari', 'Bhatapara'] },
  { id: 'Kerala', name: 'Kerala', zone: 'South', regionalLang: 'en', code: 'KL', districts: ['Palakkad', 'Wayanad', 'Idukki', 'Kottayam', 'Kozhikode', 'Thrissur'] }
];

// All-India APMC Mandi Network with Real-Time Congestion Telemetrics
const ALL_INDIA_MANDIS = [
  // =========================================================================
  // Maharashtra - Comprehensive Procurement Centers Across All Districts
  // =========================================================================
  {
    id: 'mandi_pune',
    name: 'Pune APMC (Gultekdi Central Market Yard)',
    state: 'Maharashtra',
    district: 'Pune',
    zone: 'West',
    distanceKm: '4.2 km',
    congestionLevel: 'moderate',
    heatScore: 64,
    waitMins: 28,
    vehiclesInQueue: 34,
    activeBays: '10 / 12',
    dailyArrivalTons: 2800,
    storageCapacityMT: 25000,
    currentStockMT: 17200,
    primaryCrops: ['Wheat', 'Soybean', 'Chana', 'Jowar', 'Vegetables'],
    mspHighlight: 'Wheat ₹2,275 • Soybean ₹4,850 • Chana ₹5,440',
    statusTag: 'Steady Flow (मध्यम गर्दी)'
  },
  {
    id: 'mandi_baramati',
    name: 'Baramati APMC (Govt MSP Grain & Oilseeds Hub)',
    state: 'Maharashtra',
    district: 'Pune',
    zone: 'West',
    distanceKm: '3.1 km',
    congestionLevel: 'low',
    heatScore: 24,
    waitMins: 14,
    vehiclesInQueue: 11,
    activeBays: '8 / 8',
    dailyArrivalTons: 1650,
    storageCapacityMT: 22000,
    currentStockMT: 9100,
    primaryCrops: ['Soybean', 'Wheat', 'Gram / Chana', 'Bajra'],
    mspHighlight: 'Soybean ₹4,850 • Gram ₹5,440',
    statusTag: 'Smooth Flow (सुरळीत)'
  },
  {
    id: 'mandi_lasalgaon',
    name: 'Lasalgaon APMC (Asia’s Onion & Grain Hub)',
    state: 'Maharashtra',
    district: 'Nashik',
    zone: 'West',
    distanceKm: '3.8 km',
    congestionLevel: 'low',
    heatScore: 28,
    waitMins: 18,
    vehiclesInQueue: 14,
    activeBays: '7 / 8',
    dailyArrivalTons: 1420,
    storageCapacityMT: 18000,
    currentStockMT: 8200,
    primaryCrops: ['Soybean', 'Wheat', 'Maize', 'Onion'],
    mspHighlight: 'Wheat ₹2,275 • Soybean ₹4,850 • Maize ₹2,090',
    statusTag: 'Smooth Flow (सुरळीत)'
  },
  {
    id: 'mandi_pimpalgaon',
    name: 'Pimpalgaon Baswant APMC (MSP Grain & Tomato Terminal)',
    state: 'Maharashtra',
    district: 'Nashik',
    zone: 'West',
    distanceKm: '5.4 km',
    congestionLevel: 'moderate',
    heatScore: 58,
    waitMins: 26,
    vehiclesInQueue: 28,
    activeBays: '9 / 10',
    dailyArrivalTons: 2200,
    storageCapacityMT: 20000,
    currentStockMT: 13500,
    primaryCrops: ['Soybean', 'Wheat', 'Chana', 'Maize'],
    mspHighlight: 'Soybean ₹4,850 • Wheat ₹2,275',
    statusTag: 'Normal Flow (नियमित)'
  },
  {
    id: 'mandi_malegaon',
    name: 'Malegaon APMC (Khandesh Grain & Cotton Yard)',
    state: 'Maharashtra',
    district: 'Nashik',
    zone: 'West',
    distanceKm: '6.8 km',
    congestionLevel: 'moderate',
    heatScore: 62,
    waitMins: 32,
    vehiclesInQueue: 36,
    activeBays: '8 / 10',
    dailyArrivalTons: 1950,
    storageCapacityMT: 19000,
    currentStockMT: 14100,
    primaryCrops: ['Cotton', 'Soybean', 'Bajra', 'Wheat'],
    mspHighlight: 'Cotton ₹7,121 • Bajra ₹2,500',
    statusTag: 'Steady Intake (स्थिर आवक)'
  },
  {
    id: 'mandi_nagpur',
    name: 'Nagpur APMC (Kalamna Central Market Yard)',
    state: 'Maharashtra',
    district: 'Nagpur',
    zone: 'West',
    distanceKm: '7.1 km',
    congestionLevel: 'low',
    heatScore: 32,
    waitMins: 20,
    vehiclesInQueue: 18,
    activeBays: '8 / 10',
    dailyArrivalTons: 2100,
    storageCapacityMT: 30000,
    currentStockMT: 12000,
    primaryCrops: ['Soybean', 'Paddy / Rice', 'Cotton', 'Chana'],
    mspHighlight: 'Soybean ₹4,850 • Paddy ₹2,183 • Cotton ₹7,121',
    statusTag: 'Smooth Flow (सुरळीत)'
  },
  {
    id: 'mandi_katol',
    name: 'Katol APMC (Nagpur Rural Grain & Citrus Hub)',
    state: 'Maharashtra',
    district: 'Nagpur',
    zone: 'West',
    distanceKm: '8.4 km',
    congestionLevel: 'low',
    heatScore: 22,
    waitMins: 12,
    vehiclesInQueue: 9,
    activeBays: '6 / 6',
    dailyArrivalTons: 1100,
    storageCapacityMT: 14000,
    currentStockMT: 5200,
    primaryCrops: ['Soybean', 'Paddy', 'Chana', 'Tur'],
    mspHighlight: 'Soybean ₹4,850 • Chana ₹5,440',
    statusTag: 'Fast Clearance (जलद तपासणी)'
  },
  {
    id: 'mandi_latur',
    name: 'Latur APMC (Marathwada Pulses & Oilseeds Hub)',
    state: 'Maharashtra',
    district: 'Latur',
    zone: 'West',
    distanceKm: '4.5 km',
    congestionLevel: 'high',
    heatScore: 88,
    waitMins: 58,
    vehiclesInQueue: 72,
    activeBays: '8 / 8 (Full)',
    dailyArrivalTons: 3900,
    storageCapacityMT: 22000,
    currentStockMT: 20400,
    primaryCrops: ['Soybean', 'Chana', 'Tur / Arhar', 'Urad'],
    mspHighlight: 'Soybean ₹4,850 • Tur ₹7,000 • Chana ₹5,440',
    statusTag: 'Heavy Jam (गोदाम ९२% भरले)',
    detour: 'Latur Godown 92% full. Diversion to Ausa Sub-yard recommended.'
  },
  {
    id: 'mandi_solapur',
    name: 'Solapur APMC (Siddheshwar Market Yard - Jowar & Pulses)',
    state: 'Maharashtra',
    district: 'Solapur',
    zone: 'West',
    distanceKm: '5.0 km',
    congestionLevel: 'low',
    heatScore: 30,
    waitMins: 16,
    vehiclesInQueue: 15,
    activeBays: '9 / 10',
    dailyArrivalTons: 2400,
    storageCapacityMT: 24000,
    currentStockMT: 10800,
    primaryCrops: ['Jowar', 'Soybean', 'Chana', 'Tur', 'Wheat'],
    mspHighlight: 'Jowar ₹3,180 • Soybean ₹4,850',
    statusTag: 'Smooth Clearance (सुरळीत)'
  },
  {
    id: 'mandi_kolhapur',
    name: 'Kolhapur APMC (Shahu Market Yard - Jaggery & Grain)',
    state: 'Maharashtra',
    district: 'Kolhapur',
    zone: 'West',
    distanceKm: '4.8 km',
    congestionLevel: 'moderate',
    heatScore: 54,
    waitMins: 24,
    vehiclesInQueue: 25,
    activeBays: '10 / 12',
    dailyArrivalTons: 2600,
    storageCapacityMT: 26000,
    currentStockMT: 15200,
    primaryCrops: ['Paddy / Rice', 'Soybean', 'Jowar', 'Groundnut'],
    mspHighlight: 'Paddy ₹2,183 • Soybean ₹4,850',
    statusTag: 'Normal Flow (नियमित)'
  },
  {
    id: 'mandi_ahmednagar',
    name: 'Ahmednagar APMC (Ahilyanagar Central Grain Mandi)',
    state: 'Maharashtra',
    district: 'Ahmednagar (Ahilyanagar)',
    zone: 'West',
    distanceKm: '3.6 km',
    congestionLevel: 'low',
    heatScore: 26,
    waitMins: 15,
    vehiclesInQueue: 13,
    activeBays: '8 / 8',
    dailyArrivalTons: 1750,
    storageCapacityMT: 21000,
    currentStockMT: 8900,
    primaryCrops: ['Bajra', 'Soybean', 'Wheat', 'Gram', 'Jowar'],
    mspHighlight: 'Bajra ₹2,500 • Soybean ₹4,850',
    statusTag: 'Smooth Flow (सुरळीत)'
  },
  {
    id: 'mandi_rahuri',
    name: 'Rahuri APMC (Mahatma Phule MSP Procurement Center)',
    state: 'Maharashtra',
    district: 'Ahmednagar (Ahilyanagar)',
    zone: 'West',
    distanceKm: '6.2 km',
    congestionLevel: 'low',
    heatScore: 20,
    waitMins: 10,
    vehiclesInQueue: 8,
    activeBays: '6 / 6',
    dailyArrivalTons: 1200,
    storageCapacityMT: 16000,
    currentStockMT: 5800,
    primaryCrops: ['Wheat', 'Soybean', 'Chana', 'Maize'],
    mspHighlight: 'Wheat ₹2,275 • Soybean ₹4,850',
    statusTag: 'Fast Gate Pass (जलद प्रवेश)'
  },
  {
    id: 'mandi_csn',
    name: 'Chhatrapati Sambhaji Nagar APMC (Jadhavwadi Market Yard)',
    state: 'Maharashtra',
    district: 'Chhatrapati Sambhaji Nagar (Aurangabad)',
    zone: 'West',
    distanceKm: '5.1 km',
    congestionLevel: 'moderate',
    heatScore: 60,
    waitMins: 30,
    vehiclesInQueue: 32,
    activeBays: '8 / 10',
    dailyArrivalTons: 2300,
    storageCapacityMT: 25000,
    currentStockMT: 16800,
    primaryCrops: ['Cotton', 'Soybean', 'Maize', 'Bajra', 'Wheat'],
    mspHighlight: 'Cotton ₹7,121 • Maize ₹2,090',
    statusTag: 'Steady Flow (मध्यम गर्दी)'
  },
  {
    id: 'mandi_jalgaon',
    name: 'Jalgaon APMC (Khandesh Cotton, Maize & Pulse Terminal)',
    state: 'Maharashtra',
    district: 'Jalgaon',
    zone: 'West',
    distanceKm: '4.9 km',
    congestionLevel: 'moderate',
    heatScore: 56,
    waitMins: 25,
    vehiclesInQueue: 29,
    activeBays: '9 / 10',
    dailyArrivalTons: 2500,
    storageCapacityMT: 27000,
    currentStockMT: 16000,
    primaryCrops: ['Cotton', 'Maize', 'Soybean', 'Chana', 'Wheat'],
    mspHighlight: 'Cotton ₹7,121 • Maize ₹2,090 • Soybean ₹4,850',
    statusTag: 'Normal Flow (नियमित)'
  },
  {
    id: 'mandi_amravati',
    name: 'Amravati APMC (Cotton & Soybean Procurement Center)',
    state: 'Maharashtra',
    district: 'Amravati',
    zone: 'West',
    distanceKm: '4.3 km',
    congestionLevel: 'moderate',
    heatScore: 68,
    waitMins: 35,
    vehiclesInQueue: 41,
    activeBays: '8 / 10',
    dailyArrivalTons: 3100,
    storageCapacityMT: 28000,
    currentStockMT: 20100,
    primaryCrops: ['Soybean', 'Cotton', 'Tur / Arhar', 'Chana'],
    mspHighlight: 'Soybean ₹4,850 • Tur ₹7,000',
    statusTag: 'Heavy Harvest Rush (कापूस व सोयाबीन)'
  },
  {
    id: 'mandi_nanded',
    name: 'Nanded APMC (Cotton & Turmeric Procurement Yard)',
    state: 'Maharashtra',
    district: 'Nanded',
    zone: 'West',
    distanceKm: '5.7 km',
    congestionLevel: 'low',
    heatScore: 34,
    waitMins: 19,
    vehiclesInQueue: 17,
    activeBays: '8 / 8',
    dailyArrivalTons: 2000,
    storageCapacityMT: 22000,
    currentStockMT: 10400,
    primaryCrops: ['Cotton', 'Soybean', 'Turmeric', 'Chana', 'Jowar'],
    mspHighlight: 'Cotton ₹7,121 • Soybean ₹4,850',
    statusTag: 'Smooth Flow (सुरळीत)'
  },
  {
    id: 'mandi_sangli',
    name: 'Sangli APMC (Vasantdada Market Yard - Turmeric & Soybean)',
    state: 'Maharashtra',
    district: 'Sangli',
    zone: 'West',
    distanceKm: '4.4 km',
    congestionLevel: 'low',
    heatScore: 28,
    waitMins: 16,
    vehiclesInQueue: 14,
    activeBays: '9 / 10',
    dailyArrivalTons: 2200,
    storageCapacityMT: 23000,
    currentStockMT: 9800,
    primaryCrops: ['Soybean', 'Turmeric', 'Jowar', 'Maize', 'Wheat'],
    mspHighlight: 'Soybean ₹4,850 • Turmeric Mandi Benchmark',
    statusTag: 'Smooth Flow (सुरळीत)'
  },
  {
    id: 'mandi_satara',
    name: 'Satara APMC (Wai-Satara MSP Grain Yard)',
    state: 'Maharashtra',
    district: 'Satara',
    zone: 'West',
    distanceKm: '3.9 km',
    congestionLevel: 'low',
    heatScore: 22,
    waitMins: 13,
    vehiclesInQueue: 10,
    activeBays: '7 / 8',
    dailyArrivalTons: 1450,
    storageCapacityMT: 17000,
    currentStockMT: 6500,
    primaryCrops: ['Wheat', 'Soybean', 'Jowar', 'Gram'],
    mspHighlight: 'Wheat ₹2,275 • Soybean ₹4,850',
    statusTag: 'Smooth Clearance (सुरळीत)'
  },
  {
    id: 'mandi_karad',
    name: 'Karad APMC (Western Maharashtra MSP Center)',
    state: 'Maharashtra',
    district: 'Satara',
    zone: 'West',
    distanceKm: '6.1 km',
    congestionLevel: 'low',
    heatScore: 25,
    waitMins: 15,
    vehiclesInQueue: 12,
    activeBays: '8 / 8',
    dailyArrivalTons: 1600,
    storageCapacityMT: 18000,
    currentStockMT: 7800,
    primaryCrops: ['Soybean', 'Wheat', 'Groundnut', 'Jowar'],
    mspHighlight: 'Soybean ₹4,850 • Wheat ₹2,275',
    statusTag: 'Normal Flow (नियमित)'
  },
  {
    id: 'mandi_akola',
    name: 'Akola APMC (Vidarbha Pulses & Cotton Terminal)',
    state: 'Maharashtra',
    district: 'Akola',
    zone: 'West',
    distanceKm: '4.7 km',
    congestionLevel: 'moderate',
    heatScore: 62,
    waitMins: 31,
    vehiclesInQueue: 35,
    activeBays: '8 / 10',
    dailyArrivalTons: 2700,
    storageCapacityMT: 26000,
    currentStockMT: 17800,
    primaryCrops: ['Cotton', 'Soybean', 'Chana', 'Tur', 'Wheat'],
    mspHighlight: 'Cotton ₹7,121 • Tur ₹7,000 • Soybean ₹4,850',
    statusTag: 'Steady Intake (स्थिर आवक)'
  },
  {
    id: 'mandi_jalna',
    name: 'Jalna APMC (Seed Capital MSP Grain Hub)',
    state: 'Maharashtra',
    district: 'Jalna',
    zone: 'West',
    distanceKm: '5.2 km',
    congestionLevel: 'low',
    heatScore: 32,
    waitMins: 18,
    vehiclesInQueue: 16,
    activeBays: '8 / 8',
    dailyArrivalTons: 1900,
    storageCapacityMT: 21000,
    currentStockMT: 10200,
    primaryCrops: ['Soybean', 'Cotton', 'Bajra', 'Wheat', 'Chana'],
    mspHighlight: 'Soybean ₹4,850 • Cotton ₹7,121',
    statusTag: 'Smooth Flow (सुरळीत)'
  },
  {
    id: 'mandi_dhule',
    name: 'Dhule APMC (North Maharashtra Grain & Chana Hub)',
    state: 'Maharashtra',
    district: 'Dhule',
    zone: 'West',
    distanceKm: '4.0 km',
    congestionLevel: 'low',
    heatScore: 26,
    waitMins: 15,
    vehiclesInQueue: 13,
    activeBays: '8 / 8',
    dailyArrivalTons: 1800,
    storageCapacityMT: 20000,
    currentStockMT: 8600,
    primaryCrops: ['Wheat', 'Bajra', 'Cotton', 'Chana', 'Maize'],
    mspHighlight: 'Wheat ₹2,275 • Chana ₹5,440',
    statusTag: 'Smooth Flow (सुरळीत)'
  },
  {
    id: 'mandi_yavatmal',
    name: 'Yavatmal APMC (Vidarbha Cotton & Soybean Yard)',
    state: 'Maharashtra',
    district: 'Yavatmal',
    zone: 'West',
    distanceKm: '5.5 km',
    congestionLevel: 'moderate',
    heatScore: 66,
    waitMins: 34,
    vehiclesInQueue: 38,
    activeBays: '8 / 10',
    dailyArrivalTons: 2800,
    storageCapacityMT: 24000,
    currentStockMT: 18100,
    primaryCrops: ['Cotton', 'Soybean', 'Tur', 'Gram'],
    mspHighlight: 'Cotton ₹7,121 • Soybean ₹4,850',
    statusTag: 'Peak Cotton Harvest (कापूस आवक)'
  },
  {
    id: 'mandi_beed',
    name: 'Beed APMC (Marathwada Bajra & Soybean Center)',
    state: 'Maharashtra',
    district: 'Beed',
    zone: 'West',
    distanceKm: '4.6 km',
    congestionLevel: 'low',
    heatScore: 30,
    waitMins: 17,
    vehiclesInQueue: 15,
    activeBays: '7 / 8',
    dailyArrivalTons: 1650,
    storageCapacityMT: 19000,
    currentStockMT: 8900,
    primaryCrops: ['Bajra', 'Soybean', 'Cotton', 'Chana', 'Tur'],
    mspHighlight: 'Bajra ₹2,500 • Soybean ₹4,850',
    statusTag: 'Smooth Flow (सुरळीत)'
  },
  {
    id: 'mandi_buldhana',
    name: 'Buldhana APMC (Malkapur Cotton & Grain Yard)',
    state: 'Maharashtra',
    district: 'Buldhana',
    zone: 'West',
    distanceKm: '6.0 km',
    congestionLevel: 'low',
    heatScore: 29,
    waitMins: 16,
    vehiclesInQueue: 14,
    activeBays: '8 / 8',
    dailyArrivalTons: 1700,
    storageCapacityMT: 19500,
    currentStockMT: 9300,
    primaryCrops: ['Cotton', 'Soybean', 'Wheat', 'Chana', 'Maize'],
    mspHighlight: 'Cotton ₹7,121 • Soybean ₹4,850',
    statusTag: 'Smooth Flow (सुरळीत)'
  },
  {
    id: 'mandi_wardha',
    name: 'Wardha APMC (Hinganghat Cotton & Pulses Mandi)',
    state: 'Maharashtra',
    district: 'Wardha',
    zone: 'West',
    distanceKm: '5.8 km',
    congestionLevel: 'low',
    heatScore: 31,
    waitMins: 17,
    vehiclesInQueue: 15,
    activeBays: '8 / 8',
    dailyArrivalTons: 1850,
    storageCapacityMT: 21000,
    currentStockMT: 9900,
    primaryCrops: ['Cotton', 'Soybean', 'Chana', 'Wheat'],
    mspHighlight: 'Cotton ₹7,121 • Soybean ₹4,850',
    statusTag: 'Smooth Flow (सुरळीत)'
  },
  {
    id: 'mandi_chandrapur',
    name: 'Chandrapur APMC (Vidarbha Paddy & Grain Hub)',
    state: 'Maharashtra',
    district: 'Chandrapur',
    zone: 'West',
    distanceKm: '6.5 km',
    congestionLevel: 'low',
    heatScore: 27,
    waitMins: 15,
    vehiclesInQueue: 12,
    activeBays: '7 / 8',
    dailyArrivalTons: 1550,
    storageCapacityMT: 18500,
    currentStockMT: 8100,
    primaryCrops: ['Paddy / Rice', 'Cotton', 'Soybean', 'Wheat'],
    mspHighlight: 'Paddy ₹2,183 • Cotton ₹7,121',
    statusTag: 'Smooth Flow (सुरळीत)'
  },
  {
    id: 'mandi_dharashiv',
    name: 'Dharashiv APMC (Osmanabad Pulses & Oilseeds Center)',
    state: 'Maharashtra',
    district: 'Dharashiv (Osmanabad)',
    zone: 'West',
    distanceKm: '4.8 km',
    congestionLevel: 'low',
    heatScore: 28,
    waitMins: 16,
    vehiclesInQueue: 13,
    activeBays: '7 / 8',
    dailyArrivalTons: 1600,
    storageCapacityMT: 18000,
    currentStockMT: 8400,
    primaryCrops: ['Soybean', 'Chana', 'Tur', 'Jowar'],
    mspHighlight: 'Soybean ₹4,850 • Tur ₹7,000',
    statusTag: 'Smooth Flow (सुरळीत)'
  },
  {
    id: 'mandi_parbhani',
    name: 'Parbhani APMC (Marathwada Cotton & Jowar Mandi)',
    state: 'Maharashtra',
    district: 'Parbhani',
    zone: 'West',
    distanceKm: '5.3 km',
    congestionLevel: 'moderate',
    heatScore: 52,
    waitMins: 24,
    vehiclesInQueue: 24,
    activeBays: '8 / 8',
    dailyArrivalTons: 1950,
    storageCapacityMT: 20000,
    currentStockMT: 12800,
    primaryCrops: ['Cotton', 'Soybean', 'Jowar', 'Chana'],
    mspHighlight: 'Cotton ₹7,121 • Jowar ₹3,180',
    statusTag: 'Normal Flow (नियमित)'
  },
  {
    id: 'mandi_washim',
    name: 'Washim APMC (Risod Soybean & Wheat Yard)',
    state: 'Maharashtra',
    district: 'Washim',
    zone: 'West',
    distanceKm: '4.2 km',
    congestionLevel: 'low',
    heatScore: 25,
    waitMins: 14,
    vehiclesInQueue: 11,
    activeBays: '7 / 8',
    dailyArrivalTons: 1500,
    storageCapacityMT: 17500,
    currentStockMT: 7600,
    primaryCrops: ['Soybean', 'Wheat', 'Chana', 'Tur'],
    mspHighlight: 'Soybean ₹4,850 • Wheat ₹2,275',
    statusTag: 'Smooth Flow (सुरळीत)'
  },
  {
    id: 'mandi_nandurbar',
    name: 'Nandurbar APMC (Tribal MSP Grain & Red Chili Terminal)',
    state: 'Maharashtra',
    district: 'Nandurbar',
    zone: 'West',
    distanceKm: '5.9 km',
    congestionLevel: 'low',
    heatScore: 23,
    waitMins: 13,
    vehiclesInQueue: 10,
    activeBays: '6 / 6',
    dailyArrivalTons: 1300,
    storageCapacityMT: 16000,
    currentStockMT: 6200,
    primaryCrops: ['Chili', 'Maize', 'Soybean', 'Wheat', 'Cotton'],
    mspHighlight: 'Maize ₹2,090 • Soybean ₹4,850',
    statusTag: 'Smooth Flow (सुरळीत)'
  },
  {
    id: 'mandi_bhandara',
    name: 'Bhandara APMC (Rice Bowl MSP Procurement Center)',
    state: 'Maharashtra',
    district: 'Bhandara',
    zone: 'West',
    distanceKm: '4.7 km',
    congestionLevel: 'low',
    heatScore: 24,
    waitMins: 14,
    vehiclesInQueue: 11,
    activeBays: '7 / 8',
    dailyArrivalTons: 1800,
    storageCapacityMT: 22000,
    currentStockMT: 9500,
    primaryCrops: ['Paddy / Rice', 'Wheat', 'Chana'],
    mspHighlight: 'Paddy MSP ₹2,183 (Grade A ₹2,203)',
    statusTag: 'Fast Clearance (धान खरेदी)'
  },
  {
    id: 'mandi_gondia',
    name: 'Gondia APMC (Eastern Vidarbha Paddy & Rice Hub)',
    state: 'Maharashtra',
    district: 'Gondia',
    zone: 'West',
    distanceKm: '5.2 km',
    congestionLevel: 'low',
    heatScore: 26,
    waitMins: 15,
    vehiclesInQueue: 13,
    activeBays: '8 / 8',
    dailyArrivalTons: 2100,
    storageCapacityMT: 25000,
    currentStockMT: 11200,
    primaryCrops: ['Paddy / Rice', 'Wheat', 'Chana'],
    mspHighlight: 'Paddy MSP ₹2,183 Direct Mill Link',
    statusTag: 'Smooth Flow (सुरळीत)'
  },
  {
    id: 'mandi_hingoli',
    name: 'Hingoli APMC (Turmeric & Soybean Market Yard)',
    state: 'Maharashtra',
    district: 'Hingoli',
    zone: 'West',
    distanceKm: '4.6 km',
    congestionLevel: 'low',
    heatScore: 27,
    waitMins: 15,
    vehiclesInQueue: 12,
    activeBays: '6 / 6',
    dailyArrivalTons: 1400,
    storageCapacityMT: 16500,
    currentStockMT: 7100,
    primaryCrops: ['Turmeric', 'Soybean', 'Cotton', 'Chana'],
    mspHighlight: 'Soybean ₹4,850 • Turmeric High Curcumin',
    statusTag: 'Smooth Flow (सुरळीत)'
  },
  {
    id: 'mandi_gadchiroli',
    name: 'Gadchiroli APMC (Forest Produce & MSP Rice Center)',
    state: 'Maharashtra',
    district: 'Gadchiroli',
    zone: 'West',
    distanceKm: '7.3 km',
    congestionLevel: 'low',
    heatScore: 18,
    waitMins: 10,
    vehiclesInQueue: 7,
    activeBays: '5 / 5',
    dailyArrivalTons: 950,
    storageCapacityMT: 13000,
    currentStockMT: 4300,
    primaryCrops: ['Paddy / Rice', 'Forest Produce', 'Soybean'],
    mspHighlight: 'Paddy ₹2,183 Tribal Bonus Verified',
    statusTag: 'Fast Clearance (सुरळीत)'
  },
  {
    id: 'mandi_vashi',
    name: 'Vashi APMC (Navi Mumbai Central APMC Terminal)',
    state: 'Maharashtra',
    district: 'Thane',
    zone: 'West',
    distanceKm: '8.5 km',
    congestionLevel: 'moderate',
    heatScore: 65,
    waitMins: 36,
    vehiclesInQueue: 44,
    activeBays: '16 / 18',
    dailyArrivalTons: 5200,
    storageCapacityMT: 50000,
    currentStockMT: 34000,
    primaryCrops: ['Wheat', 'Rice / Paddy', 'Pulses', 'Oilseeds', 'Spices'],
    mspHighlight: 'National Terminal Pricing Benchmark',
    statusTag: 'Mega Terminal Flow'
  },
  {
    id: 'mandi_panvel',
    name: 'Panvel APMC (Raigad Paddy & Produce Hub)',
    state: 'Maharashtra',
    district: 'Raigad',
    zone: 'West',
    distanceKm: '6.4 km',
    congestionLevel: 'low',
    heatScore: 28,
    waitMins: 16,
    vehiclesInQueue: 14,
    activeBays: '8 / 8',
    dailyArrivalTons: 1600,
    storageCapacityMT: 18000,
    currentStockMT: 8000,
    primaryCrops: ['Paddy / Rice', 'Vegetables', 'Pulses'],
    mspHighlight: 'Paddy ₹2,183',
    statusTag: 'Smooth Flow (सुरळीत)'
  },
  {
    id: 'mandi_ratnagiri',
    name: 'Ratnagiri APMC (Coastal MSP & Grain Center)',
    state: 'Maharashtra',
    district: 'Ratnagiri',
    zone: 'West',
    distanceKm: '5.5 km',
    congestionLevel: 'low',
    heatScore: 21,
    waitMins: 12,
    vehiclesInQueue: 8,
    activeBays: '6 / 6',
    dailyArrivalTons: 1100,
    storageCapacityMT: 14000,
    currentStockMT: 5100,
    primaryCrops: ['Paddy / Rice', 'Cashew', 'Ragi / Nachani'],
    mspHighlight: 'Paddy ₹2,183 • Ragi MSP ₹3,846',
    statusTag: 'Smooth Flow (सुरळीत)'
  },
  {
    id: 'mandi_sawantwadi',
    name: 'Sawantwadi APMC (Sindhudurg Agricultural Yard)',
    state: 'Maharashtra',
    district: 'Sindhudurg',
    zone: 'West',
    distanceKm: '6.8 km',
    congestionLevel: 'low',
    heatScore: 19,
    waitMins: 11,
    vehiclesInQueue: 7,
    activeBays: '5 / 5',
    dailyArrivalTons: 900,
    storageCapacityMT: 12000,
    currentStockMT: 4200,
    primaryCrops: ['Paddy / Rice', 'Ragi', 'Coconut', 'Spices'],
    mspHighlight: 'Paddy ₹2,183',
    statusTag: 'Smooth Flow (सुरळीत)'
  },
  {
    id: 'mandi_palghar',
    name: 'Palghar APMC (Tribal Paddy Procurement Center)',
    state: 'Maharashtra',
    district: 'Palghar',
    zone: 'West',
    distanceKm: '5.6 km',
    congestionLevel: 'low',
    heatScore: 23,
    waitMins: 13,
    vehiclesInQueue: 9,
    activeBays: '6 / 6',
    dailyArrivalTons: 1250,
    storageCapacityMT: 15000,
    currentStockMT: 5800,
    primaryCrops: ['Paddy / Rice', 'Ragi', 'Vari', 'Gram'],
    mspHighlight: 'Paddy ₹2,183',
    statusTag: 'Smooth Flow (सुरळीत)'
  },

  // Punjab
  {
    id: 'mandi_khanna',
    name: 'Khanna APMC (Asia’s Largest Grain Market)',
    state: 'Punjab',
    district: 'Ludhiana',
    zone: 'North',
    distanceKm: '5.0 km',
    congestionLevel: 'moderate',
    heatScore: 56,
    waitMins: 32,
    vehiclesInQueue: 46,
    activeBays: '16 / 18',
    dailyArrivalTons: 6800,
    storageCapacityMT: 65000,
    currentStockMT: 41000,
    primaryCrops: ['Wheat', 'Paddy', 'Basmati', 'Mustard'],
    mspHighlight: 'Wheat ₹2,275 • Paddy ₹2,183',
    statusTag: 'Normal Flow (ਆਮ ਚੱਲ ਰਿਹਾ)'
  },
  {
    id: 'mandi_amritsar',
    name: 'Amritsar APMC (Bhagtanwala Dana Mandi)',
    state: 'Punjab',
    district: 'Amritsar',
    zone: 'North',
    distanceKm: '4.1 km',
    congestionLevel: 'low',
    heatScore: 26,
    waitMins: 16,
    vehiclesInQueue: 12,
    activeBays: '12 / 12',
    dailyArrivalTons: 3400,
    storageCapacityMT: 40000,
    currentStockMT: 15000,
    primaryCrops: ['Basmati Rice', 'Wheat', 'Maize'],
    mspHighlight: 'Basmati High Quality • Wheat ₹2,275',
    statusTag: 'Fast Clearance (ਤੇਜ਼ ਨਿਪਟਾਰਾ)'
  },
  {
    id: 'mandi_bathinda',
    name: 'Bathinda APMC (Cotton & Wheat Belt)',
    state: 'Punjab',
    district: 'Bathinda',
    zone: 'North',
    distanceKm: '6.5 km',
    congestionLevel: 'high',
    heatScore: 84,
    waitMins: 52,
    vehiclesInQueue: 65,
    activeBays: '10 / 10 (Full)',
    dailyArrivalTons: 4200,
    storageCapacityMT: 35000,
    currentStockMT: 31000,
    primaryCrops: ['Cotton', 'Wheat', 'Mustard', 'Barley'],
    mspHighlight: 'Cotton ₹7,121 • Mustard ₹5,650',
    statusTag: 'Heavy Congestion (ਭਾਰੀ ਜਾਮ)'
  },

  // Madhya Pradesh
  {
    id: 'mandi_indore',
    name: 'Indore APMC (Laxmibai Nagar Mandi Hub)',
    state: 'Madhya Pradesh',
    district: 'Indore',
    zone: 'Central',
    distanceKm: '2.5 km',
    congestionLevel: 'moderate',
    heatScore: 68,
    waitMins: 35,
    vehiclesInQueue: 42,
    activeBays: '12 / 14',
    dailyArrivalTons: 5100,
    storageCapacityMT: 45000,
    currentStockMT: 38000,
    primaryCrops: ['Wheat', 'Soybean', 'Chana', 'Garlic'],
    mspHighlight: 'Wheat ₹2,275 • Soybean ₹4,850',
    statusTag: 'Moderate Wait (~35m)'
  },
  {
    id: 'mandi_ujjain',
    name: 'Ujjain APMC (Agar Road Mandi)',
    state: 'Madhya Pradesh',
    district: 'Ujjain',
    zone: 'Central',
    distanceKm: '5.0 km',
    congestionLevel: 'low',
    heatScore: 22,
    waitMins: 15,
    vehiclesInQueue: 9,
    activeBays: '8 / 8',
    dailyArrivalTons: 1800,
    storageCapacityMT: 28000,
    currentStockMT: 11000,
    primaryCrops: ['Wheat', 'Chana', 'Soybean'],
    mspHighlight: 'Chana ₹5,440 • Wheat ₹2,275',
    statusTag: 'Smooth Flow (<15m)'
  },
  {
    id: 'mandi_dewas',
    name: 'Dewas APMC (Dewas Mandi Hub)',
    state: 'Madhya Pradesh',
    district: 'Dewas',
    zone: 'Central',
    distanceKm: '8.2 km',
    congestionLevel: 'high',
    heatScore: 82,
    waitMins: 48,
    vehiclesInQueue: 54,
    activeBays: '6 / 6 (Full)',
    dailyArrivalTons: 3200,
    storageCapacityMT: 22000,
    currentStockMT: 20500,
    primaryCrops: ['Soybean', 'Mustard', 'Wheat'],
    mspHighlight: 'Soybean ₹4,850 • Mustard ₹5,650',
    statusTag: 'Congested (93% Full)'
  },
  {
    id: 'mandi_sehore',
    name: 'Sehore APMC (Famous Sharbati Wheat Yard)',
    state: 'Madhya Pradesh',
    district: 'Sehore',
    zone: 'Central',
    distanceKm: '11.0 km',
    congestionLevel: 'low',
    heatScore: 30,
    waitMins: 18,
    vehiclesInQueue: 15,
    activeBays: '6 / 6',
    dailyArrivalTons: 2200,
    storageCapacityMT: 25000,
    currentStockMT: 10500,
    primaryCrops: ['Sharbati Wheat', 'Chana', 'Soybean'],
    mspHighlight: 'Sharbati Premium Rates • Wheat ₹2,275',
    statusTag: 'Smooth Clearance'
  },

  // Gujarat
  {
    id: 'mandi_unjha',
    name: 'Unjha APMC (World’s Spice & Cumin Capital)',
    state: 'Gujarat',
    district: 'Mehsana',
    zone: 'West',
    distanceKm: '3.4 km',
    congestionLevel: 'moderate',
    heatScore: 58,
    waitMins: 28,
    vehiclesInQueue: 34,
    activeBays: '10 / 12',
    dailyArrivalTons: 4100,
    storageCapacityMT: 35000,
    currentStockMT: 22000,
    primaryCrops: ['Cumin (Jeera)', 'Fennel (Saunf)', 'Mustard', 'Castor'],
    mspHighlight: 'Cumin High Trade • Mustard ₹5,650',
    statusTag: 'Active Trading (ચાલુ વેપાર)'
  },
  {
    id: 'mandi_rajkot',
    name: 'Rajkot APMC (Bedi Yard - Groundnut & Cotton)',
    state: 'Gujarat',
    district: 'Rajkot',
    zone: 'West',
    distanceKm: '5.6 km',
    congestionLevel: 'high',
    heatScore: 86,
    waitMins: 55,
    vehiclesInQueue: 68,
    activeBays: '12 / 12 (Full)',
    dailyArrivalTons: 5400,
    storageCapacityMT: 42000,
    currentStockMT: 39000,
    primaryCrops: ['Groundnut (Singdana)', 'Cotton', 'Wheat', 'Sesame'],
    mspHighlight: 'Groundnut ₹6,377 • Cotton ₹7,121',
    statusTag: 'High Density (ભારે ભીડ)'
  },
  {
    id: 'mandi_gondal',
    name: 'Gondal APMC (Saurashtra Mega Yard)',
    state: 'Gujarat',
    district: 'Gondal',
    zone: 'West',
    distanceKm: '6.0 km',
    congestionLevel: 'low',
    heatScore: 24,
    waitMins: 14,
    vehiclesInQueue: 11,
    activeBays: '8 / 8',
    dailyArrivalTons: 2600,
    storageCapacityMT: 30000,
    currentStockMT: 11500,
    primaryCrops: ['Red Chili', 'Groundnut', 'Coriander', 'Wheat'],
    mspHighlight: 'Chili Premium • Wheat ₹2,275',
    statusTag: 'Fast Clearance (ઝડપી નિકાલ)'
  },

  // Uttar Pradesh
  {
    id: 'mandi_muzaffarnagar',
    name: 'Muzaffarnagar APMC (Jaggery & Wheat Hub)',
    state: 'Uttar Pradesh',
    district: 'Muzaffarnagar',
    zone: 'North',
    distanceKm: '4.8 km',
    congestionLevel: 'moderate',
    heatScore: 62,
    waitMins: 34,
    vehiclesInQueue: 41,
    activeBays: '10 / 12',
    dailyArrivalTons: 4800,
    storageCapacityMT: 48000,
    currentStockMT: 32000,
    primaryCrops: ['Wheat', 'Sugarcane/Jaggery', 'Paddy', 'Mustard'],
    mspHighlight: 'Wheat ₹2,275 • Sugarcane SAP ₹370',
    statusTag: 'Steady Flow (~34m wait)'
  },
  {
    id: 'mandi_bareilly',
    name: 'Bareilly APMC (Rohilkhand Grain Terminal)',
    state: 'Uttar Pradesh',
    district: 'Bareilly',
    zone: 'North',
    distanceKm: '5.2 km',
    congestionLevel: 'low',
    heatScore: 28,
    waitMins: 17,
    vehiclesInQueue: 16,
    activeBays: '8 / 8',
    dailyArrivalTons: 2300,
    storageCapacityMT: 32000,
    currentStockMT: 13500,
    primaryCrops: ['Paddy', 'Wheat', 'Mentha', 'Mustard'],
    mspHighlight: 'Paddy ₹2,183 • Wheat ₹2,275',
    statusTag: 'Smooth Entry'
  },
  {
    id: 'mandi_varanasi',
    name: 'Varanasi APMC (Chandpur Yard)',
    state: 'Uttar Pradesh',
    district: 'Varanasi',
    zone: 'North',
    distanceKm: '6.4 km',
    congestionLevel: 'high',
    heatScore: 80,
    waitMins: 46,
    vehiclesInQueue: 58,
    activeBays: '7 / 8',
    dailyArrivalTons: 3600,
    storageCapacityMT: 28000,
    currentStockMT: 25000,
    primaryCrops: ['Paddy', 'Wheat', 'Vegetables', 'Mustard'],
    mspHighlight: 'Paddy ₹2,183 • Wheat ₹2,275',
    statusTag: 'Heavy Inflow (89% Full)'
  },

  // Haryana
  {
    id: 'mandi_karnal',
    name: 'Karnal APMC (Basmati Rice Capital)',
    state: 'Haryana',
    district: 'Karnal',
    zone: 'North',
    distanceKm: '3.9 km',
    congestionLevel: 'low',
    heatScore: 25,
    waitMins: 16,
    vehiclesInQueue: 13,
    activeBays: '14 / 14',
    dailyArrivalTons: 5200,
    storageCapacityMT: 55000,
    currentStockMT: 21000,
    primaryCrops: ['Basmati Paddy', 'Wheat', 'Mustard'],
    mspHighlight: 'Basmati Grade 1 • Wheat ₹2,275',
    statusTag: 'Smooth Flow (<16m)'
  },
  {
    id: 'mandi_sirsa',
    name: 'Sirsa APMC (Cotton & Wheat Market)',
    state: 'Haryana',
    district: 'Sirsa',
    zone: 'North',
    distanceKm: '5.5 km',
    congestionLevel: 'high',
    heatScore: 85,
    waitMins: 50,
    vehiclesInQueue: 64,
    activeBays: '8 / 8 (Full)',
    dailyArrivalTons: 4400,
    storageCapacityMT: 36000,
    currentStockMT: 33000,
    primaryCrops: ['Cotton', 'Wheat', 'Mustard', 'Barley'],
    mspHighlight: 'Cotton ₹7,121 • Mustard ₹5,650',
    statusTag: 'Heavy Congestion'
  },

  // Rajasthan
  {
    id: 'mandi_kota',
    name: 'Kota APMC (Bhamashah Mega Grain Yard)',
    state: 'Rajasthan',
    district: 'Kota',
    zone: 'North',
    distanceKm: '4.2 km',
    congestionLevel: 'moderate',
    heatScore: 65,
    waitMins: 36,
    vehiclesInQueue: 44,
    activeBays: '12 / 14',
    dailyArrivalTons: 4900,
    storageCapacityMT: 50000,
    currentStockMT: 34000,
    primaryCrops: ['Soybean', 'Mustard', 'Coriander', 'Wheat'],
    mspHighlight: 'Soybean ₹4,850 • Mustard ₹5,650',
    statusTag: 'Moderate Line (~36m)'
  },
  {
    id: 'mandi_sriganganagar',
    name: 'Sri Ganganagar APMC (Canal Granary Yard)',
    state: 'Rajasthan',
    district: 'Sri Ganganagar',
    zone: 'North',
    distanceKm: '6.1 km',
    congestionLevel: 'low',
    heatScore: 31,
    waitMins: 19,
    vehiclesInQueue: 17,
    activeBays: '10 / 10',
    dailyArrivalTons: 3800,
    storageCapacityMT: 42000,
    currentStockMT: 16000,
    primaryCrops: ['Wheat', 'Mustard', 'Cotton', 'Kinnow'],
    mspHighlight: 'Wheat ₹2,275 • Cotton ₹7,121',
    statusTag: 'Smooth Intake'
  },

  // West Bengal
  {
    id: 'mandi_burdwan',
    name: 'Burdwan APMC (Memari Rice Bowl Terminal)',
    state: 'West Bengal',
    district: 'Burdwan',
    zone: 'East',
    distanceKm: '4.6 km',
    congestionLevel: 'moderate',
    heatScore: 60,
    waitMins: 30,
    vehiclesInQueue: 36,
    activeBays: '8 / 10',
    dailyArrivalTons: 3500,
    storageCapacityMT: 38000,
    currentStockMT: 23000,
    primaryCrops: ['Paddy (Aman/Boro)', 'Potato', 'Mustard', 'Jute'],
    mspHighlight: 'Paddy ₹2,183 • Jute ₹5,050',
    statusTag: 'Normal Flow (স্বাভাবিক प्रवाह)'
  },
  {
    id: 'mandi_hooghly',
    name: 'Hooghly APMC (Sheoraphuli Agrico Yard)',
    state: 'West Bengal',
    district: 'Hooghly',
    zone: 'East',
    distanceKm: '5.3 km',
    congestionLevel: 'high',
    heatScore: 78,
    waitMins: 45,
    vehiclesInQueue: 52,
    activeBays: '6 / 6 (Full)',
    dailyArrivalTons: 2900,
    storageCapacityMT: 24000,
    currentStockMT: 21500,
    primaryCrops: ['Potato', 'Paddy', 'Jute', 'Vegetables'],
    mspHighlight: 'Potato Cold Storage Full • Paddy ₹2,183',
    statusTag: 'Crowded (অতিরিক্ত ভিড়)'
  },

  // Tamil Nadu
  {
    id: 'mandi_erode',
    name: 'Erode APMC (Turmeric City Regulated Market)',
    state: 'Tamil Nadu',
    district: 'Erode',
    zone: 'South',
    distanceKm: '3.7 km',
    congestionLevel: 'low',
    heatScore: 27,
    waitMins: 16,
    vehiclesInQueue: 14,
    activeBays: '8 / 8',
    dailyArrivalTons: 2400,
    storageCapacityMT: 28000,
    currentStockMT: 12000,
    primaryCrops: ['Turmeric', 'Paddy', 'Groundnut', 'Maize'],
    mspHighlight: 'Turmeric High Grade • Paddy ₹2,183',
    statusTag: 'Smooth (சீரான இயக்கம்)'
  },
  {
    id: 'mandi_thanjavur',
    name: 'Thanjavur APMC (Cauvery Delta Direct Purchase)',
    state: 'Tamil Nadu',
    district: 'Thanjavur',
    zone: 'South',
    distanceKm: '4.8 km',
    congestionLevel: 'high',
    heatScore: 89,
    waitMins: 56,
    vehiclesInQueue: 70,
    activeBays: '10 / 10 (Full)',
    dailyArrivalTons: 4600,
    storageCapacityMT: 35000,
    currentStockMT: 33000,
    primaryCrops: ['Paddy (Kuruvai/Samba)', 'Pulses', 'Groundnut'],
    mspHighlight: 'Paddy ₹2,183 + State Bonus ₹100',
    statusTag: 'Heavy Inflow (அதிக நெரிசல்)'
  },

  // Karnataka
  {
    id: 'mandi_hubballi',
    name: 'Hubballi APMC (Amaragol Yard - Cotton & Chili)',
    state: 'Karnataka',
    district: 'Hubballi-Dharwad',
    zone: 'South',
    distanceKm: '5.2 km',
    congestionLevel: 'low',
    heatScore: 33,
    waitMins: 20,
    vehiclesInQueue: 19,
    activeBays: '10 / 10',
    dailyArrivalTons: 3100,
    storageCapacityMT: 34000,
    currentStockMT: 14000,
    primaryCrops: ['Cotton', 'Byadagi Chili', 'Maize', 'Soybean'],
    mspHighlight: 'Cotton ₹7,121 • Chili GI Premium',
    statusTag: 'Smooth Flow'
  },
  {
    id: 'mandi_davanagere',
    name: 'Davanagere APMC (Central Karnataka Maize Hub)',
    state: 'Karnataka',
    district: 'Davanagere',
    zone: 'South',
    distanceKm: '4.9 km',
    congestionLevel: 'moderate',
    heatScore: 61,
    waitMins: 32,
    vehiclesInQueue: 37,
    activeBays: '8 / 10',
    dailyArrivalTons: 2800,
    storageCapacityMT: 30000,
    currentStockMT: 19000,
    primaryCrops: ['Maize', 'Paddy', 'Ragi', 'Groundnut'],
    mspHighlight: 'Maize ₹2,090 • Ragi ₹3,846',
    statusTag: 'Moderate Queue'
  },

  // Andhra Pradesh & Telangana
  {
    id: 'mandi_guntur',
    name: 'Guntur APMC (Asia’s Biggest Mirchi Yard)',
    state: 'Andhra Pradesh',
    district: 'Guntur',
    zone: 'South',
    distanceKm: '4.0 km',
    congestionLevel: 'high',
    heatScore: 92,
    waitMins: 62,
    vehiclesInQueue: 88,
    activeBays: '14 / 14 (Full)',
    dailyArrivalTons: 7200,
    storageCapacityMT: 52000,
    currentStockMT: 49000,
    primaryCrops: ['Dry Red Chili', 'Cotton', 'Tobacco', 'Paddy'],
    mspHighlight: 'Chili Export Demand • Cotton ₹7,121',
    statusTag: 'Heavy Congestion (94% Full)'
  },
  {
    id: 'mandi_warangal',
    name: 'Warangal APMC (Enumamula Mega Yard)',
    state: 'Telangana',
    district: 'Warangal',
    zone: 'South',
    distanceKm: '5.8 km',
    congestionLevel: 'moderate',
    heatScore: 66,
    waitMins: 37,
    vehiclesInQueue: 43,
    activeBays: '12 / 14',
    dailyArrivalTons: 4500,
    storageCapacityMT: 45000,
    currentStockMT: 31000,
    primaryCrops: ['Cotton', 'Paddy', 'Red Gram', 'Chili'],
    mspHighlight: 'Cotton ₹7,121 • Paddy ₹2,183',
    statusTag: 'Moderate Traffic'
  },

  // Bihar
  {
    id: 'mandi_gulabbagh',
    name: 'Gulabbagh APMC (Purnea - Eastern Maize Capital)',
    state: 'Bihar',
    district: 'Purnea',
    zone: 'East',
    distanceKm: '6.7 km',
    congestionLevel: 'low',
    heatScore: 29,
    waitMins: 18,
    vehiclesInQueue: 16,
    activeBays: '10 / 10',
    dailyArrivalTons: 3800,
    storageCapacityMT: 40000,
    currentStockMT: 15500,
    primaryCrops: ['Maize', 'Jute', 'Makhana', 'Wheat'],
    mspHighlight: 'Maize ₹2,090 • Makhana Premium',
    statusTag: 'Smooth Clearance'
  }
];

const DEFAULT_STATE = {
  currentLanguage: 'en', // 'en', 'hi', 'mr', 'pa', 'gu', 'bn', 'ta'
  selectedState: 'Maharashtra',
  selectedZone: 'all',
  selectedDistrict: 'All Districts',
  mobileCanvasMode: false,
  auth: {
    isLoggedIn: false, // Starts at Unified Login Gateway
    currentRole: null, // 'farmer', 'center', 'district'
    user: null
  },
  farmer: {
    name: 'Ramesh Patil',
    phone: '+91 98765 43210',
    aadhaar: 'XXXX-XXXX-4821',
    govIdType: 'Aadhaar Card',
    bankAccount: 'Bank of Maharashtra •••• 4821',
    ifsc: 'MAHB0000324',
    residence: {
      state: 'Maharashtra',
      district: 'Pune',
      tehsil: 'Baramati / Haveli',
      village: 'Baramati Rural (पुणे)',
      houseAddress: 'House No. 42, Ward 3, Baramati APMC Circle',
      pincode: '413102',
      residenceType: 'Permanent Resident (पैतृक निवासी)'
    },
    land: {
      totalAcres: 6.5,
      bighaEquivalent: '16.25 Bigha',
      cultivableAcres: 6.0,
      irrigatedAcres: 5.0,
      unirrigatedAcres: 1.5,
      ownershipType: 'Owner Cultivator (स्वयं मालिक)',
      khasraNo: '142/3, 145/1',
      khatauniNo: 'KH-00942',
      credentialDocType: '7/12 Extract & Khasra-Khatauni (भू-अभिलेख)',
      pmKisanId: 'MP-IND-2023-99824',
      soilType: 'Black Cotton Soil (काली मिट्टी)',
      waterSource: 'Tube-well & Canal (नहर व नलकूप)'
    },
    activeToken: {
      bookingId: 'AFG20251015001',
      id: 'A12',
      crop: 'Wheat',
      qtyQuintal: 50,
      mandi: 'Centre A (Shivaji Nagar, Indore Mandi)',
      centerId: 'centre_a',
      distanceKm: '2.5 km',
      gate: 'Gate 2 (Tractor & Heavy Vehicle Yard)',
      date: '15 Oct 2025',
      timeSlot: '10:00 AM - 11:00 AM',
      vehicleType: 'Tractor Trolley (2-Wheel)',
      vehicleIcon: '🚜',
      vehicleNo: 'MP-09-AB-1234',
      parkingLane: 'Lane TT-04 (Tractor Bay)',
      status: 'Confirmed', // Confirmed, Checked-In, Weighing, QC_Done, Paid
      servingToken: 'A08',
      farmersAhead: 4,
      mspPerQtl: 2275,
      expectedTotal: null,
      finalRate: null,
      finalAmount: null,
      priceStatus: 'Assessed post-inspection at Mandi',
      utrNo: 'TXN1234567890',
      isCheckedIn: false,
      qrData: 'AFG20251015001-A12'
    },
    procurementSteps: [
      { id: 1, name: 'Crop verification', status: 'completed', time: 'Completed (10:05 AM)', desc: 'Crop variety (Wheat FAQ) & vehicle plate verified at intake gate.' },
      { id: 2, name: 'Weighing', status: 'in_progress', time: 'In Progress', desc: 'Electronic weighbridge: Gross 52.40 Qtl • Tare 2.40 Qtl • Net 50.00 Qtl.' },
      { id: 3, name: 'Quality check', status: 'pending', time: 'Pending', desc: 'Grain moisture (target ≤12%) and foreign matter analysis.' },
      { id: 4, name: 'Acceptance', status: 'pending', time: 'Pending', desc: 'Digital receipt sign-off by Mandi Superintendent.' },
      { id: 5, name: 'Procurement completed', status: 'pending', time: 'Pending', desc: 'Direct Benefit Transfer (DBT) payment generation.' }
    ],
    bookings: [
      {
        bookingId: 'AFG20251015001',
        token: 'A12',
        crop: 'Wheat',
        qty: 50,
        center: 'Centre A (Shivaji Nagar, Indore)',
        date: '15 Oct 2025',
        timeSlot: '10:00 AM - 11:00 AM',
        status: 'Booked',
        vehicle: 'Tractor Trolley MP-09-AB-1234',
        amount: 113750
      },
      {
        bookingId: 'AFG20250928002',
        token: 'A18',
        crop: 'Rice',
        qty: 30,
        center: 'Centre B (Agar Road, Ujjain)',
        date: '28 Sep 2025',
        timeSlot: '09:00 AM - 10:00 AM',
        status: 'In Progress',
        vehicle: 'Bolero Pickup MP-09-CD-5678',
        amount: 65490
      },
      {
        bookingId: 'AFG20250815003',
        token: 'A06',
        crop: 'Maize',
        qty: 20,
        center: 'Centre C (Dewas Mandi Hub)',
        date: '15 Aug 2025',
        timeSlot: '11:00 AM - 12:00 PM',
        status: 'Completed',
        vehicle: 'Tractor Trolley MP-13-EF-9012',
        amount: 41800
      },
      {
        bookingId: 'AFG20250801004',
        token: 'A21',
        crop: 'Wheat',
        qty: 40,
        center: 'Centre A (Shivaji Nagar, Indore)',
        date: '10 Aug 2025',
        timeSlot: '10:00 AM - 11:00 AM',
        status: 'Cancelled',
        vehicle: 'Tractor Trolley MP-09-IJ-7890',
        amount: 91000
      }
    ],
    queueTracking: {
      token: 'A12',
      farmersAhead: 4,
      estWaitMins: 20,
      centre: 'Centre A (Shivaji Nagar, Indore Mandi)',
      queueList: [
        { token: 'A12', label: 'A12 (You)', wait: '20 min', status: 'current', isUser: true },
        { token: 'A11', label: 'A11', wait: '10 min', status: 'waiting', isUser: false },
        { token: 'A10', label: 'A10', wait: '15 min', status: 'waiting', isUser: false },
        { token: 'A09', label: 'A09', wait: '20 min', status: 'waiting', isUser: false },
        { token: 'A08', label: 'A08', wait: '25 min', status: 'waiting', isUser: false }
      ]
    },
    paymentTimeline: [
      {
        id: 'qc',
        stage: 'Quality Check & Grading',
        title: 'Moisture & Physical Grain Quality',
        status: 'completed',
        timestamp: '15 Oct, 10:15 AM',
        details: 'Moisture: 8.5% (FAQ Standard: ≤12%) • Grade A (100% Accepted)'
      },
      {
        id: 'weighment',
        stage: 'Certified Weighbridge Weighment',
        title: 'Electronic Weighbridge Certification',
        status: 'completed',
        timestamp: '15 Oct, 10:45 AM',
        details: 'Gross: 52.40 Qtl • Tare: 2.40 Qtl • Net Certified: 50.00 Qtl'
      },
      {
        id: 'payment_init',
        stage: 'Payment Initiated (DBT)',
        title: 'Direct Benefit Transfer to Bank',
        status: 'completed',
        timestamp: '15 Oct, 11:00 AM',
        details: 'Disbursement file signed & transmitted to NPCI / PFMS gateway'
      },
      {
        id: 'paid',
        stage: 'Direct Bank Credit',
        title: 'Bank Credit Confirmation',
        status: 'completed',
        timestamp: '15 Oct, 02:15 PM',
        details: '₹1,13,750 direct credit to Bank of India (A/C ****4821)'
      }
    ],
    history: [
      {
        id: 'REC-2025-0982',
        crop: 'Soybean (Yellow)',
        qty: 50,
        rate: 4850,
        total: 242500,
        date: '14 Apr 2025',
        status: 'Paid',
        mandi: 'Indore Center',
        vehicle: 'Tractor Trolley MP-09-AB-1234',
        utr: 'UTR893120194812'
      },
      {
        id: 'REC-2025-0761',
        crop: 'Wheat (Sharbati)',
        qty: 40,
        rate: 2275,
        total: 91000,
        date: '18 Apr 2025',
        status: 'Paid',
        mandi: 'Indore Center',
        vehicle: 'Pickup Bolero MP-09-CD-5678',
        utr: 'UTR893120177341'
      },
      {
        id: 'REC-2025-0410',
        crop: 'Gram / Chana',
        qty: 30,
        rate: 5440,
        total: 163200,
        date: '10 Apr 2025',
        status: 'Paid',
        mandi: 'Ujjain Mandi',
        vehicle: 'Tractor Trolley MP-13-EF-9012',
        utr: 'UTR893120152981'
      }
    ],
    notifications: [
      {
        id: 1,
        title: 'Slot Reminder',
        body: 'Your slot is confirmed for tomorrow 10:00 AM at Indore Center Gate 2.',
        time: '2h ago',
        type: 'reminder',
        icon: 'calendar'
      },
      {
        id: 2,
        title: 'DBT Payment Alert',
        body: '₹91,000 credited to Bank of India A/C 4821 for Wheat procurement.',
        time: '3d ago',
        type: 'payment',
        icon: 'check-circle'
      },
      {
        id: 3,
        title: 'Queue Update',
        body: 'Tokens A-012 to A-017 completed. Your tractor is next in ~34 mins.',
        time: '4m ago',
        type: 'queue',
        icon: 'clock'
      },
      {
        id: 4,
        title: 'MSP Revision Notice',
        body: 'Soybean MSP revised to ₹4,892/Qtl for this marketing season.',
        time: '1d ago',
        type: 'info',
        icon: 'trending-up'
      }
    ]
  },
  center: {
    centerName: 'Indore Procurement Center #04',
    operatorName: 'Vijay Sharma (QC Lead & Superintendent)',
    kpis: {
      todaysBookings: 2318,
      tokenedIn: 1892,
      inQueue: 426,
      completed: 1756
    },
    queue: [
      {
        token: 'A-018',
        farmer: 'Ramesh Patel',
        crop: 'Soybean',
        qty: 50,
        vehicle: 'Tractor Trolley (2-Wheel)',
        vehicleIcon: '🚜',
        vehicleNo: 'MP-09-AB-1234',
        lane: 'Lane TT-02',
        arrival: '09:50 AM',
        status: 'Serving',
        waitMins: 0
      },
      {
        token: 'A-019',
        farmer: 'Suresh Yadav',
        crop: 'Soybean',
        qty: 90,
        vehicle: 'Medium Truck (6-Tyre Eicher)',
        vehicleIcon: '🚚',
        vehicleNo: 'MP-09-CD-5678',
        lane: 'Lane TR-03',
        arrival: '09:55 AM',
        status: 'Waiting',
        waitMins: 12
      },
      {
        token: 'A-020',
        farmer: 'Mahesh Kumar',
        crop: 'Wheat',
        qty: 30,
        vehicle: 'Pickup / Bolero Maxi Truck',
        vehicleIcon: '🛻',
        vehicleNo: 'MP-09-EF-9012',
        lane: 'Lane PK-01',
        arrival: '10:02 AM',
        status: 'Waiting',
        waitMins: 20
      },
      {
        token: 'A-021',
        farmer: 'Pooja Sharma',
        crop: 'Soybean',
        qty: 15,
        vehicle: 'Bullock Cart (Bail Gaadi)',
        vehicleIcon: '🐂',
        vehicleNo: 'IND-CART-104',
        lane: 'Lane BC-01',
        arrival: '10:10 AM',
        status: 'Waiting',
        waitMins: 26
      },
      {
        token: 'A-022',
        farmer: 'Raj Kumar',
        crop: 'Wheat',
        qty: 85,
        vehicle: 'Tractor Trolley (4-Wheel Heavy)',
        vehicleIcon: '🚜',
        vehicleNo: 'MP-09-IJ-7890',
        lane: 'Lane TH-02',
        arrival: '10:14 AM',
        status: 'Waiting',
        waitMins: 30
      },
      {
        token: 'A-023',
        farmer: 'Laxman Patel',
        crop: 'Soybean',
        qty: 240,
        vehicle: 'Heavy Multi-Axle Hauler (10-14 Tyre)',
        vehicleIcon: '🚛',
        vehicleNo: 'MP-09-KL-1234',
        lane: 'Lane HH-01',
        arrival: '10:18 AM',
        status: 'Waiting',
        waitMins: 34
      }
    ],
    parkingLanes: {
      tractorTrolley: { total: 20, occupied: 14, name: 'Tractor Trolley Yard' },
      tractorHeavy: { total: 15, occupied: 10, name: 'Tractor Heavy (4-Wheel)' },
      pickupBolero: { total: 12, occupied: 7, name: 'Pickup / Bolero Bay' },
      truck6Tyre: { total: 10, occupied: 8, name: 'Medium Truck (6-Tyre) Bay' },
      heavyHauler: { total: 8, occupied: 5, name: 'Multi-Axle Heavy Hauler Bay' },
      bullockCart: { total: 8, occupied: 3, name: 'Traditional / Bullock Cart Bay' }
    },
    capacity: {
      hourlyCapacity: 50,
      bookedSlots: 42,
      availableSlots: 8,
      isBlocked: false
    },
    storage: {
      totalCapacityMT: 10000,
      currentStockMT: 9200,
      percentage: 92,
      shedA: 98,
      shedB: 85,
      openPlinth: 92
    },
    vehicleMovementLogs: [
      { token: 'A-016', time: '10:45 AM', action: 'Out', vehicle: 'Tractor Trolley MP-09-PQ-4412' },
      { token: 'A-018', time: '10:50 AM', action: 'In', vehicle: 'Tractor Trolley MP-09-AB-1234' },
      { token: 'A-019', time: '11:02 AM', action: 'In', vehicle: '6-Tyre Truck MP-09-CD-5678' }
    ],
    payments: {
      pendingCount: 2,
      successCount: 1757,
      failedCount: 0,
      toBePaidAmount: 181842.60,
      paidTodayAmount: 52380.00,
      recentList: [
        {
          token: 'PF-1024',
          txnRef: 'PF-TXN-1003',
          farmer: 'Sunita Jadhav',
          location: 'Indapur',
          bank: 'State Bank of India (Baramati)',
          account: '****4837',
          ifsc: 'SBIN0000324',
          aadhaarLinked: true,
          amount: 94764.60,
          crop: 'Wheat (Sharbati)',
          qty: 42,
          status: 'Processing',
          time: 'Today, 10:42 AM'
        },
        {
          token: 'PF-1042',
          txnRef: 'PF-TXN-1002',
          farmer: 'Jyoti Khandagale',
          location: 'Nandgaon',
          bank: 'State Bank of India (Baramati)',
          account: '****5143',
          ifsc: 'SBIN0000324',
          aadhaarLinked: true,
          amount: 87078.00,
          crop: 'Soybean',
          qty: 38.5,
          status: 'Processing',
          time: 'Today, 10:15 AM'
        },
        {
          token: 'PF-1041',
          txnRef: 'PF-TXN-1001',
          farmer: 'Ashok Randhive',
          location: 'Igatpuri',
          bank: 'State Bank of India (Baramati)',
          account: '****2910',
          ifsc: 'SBIN0000324',
          aadhaarLinked: true,
          amount: 52380.00,
          crop: 'Soybean',
          qty: 24,
          status: 'Settled',
          time: 'Today, 08:30 AM'
        },
        {
          token: 'A-018',
          txnRef: 'PF-TXN-1000',
          farmer: 'Ramesh Patel',
          location: 'Baramati',
          bank: 'Bank of India (Baramati)',
          account: '****4821',
          ifsc: 'BKID0009821',
          aadhaarLinked: true,
          amount: 113750.00,
          crop: 'Wheat',
          qty: 50,
          status: 'Settled',
          time: 'Yesterday, 04:15 PM'
        }
      ]
    }
  },
  district: {
    kpis: {
      activeCenters: 24,
      farmersToday: 4256,
      totalBookings: 2318,
      avgWaitMins: 28,
      totalProcurementMT: 8745,
      amountPaidCr: 3.24
    },
    aiPrediction: {
      active: true,
      title: 'AI Vehicle Congestion & Load Prediction',
      message: 'High agricultural vehicle congestion predicted tomorrow (10:00 AM - 12:00 PM). 45+ heavy tractor trolleys and 20 multi-axle trucks booked across Indore & Ujjain mandis.',
      recommendation: 'Open 3 auxiliary tractor weighing ramps & divert bulk trucks to Dewas Hub.'
    },
    mandis: [
      {
        id: 'mandi-1',
        name: 'Indore Center (Laxmibai Nagar)',
        lat: 22.7196,
        lng: 75.8577,
        bookings: 887,
        liveQueue: 142,
        avgWait: 32,
        procurementMT: 1245,
        storagePct: 92,
        status: 'High',
        color: '#ef4444'
      },
      {
        id: 'mandi-2',
        name: 'Ujjain Mandi (Agar Road)',
        lat: 23.1765,
        lng: 75.7885,
        bookings: 648,
        liveQueue: 118,
        avgWait: 21,
        procurementMT: 985,
        storagePct: 76,
        status: 'Moderate',
        color: '#f59e0b'
      },
      {
        id: 'mandi-3',
        name: 'Dewas Hub',
        lat: 22.9676,
        lng: 76.0534,
        bookings: 421,
        liveQueue: 76,
        avgWait: 18,
        procurementMT: 642,
        storagePct: 64,
        status: 'Normal',
        color: '#10b981'
      },
      {
        id: 'mandi-4',
        name: 'Bhopal Central Mandi',
        lat: 23.2599,
        lng: 77.4126,
        bookings: 357,
        liveQueue: 54,
        avgWait: 16,
        procurementMT: 580,
        storagePct: 58,
        status: 'Normal',
        color: '#10b981'
      },
      {
        id: 'mandi-5',
        name: 'Dhar District Mandi',
        lat: 22.5978,
        lng: 75.2974,
        bookings: 295,
        liveQueue: 48,
        avgWait: 19,
        procurementMT: 412,
        storagePct: 71,
        status: 'Normal',
        color: '#10b981'
      },
      {
        id: 'mandi-6',
        name: 'Khargone Mandi',
        lat: 21.8258,
        lng: 75.6124,
        bookings: 320,
        liveQueue: 65,
        avgWait: 24,
        procurementMT: 490,
        storagePct: 81,
        status: 'Moderate',
        color: '#f59e0b'
      }
    ],
    alerts: [
      {
        id: 'ALT-1',
        type: 'critical',
        title: 'Storage Capacity Alert (92%)',
        desc: 'Indore Mandi - 9,200 MT / 10,000 MT occupied (Only 800 MT buffer left in Shed 3)',
        time: '10:34 AM',
        icon: 'alert-triangle'
      },
      {
        id: 'ALT-2',
        type: 'warning',
        title: 'Payment Delay Flag',
        desc: 'Ujjain Mandi - 12 farmers bank verification pending with state PFMS node',
        time: '09:45 AM',
        icon: 'clock'
      },
      {
        id: 'ALT-3',
        type: 'danger',
        title: 'Fraud Detection Warning',
        desc: 'Multiple simultaneous booking requests flagged: 2 farmers using identical land parcel number',
        time: '09:20 AM',
        icon: 'shield-alert'
      },
      {
        id: 'ALT-4',
        type: 'warning',
        title: 'Vehicle Congestion in Queue',
        desc: 'Dewas Hub - Tractor Trolley turnaround time crossed 45 minutes on Weighbridge #2',
        time: '07:14 AM',
        icon: 'truck'
      },
      {
        id: 'ALT-5',
        type: 'info',
        title: 'Offline Center Sync Completed',
        desc: 'Badnawar sub-center reconnected; 14 offline weighbridge tokens synced into state ledger',
        time: '06:45 AM',
        icon: 'wifi'
      }
    ]
  },
  dossiers: [
    {
      id: 'DOS-01',
      name: 'Ramesh Patil',
      phone: '9999990001',
      village: 'Baramati',
      district: 'Pune',
      state: 'Maharashtra',
      aadhaar: 'XXXX-XXXX-7821',
      aadhaarVerified: true,
      pmKisanId: 'PMK-MH-849200',
      landHolding: '3.5 Acres (7/12 Satbara)',
      bankName: 'State Bank of India (Baramati)',
      accountMasked: '••••4837',
      ifsc: 'SBIN0000324',
      token: 'PF-1024',
      totalProcuredQtl: 0,
      totalEarnings: 0,
      dbtSettled: 0,
      activeQueueCount: 1,
      queueStatus: '1 in Queue'
    },
    {
      id: 'DOS-02',
      name: 'Sunita Jadhav',
      phone: '9822014837',
      village: 'Indapur',
      district: 'Pune',
      state: 'Maharashtra',
      aadhaar: 'XXXX-XXXX-4837',
      aadhaarVerified: true,
      pmKisanId: 'PMK-MH-910244',
      landHolding: '4.2 Acres (7/12 Satbara)',
      bankName: 'State Bank of India (Baramati)',
      accountMasked: '••••4837',
      ifsc: 'SBIN0000324',
      token: 'PF-1024',
      totalProcuredQtl: 42.0,
      totalEarnings: 94764.60,
      dbtSettled: 0,
      activeQueueCount: 1,
      queueStatus: 'Awaiting DBT Release'
    },
    {
      id: 'DOS-03',
      name: 'Jyoti Khandagale',
      phone: '9765415143',
      village: 'Nandgaon',
      district: 'Pune',
      state: 'Maharashtra',
      aadhaar: 'XXXX-XXXX-5143',
      aadhaarVerified: true,
      pmKisanId: 'PMK-MH-623819',
      landHolding: '3.8 Acres (7/12 Satbara)',
      bankName: 'State Bank of India (Baramati)',
      accountMasked: '••••5143',
      ifsc: 'SBIN0000324',
      token: 'PF-1042',
      totalProcuredQtl: 38.5,
      totalEarnings: 87078.00,
      dbtSettled: 0,
      activeQueueCount: 1,
      queueStatus: 'Awaiting DBT Release'
    },
    {
      id: 'DOS-04',
      name: 'Ashok Randhive',
      phone: '9423182910',
      village: 'Igatpuri',
      district: 'Nashik',
      state: 'Maharashtra',
      aadhaar: 'XXXX-XXXX-2910',
      aadhaarVerified: true,
      pmKisanId: 'PMK-MH-338210',
      landHolding: '2.5 Acres (7/12 Satbara)',
      bankName: 'State Bank of India (Baramati)',
      accountMasked: '••••2910',
      ifsc: 'SBIN0000324',
      token: 'PF-1041',
      totalProcuredQtl: 24.0,
      totalEarnings: 52380.00,
      dbtSettled: 52380.00,
      activeQueueCount: 0,
      queueStatus: 'Bank Settled'
    }
  ]
};

class KisanStoreClass {
  constructor() {
    this.listeners = [];
    this.state = this.loadState();
  }

  loadState() {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (!parsed.dossiers || parsed.dossiers.length === 0) {
          parsed.dossiers = JSON.parse(JSON.stringify(DEFAULT_STATE.dossiers));
        }
        if (!parsed.center?.payments?.recentList || parsed.center.payments.recentList.length < 3) {
          parsed.center.payments = JSON.parse(JSON.stringify(DEFAULT_STATE.center.payments));
        }
        return parsed;
      }
    } catch (e) {
      console.warn('Could not load from localStorage', e);
    }
    return JSON.parse(JSON.stringify(DEFAULT_STATE));
  }

  saveState() {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(this.state));
    } catch (e) {
      console.warn('Could not save to localStorage', e);
    }
    this.notify();
  }

  subscribe(listener) {
    this.listeners.push(listener);
    return () => {
      this.listeners = this.listeners.filter(l => l !== listener);
    };
  }

  notify() {
    this.listeners.forEach(fn => {
      try {
        fn(this.state);
      } catch (err) {
        console.error('Listener notification error:', err);
      }
    });
  }

  getState() {
    return this.state;
  }

  // --- Auth & Session ---

  login(role, userDetails = {}) {
    this.state.auth.isLoggedIn = true;
    this.state.auth.currentRole = role;
    this.state.auth.user = userDetails;
    this.saveState();
  }

  logout() {
    this.state.auth.isLoggedIn = false;
    this.state.auth.currentRole = null;
    this.state.auth.user = null;
    this.saveState();
  }

  // --- Language ---

  setLanguage(lang) {
    this.state.currentLanguage = lang;
    this.saveState();
  }

  // --- Pan-India Regions & State Selection ---

  setSelectedState(stateName) {
    this.state.selectedState = stateName;
    const sObj = INDIAN_STATES.find(s => s.name.toLowerCase() === (stateName || '').toLowerCase());
    
    if (stateName.toLowerCase() === 'maharashtra') {
      this.state.selectedDistrict = 'All Districts';
      if (this.state.farmer && this.state.farmer.residence) {
        this.state.farmer.residence.state = 'Maharashtra';
        this.state.farmer.residence.district = 'Pune';
        this.state.farmer.residence.village = 'Baramati Rural (पुणे)';
      }
      if (this.state.center) {
        this.state.center.centerName = 'Pune APMC (Gultekdi Central Market Yard)';
      }
    } else if (sObj && sObj.districts && sObj.districts.length > 0) {
      this.state.selectedDistrict = 'All Districts';
      if (this.state.farmer && this.state.farmer.residence) {
        this.state.farmer.residence.state = stateName;
        this.state.farmer.residence.district = sObj.districts[0];
      }
    } else {
      this.state.selectedDistrict = 'All Districts';
    }
    this.saveState();
  }

  setSelectedDistrict(districtName) {
    this.state.selectedDistrict = districtName;
    if (this.state.farmer && this.state.farmer.residence && districtName && districtName !== 'All' && districtName !== 'All Districts') {
      this.state.farmer.residence.district = districtName;
    }
    this.saveState();
  }

  getDistrictsForState(stateName) {
    const st = stateName || this.state.selectedState || 'All India';
    if (!st || st === 'All India' || st === 'all') {
      const mh = INDIAN_STATES.find(s => s.name === 'Maharashtra');
      return mh ? mh.districts : [];
    }
    const sObj = INDIAN_STATES.find(s => s.name.toLowerCase() === st.toLowerCase());
    return sObj && sObj.districts ? sObj.districts : [];
  }

  setHeatmapFilterZone(zone) {
    this.state.selectedZone = zone;
    this.saveState();
  }

  toggleMobileCanvasMode() {
    this.state.mobileCanvasMode = !this.state.mobileCanvasMode;
    this.saveState();
    return this.state.mobileCanvasMode;
  }

  getIndianStates() {
    return INDIAN_STATES;
  }

  getAllIndiaMandis(filterState = null, filterZone = null, filterHeat = null, filterDistrict = null) {
    let list = ALL_INDIA_MANDIS.map(m => {
      const heat = m.congestionLevel || (m.status === 'High' ? 'high' : m.status === 'Moderate' ? 'moderate' : 'low');
      const status = heat === 'high' ? 'High' : heat === 'moderate' ? 'Moderate' : 'Normal';
      const avgWait = m.waitMins || m.avgWait || (heat === 'high' ? 55 : heat === 'moderate' ? 32 : 16);
      const liveQueue = m.vehiclesInQueue || m.liveQueue || (heat === 'high' ? 68 : heat === 'moderate' ? 38 : 14);
      const storagePct = m.storagePct || (m.storageCapacityMT ? Math.min(100, Math.round((m.currentStockMT / m.storageCapacityMT) * 100)) : (heat === 'high' ? 92 : heat === 'moderate' ? 74 : 45));
      const heatScore = m.heatScore || (heat === 'high' ? 88 : heat === 'moderate' ? 62 : 28);
      const detour = m.detour || (heat === 'high' ? 'High yard congestion. Rerouting to nearby sub-mandi saves ~35 mins.' : heat === 'moderate' ? 'Steady intake. Proceed to Bay 3 directly.' : null);

      return {
        ...m,
        status,
        congestionLevel: heat,
        avgWait,
        liveQueue,
        storagePct,
        heatScore,
        detour
      };
    });

    const st = filterState !== null && filterState !== undefined ? filterState : this.state.selectedState;
    const zn = filterZone !== null && filterZone !== undefined ? filterZone : this.state.selectedZone;
    const dt = filterDistrict !== null && filterDistrict !== undefined ? filterDistrict : this.state.selectedDistrict;

    if (st && st !== 'All India' && st !== 'all') {
      list = list.filter(m => m.state && m.state.toLowerCase() === st.toLowerCase());
    }

    if (dt && dt !== 'All' && dt !== 'All Districts' && dt !== 'all') {
      const cleanDt = dt.toLowerCase().replace(/\s*\(.*?\)\s*/g, '').trim();
      list = list.filter(m => {
        if (!m.district) return false;
        const cleanM = m.district.toLowerCase().replace(/\s*\(.*?\)\s*/g, '').trim();
        return cleanM.includes(cleanDt) || cleanDt.includes(cleanM);
      });
    }

    if (zn && zn !== 'all' && zn !== 'All' && zn !== 'National') {
      list = list.filter(m => m.zone && m.zone.toLowerCase() === zn.toLowerCase());
    }

    if (filterHeat && filterHeat !== 'all' && filterHeat !== 'All') {
      const hLower = filterHeat.toLowerCase();
      if (hLower === 'normal' || hLower === 'low') {
        list = list.filter(m => m.status === 'Normal' || m.congestionLevel === 'low');
      } else if (hLower === 'moderate' || hLower === 'medium') {
        list = list.filter(m => m.status === 'Moderate' || m.congestionLevel === 'moderate');
      } else if (hLower === 'heavy' || hLower === 'high') {
        list = list.filter(m => m.status === 'High' || m.congestionLevel === 'high');
      }
    }
    return list;
  }

  // --- AI Slot Allocation & Capacity Management ---

  getAiRecommendedSlot(crop, qty, vehicle) {
    const v = (vehicle || '').toLowerCase();
    let slot = '10:00 - 11:00 AM';
    let bay = 'Lane TT-01 (Express Tractor Ramp)';
    let waitMins = 8;
    let savingsMins = 27;

    if (v.includes('heavy') || v.includes('hauler') || v.includes('10-14')) {
      slot = '02:00 - 03:00 PM';
      bay = 'Lane HH-01 (High-Tonnage Weighbridge)';
      waitMins = 12;
      savingsMins = 32;
    } else if (v.includes('pickup') || v.includes('bolero')) {
      slot = '10:00 - 11:00 AM';
      bay = 'Lane PK-01 (Utility Rapid Gate)';
      waitMins = 6;
      savingsMins = 25;
    } else if (v.includes('bullock') || v.includes('cart')) {
      slot = '09:00 - 10:00 AM';
      bay = 'Lane BC-01 (Dedicated Cart Plinth)';
      waitMins = 5;
      savingsMins = 20;
    }

    return {
      slot,
      date: '15 Oct Today',
      estWaitMins: waitMins,
      savingsMins,
      confidenceScore: 98,
      recommendedBay: bay,
      reason: `AI scheduled for ${vehicle || 'Vehicle'} (${qty || 50} Qtl ${crop || 'Crop'}): ${bay} has 0 backlog and guaranteed prompt weighbridge intake.`
    };
  }

  toggleSlotBlock() {
    this.state.center.capacity.isBlocked = !this.state.center.capacity.isBlocked;
    this.saveState();
    return this.state.center.capacity.isBlocked;
  }

  adjustHourlyCapacity(delta) {
    let cap = (this.state.center.capacity.hourlyCapacity || 50) + delta;
    if (cap < 10) cap = 10;
    if (cap > 200) cap = 200;
    this.state.center.capacity.hourlyCapacity = cap;
    this.state.center.capacity.availableSlots = Math.max(0, cap - this.state.center.capacity.bookedSlots);
    this.saveState();
    return cap;
  }

  // --- Actions ---

  bookSlot(bookingData) {
    const nextTokenNum = this.state.center.kpis.todaysBookings + 1;
    const tokenLetter = String.fromCharCode(65 + (Math.floor(nextTokenNum / 100) % 26));
    const tokenDigits = String((nextTokenNum % 50) + 1).padStart(2, '0');
    const tokenId = `${tokenLetter}${tokenDigits}`;
    const bookingId = `AFG${new Date().getFullYear()}${String(Date.now()).slice(-7)}`;
    
    // Assign authentic parking lane based on real vehicle
    let assignedLane = 'Lane TT-04';
    const vType = bookingData.vehicleType || 'Tractor Trolley (2-Wheel)';

    if (vType.includes('Tractor Trolley')) {
      assignedLane = `Lane TT-${String(Math.floor(Math.random() * 15) + 1).padStart(2, '0')}`;
      this.state.center.parkingLanes.tractorTrolley.occupied = Math.min(20, this.state.center.parkingLanes.tractorTrolley.occupied + 1);
    } else if (vType.includes('Tractor Heavy')) {
      assignedLane = `Lane TH-${String(Math.floor(Math.random() * 10) + 1).padStart(2, '0')}`;
      this.state.center.parkingLanes.tractorHeavy.occupied = Math.min(15, this.state.center.parkingLanes.tractorHeavy.occupied + 1);
    } else if (vType.includes('Pickup')) {
      assignedLane = `Lane PK-${String(Math.floor(Math.random() * 8) + 1).padStart(2, '0')}`;
      this.state.center.parkingLanes.pickupBolero.occupied = Math.min(12, this.state.center.parkingLanes.pickupBolero.occupied + 1);
    } else if (vType.includes('6-Tyre')) {
      assignedLane = `Lane TR-${String(Math.floor(Math.random() * 8) + 1).padStart(2, '0')}`;
      this.state.center.parkingLanes.truck6Tyre.occupied = Math.min(10, this.state.center.parkingLanes.truck6Tyre.occupied + 1);
    } else if (vType.includes('Heavy')) {
      assignedLane = `Lane HH-${String(Math.floor(Math.random() * 5) + 1).padStart(2, '0')}`;
      this.state.center.parkingLanes.heavyHauler.occupied = Math.min(8, this.state.center.parkingLanes.heavyHauler.occupied + 1);
    } else {
      assignedLane = `Lane BC-02`;
      this.state.center.parkingLanes.bullockCart.occupied = Math.min(8, this.state.center.parkingLanes.bullockCart.occupied + 1);
    }

    const rate = bookingData.crop === 'Soybean' ? 4850 :
                 bookingData.crop === 'Wheat' ? 2275 :
                 bookingData.crop === 'Chana' ? 5440 :
                 bookingData.crop === 'Mustard' ? 5650 : 2183;
    const totalVal = Number(bookingData.quantity) * rate;

    this.state.farmer.activeToken = {
      bookingId: bookingId,
      id: tokenId,
      crop: bookingData.crop,
      qtyQuintal: Number(bookingData.quantity),
      mandi: bookingData.center || 'Centre A (Shivaji Nagar, Indore Mandi)',
      centerId: bookingData.centerId || 'centre_a',
      distanceKm: bookingData.distanceKm || '2.5 km',
      gate: 'Gate 2 (Tractor & Heavy Vehicle Yard)',
      date: bookingData.date || '15 Oct 2025',
      timeSlot: bookingData.timeSlot || '10:00 AM - 11:00 AM',
      vehicleType: bookingData.vehicleType,
      vehicleIcon: bookingData.vehicleIcon || '🚜',
      vehicleNo: bookingData.vehicleNo || 'MP-09-AB-1234',
      parkingLane: assignedLane,
      status: 'Confirmed',
      servingToken: this.state.center.queue[0]?.token || 'A-018',
      farmersAhead: Math.max(1, this.state.center.queue.filter(q => q.status === 'Waiting').length),
      estimatedWaitMins: 20,
      mspPerQtl: rate,
      expectedTotal: null,
      finalRate: null,
      finalAmount: null,
      priceStatus: 'Assessed on ground post-inspection',
      utrNo: `TXN${Date.now().toString().slice(-10)}`,
      isCheckedIn: false,
      qrData: `${bookingId}-${tokenId}`
    };

    // Update procurement steps
    this.state.farmer.procurementSteps = [
      { id: 1, name: 'Crop verification', status: 'completed', time: 'Completed (Gate Entry)', desc: `${bookingData.crop} variety & vehicle verified.` },
      { id: 2, name: 'Weighing', status: 'in_progress', time: 'In Progress', desc: 'Awaiting gross vehicle weighbridge entry.' },
      { id: 3, name: 'Quality check', status: 'pending', time: 'Pending', desc: 'Moisture analysis & FAQ grain grading.' },
      { id: 4, name: 'Acceptance & Ground Rate', status: 'pending', time: 'Pending', desc: 'Official ground rate determination & receipt sign-off.' },
      { id: 5, name: 'Procurement completed', status: 'pending', time: 'Pending', desc: 'Direct Benefit Transfer (DBT) payout upon approval.' }
    ];

    // Add to My Bookings list
    if (!this.state.farmer.bookings) this.state.farmer.bookings = [];
    this.state.farmer.bookings.unshift({
      bookingId: bookingId,
      token: tokenId,
      crop: bookingData.crop,
      qty: Number(bookingData.quantity),
      center: bookingData.center || 'Centre A (Shivaji Nagar, Indore)',
      date: bookingData.date || '15 Oct 2025',
      timeSlot: bookingData.timeSlot || '10:00 AM - 11:00 AM',
      status: 'Booked',
      vehicle: `${bookingData.vehicleType} ${bookingData.vehicleNo || ''}`,
      amount: 'To be assessed on ground'
    });

    // Add notification
    if (!this.state.farmer.notifications) this.state.farmer.notifications = [];
    this.state.farmer.notifications.unshift({
      id: Date.now(),
      title: 'Booking Confirmation',
      body: `Your slot (${bookingId} • Token ${tokenId}) for ${bookingData.crop} (${bookingData.quantity} Qtl) has been confirmed at ${bookingData.center || 'Centre A'}.`,
      time: 'Just now',
      tag: 'SMS',
      icon: 'check-circle'
    });

    // Add to Center Official Queue
    this.state.center.queue.push({
      token: tokenId,
      bookingId: bookingId,
      farmer: this.state.farmer.name,
      crop: bookingData.crop,
      qty: Number(bookingData.quantity),
      vehicle: bookingData.vehicleType,
      vehicleIcon: bookingData.vehicleIcon || '🚜',
      vehicleNo: bookingData.vehicleNo || 'MP-09-AB-1234',
      lane: assignedLane,
      arrival: 'Just now',
      status: 'Waiting',
      waitMins: 20
    });

    if (this.state.center.vehicleMovementLogs) {
      this.state.center.vehicleMovementLogs.unshift({
        token: tokenId,
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        action: 'Slot Booked',
        vehicle: `${bookingData.vehicleType} (${bookingData.vehicleNo || ''})`
      });
    }

    this.state.center.kpis.todaysBookings += 1;
    this.state.center.kpis.inQueue += 1;
    this.state.center.capacity.bookedSlots += 1;
    this.state.center.capacity.availableSlots = Math.max(0, this.state.center.capacity.hourlyCapacity - this.state.center.capacity.bookedSlots);

    this.state.district.kpis.totalBookings += 1;
    this.state.district.kpis.farmersToday += 1;
    this.saveState();

    // --- Live Backend Synchronization (MongoDB Atlas) ---
    if (window.KisanSetuApi && window.KisanSetuApi.isBackendConnected) {
      window.KisanSetuApi.getCenters().then(centers => {
        const center = centers && centers.length > 0 ? centers[0] : null;
        if (center) {
          window.KisanSetuApi.getSlots(center.centerId, new Date().toISOString().split('T')[0]).then(slots => {
            const slot = slots && slots.length > 0 ? slots[0] : null;
            if (slot) {
              window.KisanSetuApi.bookSlot({
                centerId: center._id,
                slotId: slot._id,
                crop: bookingData.crop || 'Wheat',
                expectedQuantityQtl: Number(bookingData.quantity) || 50,
                vehicle: {
                  vehicleType: 'TRACTOR_TROLLEY',
                  vehicleNumber: bookingData.vehicleNo || 'MP-09-AB-1234'
                }
              }).then(res => {
                if (res && res.booking) {
                  console.log('✅ [Live Backend]: Booking synced to MongoDB Atlas!', res.booking.bookingId);
                  window.KisanSetuApi.showToast(`✅ Synced with MongoDB Atlas! Token: ${res.booking.token?.displayToken}`, 'success');
                }
              }).catch(e => console.warn('Live booking sync note:', e.message));
            }
          }).catch(() => {});
        }
      }).catch(() => {});
    }

    return this.state.farmer.activeToken;
  }

  performGateCheckin(tokenId) {
    const token = tokenId || this.state.farmer.activeToken.id;
    this.state.farmer.activeToken.status = 'Checked-In';
    this.state.farmer.activeToken.isCheckedIn = true;
    
    // Update procurement step
    if (this.state.farmer.procurementSteps) {
      this.state.farmer.procurementSteps[0].status = 'completed';
      this.state.farmer.procurementSteps[0].time = 'Completed (Gate Entry)';
      this.state.farmer.procurementSteps[1].status = 'in_progress';
      this.state.farmer.procurementSteps[1].time = 'In Progress';
    }

    // Update in bookings array
    if (this.state.farmer.bookings) {
      const b = this.state.farmer.bookings.find(x => x.token === token || x.bookingId === this.state.farmer.activeToken.bookingId);
      if (b) {
        b.status = 'In Progress';
      }
    }

    // Add notification
    if (!this.state.farmer.notifications) this.state.farmer.notifications = [];
    this.state.farmer.notifications.unshift({
      id: Date.now(),
      title: 'Gate Check-In Verified',
      body: `QR Code verified at Mandi Gate! Vehicle admitted. Proceed to ${this.state.farmer.activeToken.parkingLane}.`,
      time: 'Just now',
      tag: 'Gate',
      icon: 'check-circle'
    });

    // Update queue in center
    const existing = this.state.center.queue.find(q => q.token === token);
    if (existing) {
      existing.status = 'Waiting';
      existing.arrival = 'Gate Check-In: ' + new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    }

    this.saveState();
    return true;
  }

  callNextToken() {
    const queue = this.state.center.queue;
    if (!queue || queue.length === 0) return null;

    // 1. Move currently serving vehicle to 'Completed'
    const currentServing = queue.find(q => q.status === 'Serving');
    if (currentServing) {
      currentServing.status = 'Completed';
      this.state.center.kpis.completed = (this.state.center.kpis.completed || 0) + 1;
      this.state.center.kpis.inQueue = Math.max(0, (this.state.center.kpis.inQueue || 1) - 1);
    }

    // 2. Strict deterministic FIFO: find next vehicle waiting in queue
    let nextVehicle = queue.find(q => q.status === 'Waiting' || q.status === 'Checked-In');

    // 3. Fallback generator: if queue reached the end, automatically generate the next sequential token so the button never stops working!
    if (!nextVehicle) {
      const lastToken = queue[queue.length - 1]?.token || 'A-023';
      const numMatch = lastToken.match(/\d+/);
      const nextNum = numMatch ? parseInt(numMatch[0], 10) + 1 : 24;
      const nextTokenStr = `A-${String(nextNum).padStart(3, '0')}`;
      
      nextVehicle = {
        token: nextTokenStr,
        farmer: 'Farmer ' + nextTokenStr,
        crop: 'Wheat (Sharbati)',
        qty: 50,
        vehicle: 'Tractor Trolley (2-Wheel)',
        vehicleIcon: '🚜',
        vehicleNo: `MP-09-XY-${nextNum}00`,
        lane: 'Lane TT-02',
        arrival: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        status: 'Waiting',
        waitMins: 0
      };
      queue.push(nextVehicle);
    }

    // 4. Set status to Serving & assign Weighbridge Bay
    nextVehicle.status = 'Serving';
    nextVehicle.assignedBay = 'BAY-01 (Electronic Weighbridge)';
    
    // 5. Update Farmer Active Token status & serving pointer
    this.state.farmer.activeToken.servingToken = nextVehicle.token;
    if (this.state.farmer.activeToken.id === nextVehicle.token) {
      this.state.farmer.activeToken.status = 'Serving';
      if (this.state.farmer.procurementSteps) {
        this.state.farmer.procurementSteps[1].status = 'in_progress';
        this.state.farmer.procurementSteps[1].desc = 'Your vehicle is now CALLED to Weighbridge Bay 1! Proceed immediately.';
      }
    }

    // 6. Record movement log
    if (this.state.center.vehicleMovementLogs) {
      this.state.center.vehicleMovementLogs.unshift({
        token: nextVehicle.token,
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        action: 'Called to Weighbridge',
        vehicle: `${nextVehicle.vehicle} (${nextVehicle.farmer})`
      });
    }

    this.saveState();

    // --- Live Backend Synchronization (Call Next via MongoDB Atlas) ---
    if (window.KisanSetuApi && window.KisanSetuApi.isBackendConnected) {
      window.KisanSetuApi.getCenters().then(centers => {
        const center = centers && centers.length > 0 ? centers[0] : null;
        if (center) {
          window.KisanSetuApi.callNextVehicle(center._id, 'BAY-01').then(res => {
            console.log('✅ [Live Backend]: Called next vehicle via MongoDB Atlas!', res);
          }).catch(() => {});
        }
      }).catch(() => {});
    }

    return nextVehicle;
  }

  saveQCAndWeighment(data) {
    const { token, moisture, grade, acceptedQty, rejectedQty, assessedRate } = data;
    const netQty = Number(acceptedQty) || 50;
    const rate = Number(assessedRate) || (grade === 'A' ? 2275 : 2150);
    const finalTotal = Math.round(netQty * rate);

    const item = this.state.center.queue.find(q => q.token === token);
    if (item) {
      item.status = 'Completed';
      item.assessedRate = rate;
      item.finalAmount = finalTotal;
    }
    
    this.state.center.kpis.inQueue = Math.max(0, this.state.center.kpis.inQueue - 1);
    this.state.center.kpis.completed = (this.state.center.kpis.completed || 0) + 1;

    const additionalMT = netQty / 10;
    this.state.center.storage.currentStockMT = Math.min(
      this.state.center.storage.totalCapacityMT,
      this.state.center.storage.currentStockMT + additionalMT
    );
    this.state.center.storage.percentage = Math.round(
      (this.state.center.storage.currentStockMT / this.state.center.storage.totalCapacityMT) * 100
    );

    this.state.district.kpis.totalProcurementMT += Math.round(additionalMT);

    // DIRECT REAL-TIME UPDATE TO FARMER PROCUREMENT TRACKING STEPS
    const activeFarmerToken = this.state.farmer.activeToken;
    const isThisFarmer = activeFarmerToken.id === token || token === 'A-018' || token === 'A-023' || !activeFarmerToken.id;

    if (isThisFarmer) {
      activeFarmerToken.status = 'QC_Approved';
      activeFarmerToken.certifiedNetWeight = netQty;
      activeFarmerToken.moisture = moisture;
      activeFarmerToken.grade = grade;
      activeFarmerToken.finalRate = rate;
      activeFarmerToken.finalAmount = finalTotal;

      if (this.state.farmer.procurementSteps) {
        // Step 1: Crop verification
        this.state.farmer.procurementSteps[0].status = 'completed';
        this.state.farmer.procurementSteps[0].time = 'Verified at Intake Gate';

        // Step 2: Weighing
        this.state.farmer.procurementSteps[1].status = 'completed';
        this.state.farmer.procurementSteps[1].time = 'Certified Just now';
        this.state.farmer.procurementSteps[1].desc = `Certified Net Weight: ${netQty} Qtl (Electronic Weighbridge Scale Passed).`;

        // Step 3: Quality check
        this.state.farmer.procurementSteps[2].status = 'completed';
        this.state.farmer.procurementSteps[2].time = 'Approved Just now';
        this.state.farmer.procurementSteps[2].desc = `Grade ${grade} FAQ Approved • Moisture: ${moisture}% (Within standard limit ≤12%).`;

        // Step 4: Acceptance & Ground Rate
        this.state.farmer.procurementSteps[3].status = 'completed';
        this.state.farmer.procurementSteps[3].time = 'Certified Just now';
        this.state.farmer.procurementSteps[3].desc = `Ground Rate Fixed: ₹${rate.toLocaleString('en-IN')}/Qtl • Total Payable: ₹${finalTotal.toLocaleString('en-IN')} (Signed by Superintendent).`;

        // Step 5: Ready for DBT
        this.state.farmer.procurementSteps[4].status = 'in_progress';
        this.state.farmer.procurementSteps[4].time = 'Ready for Payout';
        this.state.farmer.procurementSteps[4].desc = `Payable Amount: ₹${finalTotal.toLocaleString('en-IN')} queued for Direct Bank Transfer (DBT).`;
      }
    }

    // Queue payment for DBT release
    this.state.center.payments.recentList.unshift({
      token: token,
      farmer: item ? item.farmer : 'Farmer',
      crop: item ? item.crop : 'Wheat',
      qty: netQty,
      rate: rate,
      amount: finalTotal,
      status: 'Pending',
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    });
    this.state.center.payments.pendingCount = (this.state.center.payments.pendingCount || 0) + 1;

    this.state.center.vehicleMovementLogs.unshift({
      token: token,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      action: 'QC & Weighment Approved',
      vehicle: `${item ? item.vehicle : 'Tractor Trolley'} (Rate: ₹${rate} • Net: ${netQty} Qtl)`
    });

    this.saveState();

    if (window.KisanSetuApi && window.KisanSetuApi.isBackendConnected) {
      window.KisanSetuApi.showToast(`✅ Certified Net Weight (${netQty} Qtl) & Ground Rate (₹${rate}/Qtl) saved!`, 'success');
    }
  }

  processBulkDBT() {
    const pending = this.state.center.payments.recentList.filter(p => p.status === 'Pending');
    let totalAmt = 0;
    
    pending.forEach(p => {
      p.status = 'Success';
      totalAmt += p.amount;
    });

    this.state.center.payments.successCount += (this.state.center.payments.pendingCount || 0);
    this.state.center.payments.pendingCount = 0;

    // DIRECT REAL-TIME UPDATE: Step 5 (Procurement completed) marked completed!
    const activeFarmerToken = this.state.farmer.activeToken;
    const finalPaidAmt = activeFarmerToken.finalAmount || totalAmt || 113750;

    if (this.state.farmer.procurementSteps && this.state.farmer.procurementSteps.length >= 5) {
      this.state.farmer.procurementSteps[4].status = 'completed';
      this.state.farmer.procurementSteps[4].time = 'Transferred (DBT Success)';
      this.state.farmer.procurementSteps[4].desc = `₹${finalPaidAmt.toLocaleString('en-IN')} credited to Bank of India (A/C •••• 4821) via PFMS • UTR: ${activeFarmerToken.utrNo || 'TXN893120194812'}`;
    }

    activeFarmerToken.status = 'Paid';
    activeFarmerToken.isPaid = true;

    const addlCr = totalAmt / 10000000;
    this.state.district.kpis.amountPaidCr = Number(((this.state.district.kpis.amountPaidCr || 0) + addlCr).toFixed(2));

    this.saveState();

    if (window.KisanSetuApi && window.KisanSetuApi.isBackendConnected) {
      window.KisanSetuApi.showToast(`💰 DBT Payout Batch of ₹${totalAmt.toLocaleString('en-IN')} credited via PFMS!`, 'success');
    }
    return totalAmt;
  }

  processSingleDBT(tokenOrRef, disbursementMode = 'Instant Transfer (Real-time NEFT credit)') {
    const list = this.state.center.payments.recentList;
    const item = list.find(p => p.token === tokenOrRef || p.txnRef === tokenOrRef);
    if (!item) return null;

    item.status = 'Settled';
    item.disbursementMode = disbursementMode;
    item.settledAt = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    item.utr = 'PFMS' + Date.now().toString().slice(-10);

    // Update balances
    const amt = Number(item.amount) || 0;
    this.state.center.payments.toBePaidAmount = Math.max(0, (this.state.center.payments.toBePaidAmount || 181842.60) - amt);
    this.state.center.payments.paidTodayAmount = (this.state.center.payments.paidTodayAmount || 52380.00) + amt;
    this.state.center.payments.pendingCount = Math.max(0, (this.state.center.payments.pendingCount || 1) - 1);
    this.state.center.payments.successCount = (this.state.center.payments.successCount || 0) + 1;

    // Sync Farmer Dossier
    if (this.state.dossiers) {
      const dos = this.state.dossiers.find(d => d.name === item.farmer || d.token === item.token);
      if (dos) {
        dos.dbtSettled = (dos.dbtSettled || 0) + amt;
        dos.queueStatus = 'Bank Settled';
      }
    }

    // Sync logged in farmer active token
    const activeFarmerToken = this.state.farmer?.activeToken;
    if (activeFarmerToken && (activeFarmerToken.id === item.token || this.state.farmer.name === item.farmer)) {
      activeFarmerToken.status = 'Paid';
      activeFarmerToken.isPaid = true;
      activeFarmerToken.utrNo = item.utr;
      activeFarmerToken.finalAmount = amt;
      if (this.state.farmer.procurementSteps && this.state.farmer.procurementSteps.length >= 5) {
        this.state.farmer.procurementSteps[4].status = 'completed';
        this.state.farmer.procurementSteps[4].time = 'Transferred (DBT Success)';
        this.state.farmer.procurementSteps[4].desc = `₹${amt.toLocaleString('en-IN')} credited to ${item.bank || 'Bank'} (${item.account || '••••4837'}) via PFMS • UTR: ${item.utr}`;
      }
    }

    // Add to movement logs
    if (this.state.center.vehicleMovementLogs) {
      this.state.center.vehicleMovementLogs.unshift({
        token: item.token,
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        action: 'DBT Bank Settled',
        vehicle: `${item.farmer} (₹${amt.toLocaleString('en-IN')} via ${disbursementMode.includes('Instant') ? 'NEFT' : 'MSP Batch'})`
      });
    }

    this.saveState();

    if (window.KisanSetuApi && window.KisanSetuApi.isBackendConnected) {
      window.KisanSetuApi.showToast(`🎉 ₹${amt.toLocaleString('en-IN')} credited to ${item.farmer} via PFMS!`, 'success');
    }

    return item;
  }

  toggleSlotBlock() {
    this.state.center.capacity.isBlocked = !this.state.center.capacity.isBlocked;
    this.saveState();
    return this.state.center.capacity.isBlocked;
  }

  applyAIMitigation() {
    this.state.district.aiPrediction.active = false;
    this.state.center.parkingLanes.tractorTrolley.total += 5;
    this.state.center.parkingLanes.tractorTrolley.occupied = Math.max(0, this.state.center.parkingLanes.tractorTrolley.occupied - 3);
    this.state.district.kpis.avgWaitMins = Math.max(15, this.state.district.kpis.avgWaitMins - 7);
    
    this.state.district.alerts.unshift({
      id: `ALT-${Date.now()}`,
      type: 'info',
      title: 'AI Mitigation Executed',
      desc: 'Opened 5 Auxiliary Tractor Weighing Bays at Indore & staggered 20 truck slots to avoid choke.',
      time: 'Just now',
      icon: 'check-circle'
    });

    this.saveState();
  }

  resetDemoData() {
    localStorage.removeItem(STORAGE_KEY);
    this.state = JSON.parse(JSON.stringify(DEFAULT_STATE));
    this.saveState();
  }
}

// Global singleton instance
window.KisanStore = new KisanStoreClass();
window.REAL_FARM_VEHICLES = REAL_FARM_VEHICLES;
window.INDIAN_STATES = INDIAN_STATES;
window.ALL_INDIA_MANDIS = ALL_INDIA_MANDIS;

