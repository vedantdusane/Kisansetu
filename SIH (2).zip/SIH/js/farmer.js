/**
 * KisanSetu / AgriFlow - Farmer Portal Controller
 * Full layout matching AgriFlow reference:
 * 1. Screen 3: Dashboard with 6 Quick Action Grid Cards + Voice Assistance
 * 2. Screens 4-8: Slot Booking Wizard (Crop Details -> Centre Recommendation -> Live Queue & Slot -> Confirm -> Digital Token & QR)
 * 3. Screen 16: QR Gate Check-in
 * 4. Screen 10: Live Queue Tracking with Farmers Ahead & Wait Times
 * 5. Screens 11 & 12: 5-Stage Procurement Process Stepper
 * 6. Screen 13: Direct Benefit Transfer (DBT) Payment Status & History
 * 7. Screen 14: Notification Feed
 * 8. Screen 9: My Bookings with Status Filter Tabs
 * Fully localized in 7 Indian Languages via window.t().
 */

// --- 100% Smartphone Camera Scannable QR Code Generator ---
function generateQRCodeSVG(text, size = 180) {
  const safeText = text || 'KISANSETU:TOKEN:A12:GATEPASS:MANDI:INDORE';
  const encoded = encodeURIComponent(safeText);

  return `
    <div class="inline-block p-3 bg-white rounded-3xl border-2 border-slate-200 shadow-md">
      <img src="https://api.qrserver.com/v1/create-qr-code/?size=${size}x${size}&margin=3&data=${encoded}" 
           alt="Certified Mandi QR Pass" 
           width="${size}" 
           height="${size}"
           class="mx-auto rounded-xl block shadow-xs bg-white"
           loading="eager"
           onerror="this.onerror=null; this.src='https://chart.googleapis.com/chart?cht=qr&chs=${size}x${size}&chl=${encoded}';" />
      <div class="mt-2 text-center">
        <span class="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-black bg-emerald-100 text-emerald-800 border border-emerald-300">
          <span>📷</span> <span>100% Camera Scannable QR</span>
        </span>
      </div>
    </div>
  `;
}

class FarmerPortalController {
  constructor() {
    this.activeView = 'dashboard'; // 'dashboard', 'book-step1', 'book-step2', 'book-step3', 'book-step4', 'token-qr', 'qr-checkin', 'live-queue', 'procurement', 'payment', 'notifications', 'bookings'
    
    this.wizardCrop = 'Wheat';
    this.wizardQty = 50;
    this.wizardDate = '15 Oct 2025';
    this.wizardVehicle = 'Tractor Trolley (2-Wheel)';
    this.wizardVehicleIcon = '🚜';
    this.wizardVehicleNo = 'MP-09-AB-1234';
    this.wizardCentre = {
      id: 'centre_a',
      name: 'Centre A (Nakane road, Dhule Mandi)',
      dist: '2.5 km',
      cap: '2,500 q',
      queue: 12,
      slots: 18,
      crops: ['Wheat', 'Soybean']
    };
    this.wizardDateSlot = '15 Oct Today';
    this.wizardTimeSlot = '10:00 - 11:00 AM';
    this.wizardDistrict = 'All Districts';

    this.bookingsFilter = 'all';

    this.cropRates = {
      Wheat: 2275,
      Soybean: 4850,
      Chana: 5440,
      Mustard: 5650,
      Paddy: 2183
    };

    this.centresList = [
      {
        id: 'centre_a',
        name: 'Centre A (Nakane Road, Dhule Mandi)',
        dist: '2.5 km',
        cap: '2,500 q',
        queue: 12,
        slots: 18,
        crops: ['Wheat', 'Soybean']
      },
      {
        id: 'centre_b',
        name: 'Centre B (surat-bypass Road, Sakri Mandi)',
        dist: '45.0 km',
        cap: '1,800 q',
        queue: 5,
        slots: 25,
        crops: ['Wheat', 'Chana']
      },
      {
        id: 'centre_c',
        name: 'Centre C (Shindkedha Mandi Hub)',
        dist: '80.2 km',
        cap: '1,200 q',
        queue: 15,
        slots: 10,
        crops: ['Wheat', 'Mustard']
      }
    ];
  }

  init() {
    this.render();
    window.KisanStore.subscribe(() => {
      this.render();
    });
  }

  setView(viewName) {
    this.activeView = viewName;
    this.render();
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  setBookingsFilter(filter) {
    this.bookingsFilter = filter;
    this.render();
  }

  selectWizardCrop(crop) {
    this.wizardCrop = crop;
    this.updateCalculation(this.wizardQty);
    this.render();
  }

  selectWizardVehicle(vName, icon) {
    this.wizardVehicle = vName;
    this.wizardVehicleIcon = icon;
    this.render();
  }

  adjustWizardQty(delta) {
    let q = (parseFloat(this.wizardQty) || 50) + delta;
    if (q < 5) q = 5;
    if (q > 500) q = 500;
    this.wizardQty = q;
    const input = document.getElementById('wizard-qty-input');
    if (input) input.value = q;
    this.updateCalculation(q);
  }

  updateCalculation(qty) {
    const rate = this.cropRates[this.wizardCrop] || 2275;
    const total = qty * rate;
    const el = document.getElementById('wizard-calc-display');
    if (el) {
      el.innerHTML = `
        <div class="flex items-center justify-between text-slate-600 text-xs sm:text-sm">
          <span>Govt MSP Rate: <strong>₹${rate.toLocaleString('en-IN')}/Qtl</strong></span>
          <span>${qty} Qtl (${(qty / 10).toFixed(1)} Tonnes)</span>
        </div>
        <div class="mt-1 text-2xl font-black text-emerald-700 font-mono">
          ₹${total.toLocaleString('en-IN')}
        </div>
      `;
    }
  }

  selectCentreAndProceed(centreObj) {
    this.wizardCentre = centreObj;
    const aiRec = (window.KisanStore && typeof window.KisanStore.getAiRecommendedSlot === 'function') ?
      window.KisanStore.getAiRecommendedSlot(this.wizardCrop, this.wizardQty, this.wizardVehicle) : null;
    if (aiRec) {
      this.wizardDateSlot = aiRec.date;
      this.wizardTimeSlot = aiRec.slot;
    }
    this.setView('book-step3');
  }

  applyAiSlot(dateSlot, timeSlot) {
    this.wizardDateSlot = dateSlot || '15 Oct Today';
    this.wizardTimeSlot = timeSlot || '10:00 - 11:00 AM';
    this.render();
    if (window.App && typeof window.App.showToast === 'function') {
      window.App.showToast('🤖 AI Recommended Slot Applied: ' + this.wizardTimeSlot + ' (Min Gate Wait)', 'success');
    }
  }

  setFilterDistrict(districtName) {
    this.wizardDistrict = districtName;
    if (window.KisanStore && typeof window.KisanStore.setSelectedDistrict === 'function') {
      window.KisanStore.setSelectedDistrict(districtName);
    }
    this.render();
  }

  handleWizardConfirmBooking() {
    const vehicleNoInput = document.getElementById('wizard-veh-no');
    if (vehicleNoInput) this.wizardVehicleNo = vehicleNoInput.value || 'MP-09-AB-1234';

    window.KisanStore.bookSlot({
      crop: this.wizardCrop,
      quantity: this.wizardQty,
      center: this.wizardCentre.name,
      centerId: this.wizardCentre.id,
      distanceKm: this.wizardCentre.dist,
      date: this.wizardDate,
      timeSlot: this.wizardTimeSlot,
      vehicleType: this.wizardVehicle,
      vehicleIcon: this.wizardVehicleIcon,
      vehicleNo: this.wizardVehicleNo
    });

    if (window.AppAudio) window.AppAudio.playSuccess();
    this.setView('token-qr');
  }

  handleGateCheckIn() {
    window.KisanStore.performGateCheckin();
    if (window.AppAudio) window.AppAudio.playSuccess();
    alert('✅ Gate Check-In Verified!\nQR Code Scanned by Mandi Gate Security. Proceed to assigned parking lane.');
    this.render();
  }

  playVoiceAssistant() {
    const text = window.t('voiceText');
    const lang = window.KisanStore.getState().currentLanguage || 'en';

    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.rate = 0.92;
      const langMap = { hi: 'hi-IN', mr: 'mr-IN', pa: 'pa-IN', gu: 'gu-IN', bn: 'bn-IN', ta: 'ta-IN', en: 'en-IN' };
      utterance.lang = langMap[lang] || 'en-IN';
      window.speechSynthesis.speak(utterance);
    } else {
      alert(`[Voice Assistant]: "${text}"`);
    }
  }

  render() {
    const container = document.getElementById('section-farmer-portal');
    if (!container) return;

    const state = window.KisanStore.getState();
    const farmer = state.farmer;
    const token = farmer.activeToken || {};
    const t = window.t;

    let contentHtml = '';
    switch (this.activeView) {
      case 'book-step1':
        contentHtml = this.renderBookStep1(t);
        break;
      case 'book-step2':
        contentHtml = this.renderBookStep2(t);
        break;
      case 'book-step3':
        contentHtml = this.renderBookStep3(t);
        break;
      case 'book-step4':
        contentHtml = this.renderBookStep4(t);
        break;
      case 'token-qr':
        contentHtml = this.renderTokenQR(t, token);
        break;
      case 'qr-checkin':
        contentHtml = this.renderQRCheckin(t, token);
        break;
      case 'live-queue':
        contentHtml = this.renderLiveQueue(t, farmer);
        break;
      case 'procurement':
        contentHtml = this.renderProcurement(t, farmer, token);
        break;
      case 'payment':
        contentHtml = this.renderPayment(t, farmer, token);
        break;
      case 'notifications':
        contentHtml = this.renderNotifications(t, farmer);
        break;
      case 'bookings':
        contentHtml = this.renderMyBookings(t, farmer);
        break;
      case 'dashboard':
      default:
        contentHtml = this.renderDashboard(t, farmer, token);
        break;
    }

    container.innerHTML = `
      <div class="space-y-6 max-w-5xl mx-auto pb-12">
        <div class="bg-white rounded-2xl p-2 sm:p-3 border border-slate-200 shadow-sm flex items-center justify-between gap-2 overflow-x-auto">
          <div class="flex items-center gap-1.5 sm:gap-2 min-w-max">
            <button onclick="FarmerPortal.setView('dashboard')" class="px-3 py-1.5 rounded-xl text-xs sm:text-sm font-bold transition flex items-center gap-1.5 ${this.activeView === 'dashboard' ? 'bg-emerald-600 text-white' : 'text-slate-700 hover:bg-slate-100'}">
              <span>🏠</span> <span>${t('tabDashboard')}</span>
            </button>
            <button onclick="FarmerPortal.setView('book-step1')" class="px-3 py-1.5 rounded-xl text-xs sm:text-sm font-bold transition flex items-center gap-1.5 ${this.activeView.startsWith('book-') ? 'bg-emerald-600 text-white' : 'text-slate-700 hover:bg-slate-100'}">
              <span>📅</span> <span>${t('quickBookSlot')}</span>
            </button>
            <button onclick="FarmerPortal.setView('token-qr')" class="px-3 py-1.5 rounded-xl text-xs sm:text-sm font-bold transition flex items-center gap-1.5 ${this.activeView === 'token-qr' ? 'bg-emerald-600 text-white' : 'text-slate-700 hover:bg-slate-100'}">
              <span>🎫</span> <span>Token (${token.id || 'A12'})</span>
            </button>
            <button onclick="FarmerPortal.setView('qr-checkin')" class="px-3 py-1.5 rounded-xl text-xs sm:text-sm font-bold transition flex items-center gap-1.5 ${this.activeView === 'qr-checkin' ? 'bg-emerald-600 text-white' : 'text-slate-700 hover:bg-slate-100'}">
              <span>📱</span> <span>QR Check-in</span>
            </button>
            <button onclick="FarmerPortal.setView('live-queue')" class="px-3 py-1.5 rounded-xl text-xs sm:text-sm font-bold transition flex items-center gap-1.5 ${this.activeView === 'live-queue' ? 'bg-emerald-600 text-white' : 'text-slate-700 hover:bg-slate-100'}">
              <span>👥</span> <span>${t('quickLiveQueue')}</span>
            </button>
            <button onclick="FarmerPortal.setView('procurement')" class="px-3 py-1.5 rounded-xl text-xs sm:text-sm font-bold transition flex items-center gap-1.5 ${this.activeView === 'procurement' ? 'bg-emerald-600 text-white' : 'text-slate-700 hover:bg-slate-100'}">
              <span>⚖️</span> <span>${t('quickProcurement')}</span>
            </button>
            <button onclick="FarmerPortal.setView('payment')" class="px-3 py-1.5 rounded-xl text-xs sm:text-sm font-bold transition flex items-center gap-1.5 ${this.activeView === 'payment' ? 'bg-emerald-600 text-white' : 'text-slate-700 hover:bg-slate-100'}">
              <span>💳</span> <span>${t('quickPayment')}</span>
            </button>
            <button onclick="FarmerPortal.setView('notifications')" class="px-3 py-1.5 rounded-xl text-xs sm:text-sm font-bold transition flex items-center gap-1.5 ${this.activeView === 'notifications' ? 'bg-emerald-600 text-white' : 'text-slate-700 hover:bg-slate-100'}">
              <span>🔔</span> <span>${t('quickNotifications')}</span>
            </button>
            <button onclick="FarmerPortal.setView('bookings')" class="px-3 py-1.5 rounded-xl text-xs sm:text-sm font-bold transition flex items-center gap-1.5 ${this.activeView === 'bookings' ? 'bg-emerald-600 text-white' : 'text-slate-700 hover:bg-slate-100'}">
              <span>📋</span> <span>${t('quickMyBookings')}</span>
            </button>
          </div>
        </div>

        ${contentHtml}
      </div>
    `;

    try {
      if (window.lucide && typeof window.lucide.createIcons === 'function') {
        window.lucide.createIcons();
      }
    } catch (e) {
      console.warn('Lucide icons error in FarmerPortal:', e);
    }
  }

  // =========================================================================
  // 1. SCREEN 3: FARMER DASHBOARD (6 Quick Action Grid Cards + Voice Assist)
  // =========================================================================
  renderDashboard(t, farmer, token) {
    const res = farmer.residence || {};
    const land = farmer.land || {};
    const state = window.KisanStore ? window.KisanStore.getState() : {};
    const currentState = state.selectedState || 'All India';

    return `
      <div class="space-y-6">
        <!-- Farm Hero Banner with Golden Wheat Emblem (Reference Image Match) -->
        <div class="farm-hero-card !min-h-[260px] !p-6 sm:!p-8">
          <div class="gold-wheat-medallion !w-16 !h-16 !text-2xl !mb-2">
            🌾
          </div>
          <h2 class="text-2xl sm:text-3xl font-black text-white tracking-tight drop-shadow">
            ${t('appBrandTitle')}
          </h2>
          <p class="text-xs sm:text-sm text-yellow-200 font-bold mt-1 drop-shadow max-w-md">
            ${t('appSlogan')}
          </p>
          <div class="flex items-center gap-2 mt-3 flex-wrap justify-center">
            <span class="px-2.5 py-1 rounded-full text-xs font-black bg-emerald-950/80 text-yellow-300 border border-yellow-400/40">
              Region: ${currentState}
            </span>
            <button onclick="App.openGlobalHeatmap()" class="px-3 py-1 rounded-full text-xs font-bold bg-yellow-400 text-emerald-950 hover:bg-yellow-300 transition flex items-center gap-1 shadow">
              <span>🗺️</span> <span>${t('heatmapTitle')}</span>
            </button>
          </div>
        </div>

        <!-- Top Greeting Header -->
        <div class="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-sm flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div class="flex items-center gap-4">
            <div class="w-16 h-16 rounded-2xl bg-emerald-100 text-emerald-700 text-3xl font-black flex items-center justify-center flex-shrink-0">
              🌾
            </div>
            <div>
              <h2 class="text-2xl sm:text-3xl font-black text-slate-900">${t('helloFarmer')}</h2>
              <p class="text-xs sm:text-sm text-slate-500 font-medium mt-0.5">
                ${farmer.name} • ${res.village || 'Sanwer Khurd'}, ${res.district || 'Indore'} • +91 ${farmer.phone || '9876543210'}
              </p>
              <div class="flex items-center gap-2 mt-2 flex-wrap text-xs">
                <span class="px-2.5 py-1 rounded-full bg-emerald-50 text-emerald-800 font-bold border border-emerald-200 flex items-center gap-1">
                  <span>✓</span> Land Holding: ${land.totalAcres || '6.5'} Acres (${land.bighaEquivalent || '16.25 Bigha'})
                </span>
                <span class="px-2.5 py-1 rounded-full bg-blue-50 text-blue-800 font-bold border border-blue-200">
                  Khasra: ${land.khasraNo || '142/3'} • RoR Certified
                </span>
              </div>
            </div>
          </div>

          <div class="flex items-center gap-2">
            <button onclick="FarmerPortal.playVoiceAssistant()" class="px-4 py-2.5 rounded-2xl bg-emerald-50 hover:bg-emerald-100 text-emerald-800 font-bold text-xs sm:text-sm border border-emerald-200 transition flex items-center gap-2 shadow-sm">
              <i data-lucide="volume-2" class="w-4 h-4"></i>
              <span>${t('voiceHelpBtn')}</span>
            </button>
          </div>
        </div>

        <!-- Green Registration / Active Verification Banner (Screen 3) -->
        <div class="p-4 sm:p-5 bg-emerald-50 border border-emerald-200 rounded-2xl flex items-center gap-3 shadow-sm">
          <div class="w-10 h-10 rounded-full bg-emerald-600 text-white flex items-center justify-center text-lg flex-shrink-0 font-black">
            ✓
          </div>
          <div>
            <h4 class="text-sm font-extrabold text-emerald-900">${t('verifiedFarmerBanner')}</h4>
            <p class="text-xs text-emerald-700 mt-0.5">
              Verified for ${res.district || 'Indore'} Division Mandis. Bookings, live queues, and payments are active.
            </p>
          </div>
        </div>

        <!-- Prominent Active Token & Scannable QR Gate Pass Banner -->
        ${token && token.id ? `
          <div class="p-5 sm:p-6 bg-white border-2 border-emerald-500 rounded-3xl shadow-sm flex flex-col md:flex-row items-center justify-between gap-5">
            <div class="flex items-center gap-4">
              <div class="p-2 bg-slate-50 rounded-2xl border border-slate-200 flex-shrink-0">
                <img src="https://api.qrserver.com/v1/create-qr-code/?size=110x110&margin=2&data=${encodeURIComponent(`KISANSETU:TOKEN:${token.id}:BOOKING:${token.bookingId || 'AFG20251015001'}:FARMER:${farmer.name}:CROP:${token.crop || 'Wheat'}:BAY:${token.parkingLane || 'Lane TT-04'}`)}" 
                     alt="Scannable QR Pass" class="w-24 h-24 rounded-xl block bg-white" />
              </div>
              <div>
                <span class="px-2.5 py-0.5 rounded-full text-[10px] font-black bg-emerald-100 text-emerald-800 border border-emerald-300 uppercase tracking-wide">
                  📷 Smartphone Camera Scannable Pass
                </span>
                <div class="flex items-center gap-2 mt-1">
                  <h3 class="text-xl sm:text-2xl font-black text-slate-900 font-mono">Token ${token.id}</h3>
                  <span class="text-xs font-bold text-slate-500">• ${token.crop || 'Wheat'} (${token.qtyQuintal || 50} Qtl)</span>
                </div>
                <p class="text-xs text-slate-600 mt-0.5">
                  Assigned Bay: <strong class="text-emerald-700 font-mono">${token.parkingLane || 'Lane TT-04'}</strong> • Gate: <strong>Gate 2</strong>
                </p>
              </div>
            </div>

            <div class="flex items-center gap-2 w-full md:w-auto">
              <button onclick="FarmerPortal.setView('qr-checkin')" class="btn-large flex-1 md:flex-none px-5 py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-md">
                📱 Fullscreen QR Pass
              </button>
              <button onclick="CenterDesk.openPrintSlipModal('${token.id}')" class="btn-large flex-1 md:flex-none px-4 py-3 bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs">
                🖨️ Mandi Slip
              </button>
            </div>
          </div>
        ` : ''}

        <!-- Quick Action Grid Cards (Including Live Heatmap) -->
        <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
          
          <!-- 1. Book a Slot -->
          <div onclick="FarmerPortal.setView('book-step1')" class="bg-white p-5 sm:p-6 rounded-3xl border-2 border-slate-200 hover:border-emerald-500 shadow-sm transition cursor-pointer flex flex-col items-center text-center space-y-3 group">
            <div class="w-14 h-14 sm:w-16 sm:h-16 rounded-2xl bg-emerald-100 text-emerald-700 text-2xl sm:text-3xl flex items-center justify-center group-hover:scale-110 transition">
              📅
            </div>
            <div>
              <h3 class="text-sm sm:text-base font-black text-slate-900">${t('quickBookSlot')}</h3>
              <p class="text-[11px] text-slate-500 mt-0.5">Crop, Centre & Time</p>
            </div>
          </div>

          <!-- 2. My Bookings -->
          <div onclick="FarmerPortal.setView('bookings')" class="bg-white p-5 sm:p-6 rounded-3xl border-2 border-slate-200 hover:border-emerald-500 shadow-sm transition cursor-pointer flex flex-col items-center text-center space-y-3 group">
            <div class="w-14 h-14 sm:w-16 sm:h-16 rounded-2xl bg-blue-100 text-blue-700 text-2xl sm:text-3xl flex items-center justify-center group-hover:scale-110 transition">
              📋
            </div>
            <div>
              <h3 class="text-sm sm:text-base font-black text-slate-900">${t('quickMyBookings')}</h3>
              <p class="text-[11px] text-slate-500 mt-0.5">${farmer.bookings ? farmer.bookings.length : 4} Active / Past Slips</p>
            </div>
          </div>

          <!-- 3. Gate QR Pass (100% Scannable) -->
          <div onclick="FarmerPortal.setView('qr-checkin')" class="bg-gradient-to-br from-emerald-600 to-teal-700 text-white p-5 sm:p-6 rounded-3xl border-2 border-emerald-500 shadow-sm transition hover:scale-105 cursor-pointer flex flex-col items-center text-center space-y-3 group">
            <div class="w-14 h-14 sm:w-16 sm:h-16 rounded-2xl bg-white/20 text-white text-2xl sm:text-3xl flex items-center justify-center group-hover:scale-110 transition shadow-inner">
              📱
            </div>
            <div>
              <h3 class="text-sm sm:text-base font-black">Gate QR Pass</h3>
              <p class="text-[11px] text-emerald-100 mt-0.5 font-bold">Token ${token.id || 'A12'} • Scannable</p>
            </div>
          </div>

          <!-- 4. Live Queue -->
          <div onclick="FarmerPortal.setView('live-queue')" class="bg-white p-5 sm:p-6 rounded-3xl border-2 border-slate-200 hover:border-emerald-500 shadow-sm transition cursor-pointer flex flex-col items-center text-center space-y-3 group">
            <div class="w-14 h-14 sm:w-16 sm:h-16 rounded-2xl bg-amber-100 text-amber-700 text-2xl sm:text-3xl flex items-center justify-center group-hover:scale-110 transition">
              👥
            </div>
            <div>
              <h3 class="text-sm sm:text-base font-black text-slate-900">${t('quickLiveQueue')}</h3>
              <p class="text-[11px] text-slate-500 mt-0.5">Token ${token.id || 'A12'} • 4 Ahead</p>
            </div>
          </div>

          <!-- 5. Live Mandi Heatmap -->
          <div onclick="App.openGlobalHeatmap()" class="bg-gradient-to-br from-amber-50 to-orange-50 p-5 sm:p-6 rounded-3xl border-2 border-amber-300 hover:border-amber-500 shadow-sm transition cursor-pointer flex flex-col items-center text-center space-y-3 group">
            <div class="w-14 h-14 sm:w-16 sm:h-16 rounded-2xl bg-amber-200 text-amber-900 text-2xl sm:text-3xl flex items-center justify-center group-hover:scale-110 transition shadow-inner">
              🗺️
            </div>
            <div>
              <h3 class="text-sm sm:text-base font-black text-slate-900">${t('heatmapTitle')}</h3>
              <p class="text-[11px] text-amber-800 font-bold mt-0.5">Live Queues & Detours</p>
            </div>
          </div>

          <!-- 6. Procurement Status -->
          <div onclick="FarmerPortal.setView('procurement')" class="bg-white p-5 sm:p-6 rounded-3xl border-2 border-slate-200 hover:border-emerald-500 shadow-sm transition cursor-pointer flex flex-col items-center text-center space-y-3 group">
            <div class="w-14 h-14 sm:w-16 sm:h-16 rounded-2xl bg-purple-100 text-purple-700 text-2xl sm:text-3xl flex items-center justify-center group-hover:scale-110 transition">
              ⚖️
            </div>
            <div>
              <h3 class="text-sm sm:text-base font-black text-slate-900">${t('quickProcurement')}</h3>
              <p class="text-[11px] text-slate-500 mt-0.5">5-Stage Verification</p>
            </div>
          </div>

          <!-- 7. Payment Status -->
          <div onclick="FarmerPortal.setView('payment')" class="bg-white p-5 sm:p-6 rounded-3xl border-2 border-slate-200 hover:border-emerald-500 shadow-sm transition cursor-pointer flex flex-col items-center text-center space-y-3 group">
            <div class="w-14 h-14 sm:w-16 sm:h-16 rounded-2xl bg-emerald-100 text-emerald-700 text-2xl sm:text-3xl flex items-center justify-center group-hover:scale-110 transition">
              💳
            </div>
            <div>
              <h3 class="text-sm sm:text-base font-black text-slate-900">${t('quickPayment')}</h3>
              <p class="text-[11px] text-slate-500 mt-0.5 font-mono font-bold text-emerald-700">₹${(token.expectedTotal || 113750).toLocaleString('en-IN')}</p>
            </div>
          </div>

          <!-- 8. Notifications -->
          <div onclick="FarmerPortal.setView('notifications')" class="bg-white p-5 sm:p-6 rounded-3xl border-2 border-slate-200 hover:border-emerald-500 shadow-sm transition cursor-pointer flex flex-col items-center text-center space-y-3 group">
            <div class="w-14 h-14 sm:w-16 sm:h-16 rounded-2xl bg-rose-100 text-rose-700 text-2xl sm:text-3xl flex items-center justify-center group-hover:scale-110 transition relative">
              🔔
              <span class="absolute top-1 right-1 w-3.5 h-3.5 bg-rose-600 rounded-full border-2 border-white"></span>
            </div>
            <div>
              <h3 class="text-sm sm:text-base font-black text-slate-900">${t('quickNotifications')}</h3>
              <p class="text-[11px] text-slate-500 mt-0.5">SMS & App Alerts</p>
            </div>
          </div>

        </div>

        <!-- Voice Assistance Prompt Banner (Screen 3 Bottom) -->
        <div onclick="FarmerPortal.playVoiceAssistant()" class="p-4 bg-white border border-slate-200 rounded-2xl shadow-sm flex items-center justify-between cursor-pointer hover:bg-slate-50 transition">
          <div class="flex items-center gap-3">
            <div class="w-10 h-10 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center text-xl">
              🎙️
            </div>
            <span class="text-xs sm:text-sm font-bold text-slate-700">${t('needHelpVoice')}</span>
          </div>
          <span class="text-xs font-bold text-emerald-700">Tap to Speak / Listen ➔</span>
        </div>
      </div>
    `;
  }

  // =========================================================================
  // 2. SCREEN 4: CROP & QUANTITY DETAILS (Slot Booking Step 1)
  // =========================================================================
  renderBookStep1(t) {
    const crops = [
      { 
        id: 'Wheat', 
        name: 'Wheat (गेहूं)', 
        rate: 2275, 
        icon: '🌾',
        img: 'https://images.unsplash.com/photo-1574323347407-f5e1ad6d020b?auto=format&fit=crop&w=600&q=80'
      },
      { 
        id: 'Soybean', 
        name: 'Soybean (सोयाबीन)', 
        rate: 4850, 
        icon: '🌱',
        img: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSXDDf0TrBovztoUUbOtsBzYH4pqDOweV3Hej7kfGk5oA&s=10'
      },
      { 
        id: 'Rice', 
        name: 'Paddy / Rice (धान)', 
        rate: 2183, 
        icon: '🌾',
        img: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTi3RXyLjxfvxilbqxnNxbNRyTQiz2Sap6qvqldQLewzsZyImNlAxypINY&s=10'
      },
      { 
        id: 'Chana', 
        name: 'Chana / Gram (चना)', 
        rate: 5440, 
        icon: '🫘',
        img: 'https://images.unsplash.com/photo-1515543904379-3d757afe72e4?auto=format&fit=crop&w=600&q=80'
      },
      { 
        id: 'Mustard', 
        name: 'Mustard (सरसों)', 
        rate: 5650, 
        icon: '🌼',
        img: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRKIYgBOuEa1QI28_KZhwlBEXN7Jje1FMDkUsomH6jQBw&s=10'
      }
    ];

    const vehicles = [
      { id: 'Tractor Trolley (2-Wheel)', name: 'Tractor Trolley (2-Wheel)', cap: '30 - 50 Qtl', icon: '🚜' },
      { id: 'Tractor Trolley (4-Wheel Heavy)', name: 'Tractor Trolley (4-Wheel Heavy)', cap: '60 - 100 Qtl', icon: '🚜' },
      { id: 'Pickup / Bolero Truck', name: 'Pickup / Bolero Truck', cap: '20 - 35 Qtl', icon: '🛻' },
      { id: 'Medium Truck (6-Tyre)', name: 'Medium Truck (6-Tyre)', cap: '90 - 140 Qtl', icon: '🚚' },
      { id: 'Heavy Multi-Axle Hauler (10-14 Tyre)', name: 'Heavy Hauler (10-14 Tyre)', cap: '200 - 350 Qtl', icon: '🚛' },
      { id: 'Bullock Cart (Bail Gaadi)', name: 'Bullock Cart (Bail Gaadi)', cap: '10 - 18 Qtl', icon: '🐂' }
    ];

    return `
      <div class="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-sm space-y-6 max-w-2xl mx-auto">
        <div class="flex items-center justify-between border-b border-slate-100 pb-4">
          <button onclick="FarmerPortal.setView('dashboard')" class="btn-back-circle">
            <i data-lucide="arrow-left" class="w-4 h-4">←</i>
          </button>
          <span class="text-xs font-bold text-slate-400">Step 1 of 4 • Crop & Transport</span>
        </div>

        <div class="text-left space-y-1">
          <h3 class="text-2xl font-black text-slate-900">${t('cropDetailsTitle')}</h3>
          <p class="text-xs text-slate-500">Select the crop you want to bring and estimated load</p>
        </div>

        <!-- Crop Type Picker with Rich Photographic Backgrounds -->
        <div class="space-y-2">
          <div class="flex items-center justify-between">
            <label class="block text-xs font-bold text-slate-700">Crop Type</label>
            <span class="text-[11px] font-bold text-emerald-600">Verified Mandi MSP</span>
          </div>
          <div class="grid grid-cols-2 sm:grid-cols-3 gap-3">
            ${crops.map(c => {
              const isSelected = this.wizardCrop === c.id;
              return `
                <div onclick="FarmerPortal.selectWizardCrop('${c.id}')"
                     class="crop-card-bg ${isSelected ? 'selected' : ''}"
                     style="background-image: linear-gradient(to top, rgba(15, 23, 42, 0.94) 0%, rgba(15, 23, 42, 0.6) 55%, rgba(15, 23, 42, 0.3) 100%), url('${c.img}');">
                  
                  <!-- Selected Badge -->
                  <div class="absolute top-2 right-2">
                    ${isSelected ? `
                      <span class="px-2 py-0.5 rounded-full bg-emerald-500 text-white text-[10px] font-black shadow-md flex items-center gap-0.5">
                        <span>✓</span> Selected
                      </span>
                    ` : `
                      <span class="w-5 h-5 rounded-full bg-black/40 backdrop-blur-sm border border-white/20 text-white/70 flex items-center justify-center text-[10px]">
                        +
                      </span>
                    `}
                  </div>

                  <!-- Content Area -->
                  <div class="p-3 relative z-10 space-y-1 text-left">
                    <div class="flex items-center gap-1.5">
                      <span class="text-xl filter drop-shadow">${c.icon}</span>
                      <span class="text-xs sm:text-sm font-black text-white drop-shadow-md leading-tight">${c.name}</span>
                    </div>
                    <div class="flex items-center justify-between pt-1 border-t border-white/25 text-[11px]">
                      <span class="text-emerald-300 font-bold drop-shadow">Govt MSP</span>
                      <span class="font-black text-white bg-emerald-600/90 px-2 py-0.5 rounded-md text-[10px] shadow-sm">₹${c.rate}/Qtl</span>
                    </div>
                  </div>
                </div>
              `;
            }).join('')}
          </div>
        </div>

        <!-- Expected Quantity with Live Total Calculation -->
        <div class="space-y-2 pt-2">
          <label class="block text-xs font-bold text-slate-700">${t('cropExpectedQtyLabel')}</label>
          <div class="flex items-center gap-3">
            <button type="button" onclick="FarmerPortal.adjustWizardQty(-10)" class="w-12 h-12 rounded-2xl bg-slate-100 hover:bg-slate-200 text-slate-800 text-xl font-black transition flex items-center justify-center">
              -
            </button>
            <input type="number" id="wizard-qty-input" value="${this.wizardQty}" min="5" max="500" oninput="FarmerPortal.wizardQty = Number(this.value); FarmerPortal.updateCalculation(this.value)" class="w-36 h-12 text-center text-xl font-black border-2 border-slate-200 rounded-2xl focus:border-emerald-600 focus:outline-none text-slate-900">
            <button type="button" onclick="FarmerPortal.adjustWizardQty(10)" class="w-12 h-12 rounded-2xl bg-slate-100 hover:bg-slate-200 text-slate-800 text-xl font-black transition flex items-center justify-center">
              +
            </button>

            <div class="flex items-center gap-1.5 ml-1">
              <button type="button" onclick="FarmerPortal.wizardQty = 30; document.getElementById('wizard-qty-input').value = 30; FarmerPortal.updateCalculation(30)" class="px-2.5 py-2 bg-slate-100 hover:bg-slate-200 rounded-xl text-xs font-bold text-slate-700">30 Q</button>
              <button type="button" onclick="FarmerPortal.wizardQty = 50; document.getElementById('wizard-qty-input').value = 50; FarmerPortal.updateCalculation(50)" class="px-2.5 py-2 bg-slate-100 hover:bg-slate-200 rounded-xl text-xs font-bold text-slate-700">50 Q</button>
              <button type="button" onclick="FarmerPortal.wizardQty = 100; document.getElementById('wizard-qty-input').value = 100; FarmerPortal.updateCalculation(100)" class="px-2.5 py-2 bg-slate-100 hover:bg-slate-200 rounded-xl text-xs font-bold text-slate-700">100 Q</button>
            </div>
          </div>

          <div id="wizard-calc-display" class="bg-emerald-50 border border-emerald-200 p-3.5 rounded-2xl mt-2">
            <div class="flex items-center justify-between text-slate-600 text-xs">
              <span>Govt MSP Rate: <strong>₹${(this.cropRates[this.wizardCrop] || 2275).toLocaleString('en-IN')}/Qtl</strong></span>
              <span>${this.wizardQty} Quintals (${(this.wizardQty / 10).toFixed(1)} Tonnes)</span>
            </div>
            <div class="mt-1 text-2xl font-black text-emerald-700 font-mono">
              ₹${(this.wizardQty * (this.cropRates[this.wizardCrop] || 2275)).toLocaleString('en-IN')}
            </div>
          </div>
        </div>

        <!-- Harvest / Procurement Date -->
        <div class="space-y-1 pt-1">
          <label class="block text-xs font-bold text-slate-700">${t('procurementDateLabel')}</label>
          <input type="text" id="wizard-date-input" value="15 Oct 2025" onchange="FarmerPortal.wizardDate = this.value" class="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-bold text-slate-900 focus:outline-none focus:border-emerald-600">
        </div>

        <!-- Real Farm Vehicles (Clean Light Card Style) -->
        <div class="space-y-2 pt-1">
          <div class="flex items-center justify-between">
            <label class="block text-xs font-bold text-slate-700">Which farm vehicle will carry this crop?</label>
            <span class="text-[11px] font-bold text-slate-500">Mandi Lane Allocation</span>
          </div>
          <div class="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
            ${vehicles.map(v => {
              const isSelected = this.wizardVehicle === v.id;
              return `
                <div onclick="FarmerPortal.selectWizardVehicle('${v.id}', '${v.icon}')"
                     class="p-3.5 rounded-2xl border-2 cursor-pointer transition flex items-center justify-between gap-3 ${isSelected ? 'border-emerald-600 bg-emerald-50 text-emerald-950 shadow-sm' : 'border-slate-200 bg-white hover:border-slate-300 hover:bg-slate-50 text-slate-800'}">
                  <div class="flex items-center gap-3 min-w-0">
                    <div class="w-12 h-12 rounded-2xl ${isSelected ? 'bg-emerald-600 text-white shadow-sm' : 'bg-slate-100 text-slate-700'} flex items-center justify-center text-2xl flex-shrink-0 transition">
                      ${v.icon}
                    </div>
                    <div class="min-w-0 text-left">
                      <div class="text-xs sm:text-sm font-black truncate leading-tight">${v.name}</div>
                      <div class="flex items-center gap-2 mt-1">
                        <span class="inline-flex items-center gap-1 px-2 py-0.5 rounded-md ${isSelected ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-100 text-slate-600'} text-[10px] font-bold">
                          ⚖️ ${v.cap}
                        </span>
                      </div>
                    </div>
                  </div>

                  <div class="flex-shrink-0">
                    ${isSelected ? `
                      <span class="px-2.5 py-1 rounded-full bg-emerald-600 text-white text-[10px] font-black shadow-sm flex items-center gap-0.5">
                        <span>✓</span> Selected
                      </span>
                    ` : `
                      <span class="w-6 h-6 rounded-full border-2 border-slate-300 flex items-center justify-center text-xs font-bold text-slate-400">
                        +
                      </span>
                    `}
                  </div>
                </div>
              `;
            }).join('')}
          </div>
        </div>

        <button onclick="FarmerPortal.setView('book-step2')" class="btn-large w-full bg-emerald-600 hover:bg-emerald-700 text-white shadow-md text-base mt-4">
          ${t('btnContinue')} ➔
        </button>
      </div>
    `;
  }

  // =========================================================================
  // 3. SCREEN 5: ELIGIBLE CENTRE RECOMMENDATION (Slot Booking Step 2)
  // =========================================================================
  renderBookStep2(t) {
    const storeState = window.KisanStore ? window.KisanStore.getState() : {};
    const currentSelectedState = storeState.selectedState || 'Maharashtra';
    const allStates = window.KisanStore ? window.KisanStore.getIndianStates() : [];
    const currentSelectedDistrict = this.wizardDistrict || storeState.selectedDistrict || 'All Districts';
    const districtsList = window.KisanStore ? window.KisanStore.getDistrictsForState(currentSelectedState) : [];
    const storeMandis = window.KisanStore ? window.KisanStore.getAllIndiaMandis(currentSelectedState, 'All', 'All', currentSelectedDistrict) : [];

    // Map mandis into centre objects
    const centres = storeMandis.map(m => ({
      id: m.id,
      name: `${m.name}`,
      shortName: m.name,
      state: m.state,
      district: m.district,
      dist: m.distanceKm ? `${m.distanceKm}` : '3.8 km',
      cap: m.storageCapacityMT ? `${(m.storageCapacityMT / 10).toFixed(0)} q` : '2,200 q',
      queue: m.liveQueue || 8,
      slots: Math.max(4, 30 - (m.liveQueue || 8)),
      status: m.status || 'Normal',
      avgWait: m.avgWait || 15,
      crops: m.primaryCrops || m.crops || ['Wheat', 'Soybean', 'Chana']
    }));

    const listToRender = centres.length > 0 ? centres : this.centresList;

    return `
      <div class="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-sm space-y-6 max-w-2xl mx-auto">
        <div class="flex items-center justify-between border-b border-slate-100 pb-4">
          <button onclick="FarmerPortal.setView('book-step1')" class="btn-back-circle">
            <i data-lucide="arrow-left" class="w-4 h-4">←</i>
          </button>
          <span class="text-xs font-bold text-slate-400">Step 2 of 4 • Select Centre</span>
        </div>

        <div class="text-left space-y-1">
          <h3 class="text-2xl font-black text-slate-900">${t('eligibleCentresTitle')}</h3>
          <p class="text-xs text-slate-500">Centres accepting <strong>${this.wizardCrop}</strong> in <strong>${currentSelectedState}</strong></p>
        </div>

        <!-- Pan-India State Selector & Live Heatmap Launcher (Step 2) -->
        <div class="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-2.5 bg-emerald-50 p-3 rounded-2xl border border-emerald-200">
          <div class="flex items-center gap-2">
            <span class="text-xs font-bold text-emerald-900 whitespace-nowrap">🇮🇳 ${t('statePrompt')}:</span>
            <select onchange="App.setSelectedState(this.value); FarmerPortal.wizardDistrict = 'All Districts'; FarmerPortal.render();" class="bg-white text-slate-800 text-xs font-bold py-1.5 px-2.5 rounded-xl border border-emerald-300 focus:outline-none">
              <option value="All India" ${currentSelectedState === 'All India' ? 'selected' : ''}>All India (National APMC)</option>
              ${allStates.map(s => `
                <option value="${s.name}" ${currentSelectedState === s.name ? 'selected' : ''}>${s.name} (${s.nativeName || s.name})</option>
              `).join('')}
            </select>
          </div>

          <button onclick="App.openGlobalHeatmap('All', '${currentSelectedState}')" class="px-3 py-1.5 bg-amber-400 hover:bg-amber-300 text-amber-950 font-black rounded-xl text-xs shadow-sm transition flex items-center justify-center gap-1.5 whitespace-nowrap">
            <span>🗺️</span>
            <span>${t('heatmapTitle')}</span>
          </button>
        </div>

        <!-- Dynamic District Selector & Filter Bar for the Selected State -->
        <div class="bg-slate-50 p-3.5 rounded-2xl border border-slate-200 space-y-2.5">
          <div class="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2">
            <div class="flex items-center gap-1.5">
              <span class="text-xs font-bold text-slate-800">📍 Districts in ${currentSelectedState}:</span>
              <span class="px-2 py-0.5 rounded-full text-[10px] font-extrabold bg-emerald-100 text-emerald-800 border border-emerald-300">
                ${districtsList.length} Districts Available
              </span>
            </div>
            <select onchange="FarmerPortal.setFilterDistrict(this.value)" class="bg-white text-slate-800 text-xs font-bold py-1.5 px-3 rounded-xl border border-slate-300 focus:outline-none w-full sm:w-auto shadow-xs">
              <option value="All Districts" ${currentSelectedDistrict === 'All Districts' || currentSelectedDistrict === 'All' ? 'selected' : ''}>
                🌟 All Districts of ${currentSelectedState} (${districtsList.length} Districts)
              </option>
              ${districtsList.map(d => `
                <option value="${d}" ${currentSelectedDistrict === d ? 'selected' : ''}>${d}</option>
              `).join('')}
            </select>
          </div>

          <!-- Quick District Filter Pills (Horizontal Scroll) -->
          <div class="flex items-center gap-1.5 overflow-x-auto pb-1 pt-0.5">
            <button onclick="FarmerPortal.setFilterDistrict('All Districts')" class="px-3 py-1 rounded-xl text-xs font-bold transition whitespace-nowrap ${currentSelectedDistrict === 'All Districts' || currentSelectedDistrict === 'All' ? 'bg-emerald-700 text-white shadow-xs' : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-100'}">
              All (${centres.length} Centers)
            </button>
            ${districtsList.slice(0, 12).map(d => {
              const dClean = d.replace(/\s*\(.*?\)\s*/g, '');
              const isSel = currentSelectedDistrict === d;
              return `
                <button onclick="FarmerPortal.setFilterDistrict('${d}')" class="px-2.5 py-1 rounded-xl text-xs font-bold transition whitespace-nowrap ${isSel ? 'bg-emerald-600 text-white shadow-xs' : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-100'}">
                  ${dClean}
                </button>
              `;
            }).join('')}
          </div>
        </div>

        <!-- Centre Count Strip -->
        <div class="flex items-center justify-between text-xs text-slate-500 px-1 pt-1">
          <span>Showing <strong>${centres.length}</strong> Procurement Center${centres.length === 1 ? '' : 's'} in <strong>${currentSelectedDistrict === 'All Districts' || currentSelectedDistrict === 'All' ? currentSelectedState : currentSelectedDistrict + ', ' + currentSelectedState}</strong></span>
          <span class="text-emerald-700 font-bold">✓ Live MSP & Slot Verified</span>
        </div>

        <!-- Centre Recommendation Cards (Screen 5) -->
        <div class="space-y-4">
          ${listToRender.map(c => {
            const isSelected = this.wizardCentre.id === c.id;
            const statusClass = c.status === 'High' ? 'bg-rose-100 text-rose-800 border-rose-200' : c.status === 'Moderate' ? 'bg-amber-100 text-amber-800 border-amber-200' : 'bg-emerald-100 text-emerald-800 border-emerald-200';
            const statusLabel = c.status === 'High' ? t('statusFull') : c.status === 'Moderate' ? t('statusBusy') : t('statusNormal');
            return `
              <div class="p-5 rounded-2xl border-2 transition ${isSelected ? 'border-emerald-600 bg-emerald-50/50 shadow-md ring-2 ring-emerald-500/20' : 'border-slate-200 bg-white hover:border-slate-300'} space-y-3">
                <div class="flex items-start justify-between gap-2">
                  <div>
                    <h4 class="font-black text-slate-900 text-base leading-snug">${c.name}</h4>
                    <div class="flex items-center gap-2 mt-1.5 text-xs text-slate-500 flex-wrap">
                      <span class="px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-900 font-extrabold border border-emerald-300">
                        📍 ${c.district} District, ${c.state}
                      </span>
                      <span class="px-2 py-0.5 rounded-full bg-slate-100 font-bold text-slate-700">🛣️ ${c.dist}</span>
                      <span>Accepts: <strong>${c.crops.join(', ')}</strong></span>
                    </div>
                  </div>
                  <span class="px-2.5 py-1 rounded-full text-[10px] font-extrabold border ${statusClass} whitespace-nowrap shadow-xs">
                    ${statusLabel} • ${c.avgWait}m wait
                  </span>
                </div>

                <div class="grid grid-cols-3 gap-2 text-center text-xs py-2 bg-slate-50 rounded-xl">
                  <div>
                    <span class="text-[10px] text-slate-400 block">${t('availableCapacityLabel')}</span>
                    <strong class="text-slate-800">${c.cap}</strong>
                  </div>
                  <div>
                    <span class="text-[10px] text-slate-400 block">${t('queueLengthLabel')}</span>
                    <strong class="text-amber-700">${c.queue} vehicles</strong>
                  </div>
                  <div>
                    <span class="text-[10px] text-slate-400 block">${t('availableSlotsLabel')}</span>
                    <strong class="text-emerald-700">${c.slots} slots</strong>
                  </div>
                </div>

                <div class="flex items-center gap-2 pt-1">
                  <button onclick="alert('Google Maps navigation to ${c.name} opened.')" class="flex-1 py-2 px-3 bg-white border border-slate-200 hover:bg-slate-50 text-slate-700 text-xs font-bold rounded-xl transition">
                    ${t('btnViewOnMap')}
                  </button>
                  <button onclick="FarmerPortal.selectCentreAndProceed(${JSON.stringify(c).replace(/"/g, '&quot;')})" class="flex-1 py-2 px-3 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl shadow-sm transition">
                    ${t('btnSelectCentre')} ➔
                  </button>
                </div>
              </div>
            `;
          }).join('')}
        </div>
      </div>
    `;
  }

  // =========================================================================
  // 4. SCREEN 6: LIVE QUEUE & AI SLOT ALLOCATION (Slot Booking Step 3)
  // =========================================================================
  renderBookStep3(t) {
    const aiRec = (window.KisanStore && typeof window.KisanStore.getAiRecommendedSlot === 'function') ?
      window.KisanStore.getAiRecommendedSlot(this.wizardCrop, this.wizardQty, this.wizardVehicle) : {
        slot: '10:00 - 11:00 AM',
        date: '15 Oct Today',
        estWaitMins: 8,
        savingsMins: 27,
        confidenceScore: 98,
        recommendedBay: 'Lane TT-01 (Express Tractor Ramp)',
        reason: `AI scheduled for ${this.wizardVehicle} (${this.wizardQty} Qtl ${this.wizardCrop}): Express ramp has 0 backlog and guaranteed prompt weighbridge intake.`
      };

    const timeSlots = [
      {
        id: '09:00 - 10:00 AM',
        waitMins: 35,
        booked: 28,
        max: 30,
        isAiRec: aiRec.slot === '09:00 - 10:00 AM',
        badge: '🔴 Peak Rush (~35m wait)',
        badgeClass: 'bg-rose-50 text-rose-700 border-rose-200',
        note: 'Heavy commercial truck wave'
      },
      {
        id: '10:00 - 11:00 AM',
        waitMins: aiRec.estWaitMins || 8,
        booked: 6,
        max: 30,
        isAiRec: aiRec.slot === '10:00 - 11:00 AM',
        badge: '🤖 AI OPTIMAL (Fast Pass)',
        badgeClass: 'bg-emerald-100 text-emerald-800 border-emerald-300 font-extrabold',
        note: `Lowest gate wait (~${aiRec.estWaitMins || 8}m) • Ramp pre-cleared`
      },
      {
        id: '11:00 - 12:00 PM',
        waitMins: 22,
        booked: 19,
        max: 30,
        isAiRec: aiRec.slot === '11:00 - 12:00 PM',
        badge: '🟡 Moderate Flow (~22m wait)',
        badgeClass: 'bg-amber-50 text-amber-800 border-amber-200',
        note: 'Normal tractor queue'
      },
      {
        id: '12:00 - 01:00 PM',
        waitMins: 40,
        booked: 29,
        max: 30,
        isAiRec: aiRec.slot === '12:00 - 01:00 PM',
        badge: '🔴 Hauler Congestion (~40m wait)',
        badgeClass: 'bg-rose-50 text-rose-700 border-rose-200',
        note: 'Multi-axle bulk arrivals'
      },
      {
        id: '02:00 - 03:00 PM',
        waitMins: 11,
        booked: 9,
        max: 30,
        isAiRec: aiRec.slot === '02:00 - 03:00 PM',
        badge: '🟢 Clear Window (~11m wait)',
        badgeClass: 'bg-emerald-50 text-emerald-800 border-emerald-200',
        note: 'Post-lunch silo clearance'
      },
      {
        id: '03:00 - 04:00 PM',
        waitMins: 15,
        booked: 14,
        max: 30,
        isAiRec: aiRec.slot === '03:00 - 04:00 PM',
        badge: '🟢 Steady Flow (~15m wait)',
        badgeClass: 'bg-emerald-50 text-emerald-800 border-emerald-200',
        note: 'Normal evening intake'
      }
    ];

    return `
      <div class="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-sm space-y-6 max-w-2xl mx-auto">
        <div class="flex items-center justify-between border-b border-slate-100 pb-4">
          <button onclick="FarmerPortal.setView('book-step2')" class="btn-back-circle">
            <i data-lucide="arrow-left" class="w-4 h-4">←</i>
          </button>
          <span class="text-xs font-bold text-slate-400">Step 3 of 4 • AI Slot Allocation</span>
        </div>

        <div class="text-left space-y-1">
          <div class="flex items-center gap-2">
            <h3 class="text-xl font-black text-slate-900">${t('liveQueueSlotTitle')}</h3>
            <span class="px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[10px] font-black border border-emerald-200 flex items-center gap-1">
              <span class="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
              AI Active
            </span>
          </div>
          <p class="text-xs text-slate-500">${this.wizardCentre.name}</p>
        </div>

        <!-- 🤖 AI Recommended Slot Allocation Hero Banner -->
        <div class="bg-gradient-to-br from-emerald-900 via-teal-900 to-slate-900 rounded-3xl p-5 text-white shadow-md relative overflow-hidden text-left border border-emerald-700/40">
          <div class="absolute -right-8 -top-8 w-32 h-32 bg-emerald-500/10 rounded-full blur-2xl"></div>
          
          <div class="flex items-start justify-between gap-3 relative z-10">
            <div class="flex items-center gap-2.5">
              <div class="w-10 h-10 rounded-2xl bg-emerald-500/20 text-emerald-300 border border-emerald-400/30 flex items-center justify-center text-xl shadow-inner flex-shrink-0">
                🤖
              </div>
              <div>
                <span class="text-[10px] uppercase font-black tracking-wider text-emerald-300 block">KisanSetu AI Slot Allocation Engine</span>
                <h4 class="text-base sm:text-lg font-black text-white leading-tight">Recommended Slot: ${aiRec.slot}</h4>
              </div>
            </div>
            <span class="px-2.5 py-1 rounded-full bg-emerald-500/30 text-emerald-200 border border-emerald-400/40 text-[10px] font-extrabold whitespace-nowrap">
              ⚡ Save ~${aiRec.savingsMins}m in queue
            </span>
          </div>

          <p class="text-xs text-emerald-100/90 mt-3 leading-relaxed relative z-10">
            ${aiRec.reason}
          </p>

          <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mt-4 pt-3 border-t border-white/15 relative z-10">
            <div class="flex items-center gap-2 text-xs text-emerald-200 font-bold">
              <span>🏷️ Pre-Allocated Ramp:</span>
              <span class="text-white font-black underline">${aiRec.recommendedBay}</span>
            </div>
            <button onclick="FarmerPortal.applyAiSlot('${aiRec.date}', '${aiRec.slot}')" class="px-4 py-2 bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-xs font-black rounded-xl shadow-lg transition flex items-center justify-center gap-1.5 whitespace-nowrap">
              <span>✨</span>
              <span>1-Click Apply AI Slot</span>
            </button>
          </div>
        </div>

        <!-- 3 KPI Metric Badges -->
        <div class="grid grid-cols-3 gap-3 text-center">
          <div class="p-3 bg-slate-50 rounded-2xl border border-slate-200">
            <span class="text-[10px] text-slate-500 font-bold block">${t('queueLengthLabel')}</span>
            <div class="text-xl font-black text-slate-900 mt-0.5">${this.wizardCentre.queue} vehicles</div>
          </div>

          <div class="p-3 bg-emerald-50 rounded-2xl border border-emerald-200">
            <span class="text-[10px] text-emerald-800 font-bold block">${t('availableSlotsLabel')}</span>
            <div class="text-xl font-black text-emerald-700 mt-0.5">${this.wizardCentre.slots} slots</div>
          </div>

          <div class="p-3 bg-teal-50 rounded-2xl border border-teal-200">
            <span class="text-[10px] text-teal-800 font-bold block">AI Est. Wait</span>
            <div class="text-xl font-black text-teal-700 mt-0.5 font-mono">~${this.wizardTimeSlot === aiRec.slot ? aiRec.estWaitMins : 20}m</div>
          </div>
        </div>

        <!-- Date Selector Pills -->
        <div class="space-y-2 pt-1">
          <label class="block text-xs font-bold text-slate-700">Select Date</label>
          <div class="grid grid-cols-3 gap-2">
            ${['15 Oct Today', '16 Oct Thu', '17 Oct Fri'].map(d => `
              <div onclick="FarmerPortal.wizardDateSlot = '${d}'; FarmerPortal.render()" class="p-2.5 rounded-xl border-2 text-center cursor-pointer text-xs font-bold transition ${this.wizardDateSlot === d ? 'border-emerald-600 bg-emerald-50 text-emerald-900 shadow-sm' : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-50'}">
                ${d}
                ${d.includes('Today') ? '<span class="block text-[9px] text-emerald-600 font-extrabold mt-0.5">⭐ AI Optimal</span>' : ''}
              </div>
            `).join('')}
          </div>
        </div>

        <!-- Time Slots Grid with Real-time AI Congestion Telemetrics -->
        <div class="space-y-2 pt-1">
          <div class="flex items-center justify-between">
            <label class="block text-xs font-bold text-slate-700">Arrival Time Slots</label>
            <span class="text-[10px] text-slate-500 font-bold">Auto-balanced by AI</span>
          </div>
          <div class="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
            ${timeSlots.map(slot => {
              const isSelected = this.wizardTimeSlot === slot.id;
              return `
                <div onclick="FarmerPortal.wizardTimeSlot = '${slot.id}'; FarmerPortal.render()" 
                     class="p-3.5 rounded-2xl border-2 text-left cursor-pointer transition relative ${isSelected ? 'border-emerald-600 bg-emerald-50 shadow-md ring-2 ring-emerald-500/30' : slot.isAiRec ? 'border-emerald-400 bg-emerald-50/40 hover:border-emerald-500' : 'border-slate-200 bg-white hover:border-slate-300 hover:bg-slate-50'}">
                  
                  <div class="flex items-start justify-between gap-2">
                    <div class="font-black text-xs sm:text-sm text-slate-900 flex items-center gap-1.5">
                      ${slot.id}
                      ${slot.isAiRec ? '<span class="text-xs">⚡</span>' : ''}
                    </div>
                    <span class="px-2 py-0.5 rounded-full text-[9px] font-black border ${slot.badgeClass} whitespace-nowrap">
                      ${slot.badge}
                    </span>
                  </div>

                  <div class="text-[11px] text-slate-500 mt-1 font-medium flex items-center justify-between">
                    <span>${slot.note}</span>
                    <span class="font-mono font-bold text-slate-700">${slot.booked}/${slot.max} Q</span>
                  </div>

                  <!-- Mini Capacity Bar -->
                  <div class="w-full bg-slate-100 rounded-full h-1.5 mt-2 overflow-hidden">
                    <div class="h-full rounded-full ${slot.booked > 25 ? 'bg-rose-500' : slot.booked > 15 ? 'bg-amber-500' : 'bg-emerald-500'}" style="width: ${(slot.booked / slot.max) * 100}%"></div>
                  </div>
                </div>
              `;
            }).join('')}
          </div>
        </div>

        <button onclick="FarmerPortal.setView('book-step4')" class="btn-large w-full bg-emerald-600 hover:bg-emerald-700 text-white shadow-md text-base mt-2">
          ${t('btnBookSlot')} (${this.wizardTimeSlot}) ➔
        </button>
      </div>
    `;
  }

  // =========================================================================
  // 5. SCREEN 7: CONFIRM BOOKING (Slot Booking Step 4)
  // =========================================================================
  renderBookStep4(t) {
    const rate = this.cropRates[this.wizardCrop] || 2275;
    const total = this.wizardQty * rate;

    return `
      <div class="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-sm space-y-6 max-w-2xl mx-auto">
        <div class="flex items-center justify-between border-b border-slate-100 pb-4">
          <button onclick="FarmerPortal.setView('book-step3')" class="btn-back-circle">
            <i data-lucide="arrow-left" class="w-4 h-4">←</i>
          </button>
          <span class="text-xs font-bold text-slate-400">Step 4 of 4 • Confirmation</span>
        </div>

        <div class="text-left space-y-1">
          <h3 class="text-2xl font-black text-slate-900">${t('confirmBookingTitle')}</h3>
          <p class="text-xs text-slate-500">Review your mandi booking before token generation</p>
        </div>

        <!-- Summary Receipt Card (Screen 7) -->
        <div class="p-5 bg-slate-50 rounded-2xl border border-slate-200 space-y-3.5 text-xs">
          <div class="flex justify-between border-b border-slate-200 pb-2">
            <span class="text-slate-500">Procurement Centre</span>
            <strong class="text-slate-900 text-right">${this.wizardCentre.name}</strong>
          </div>

          <div class="flex justify-between border-b border-slate-200 pb-2">
            <span class="text-slate-500">Crop & Quantity</span>
            <strong class="text-slate-900">${this.wizardCrop} • ${this.wizardQty} Quintals</strong>
          </div>

          <div class="flex justify-between border-b border-slate-200 pb-2">
            <span class="text-slate-500">Estimated Total Value (Govt MSP)</span>
            <strong class="text-emerald-700 font-mono text-sm">₹${total.toLocaleString('en-IN')}</strong>
          </div>

          <div class="flex justify-between border-b border-slate-200 pb-2">
            <span class="text-slate-500">Date</span>
            <strong class="text-slate-900">${this.wizardDateSlot} (${this.wizardDate})</strong>
          </div>

          <div class="flex justify-between border-b border-slate-200 pb-2">
            <span class="text-slate-500">Time Slot</span>
            <strong class="text-slate-900">${this.wizardTimeSlot}</strong>
          </div>

          <div class="flex justify-between border-b border-slate-200 pb-2">
            <span class="text-slate-500">Vehicle Type</span>
            <strong class="text-slate-900">${this.wizardVehicleIcon} ${this.wizardVehicle}</strong>
          </div>

          <div class="flex justify-between items-center">
            <span class="text-slate-500">Vehicle Number Plate</span>
            <input type="text" id="wizard-veh-no" value="${this.wizardVehicleNo}" class="p-1.5 bg-white border border-slate-300 rounded-lg text-xs font-mono font-bold text-slate-900 w-36 text-right">
          </div>
        </div>

        <!-- Actions (Screen 7) -->
        <div class="space-y-2 pt-2">
          <button onclick="FarmerPortal.handleWizardConfirmBooking()" class="btn-large w-full bg-emerald-600 hover:bg-emerald-700 text-white shadow-md text-base">
            ✅ ${t('btnConfirmBookingAction')}
          </button>
          
          <button onclick="FarmerPortal.setView('book-step3')" class="btn-large w-full bg-white hover:bg-slate-50 text-slate-700 border border-slate-200 text-xs">
            🔄 ${t('btnReschedule')}
          </button>

          <button onclick="FarmerPortal.setView('dashboard')" class="btn-large w-full bg-transparent hover:bg-rose-50 text-rose-600 text-xs font-bold">
            ❌ ${t('btnCancel')}
          </button>
        </div>
      </div>
    `;
  }

  // =========================================================================
  // 6. SCREEN 8: DIGITAL TOKEN / QR CONFIRMATION
  // =========================================================================
  renderTokenQR(t, token) {
    const qrSvg = generateQRCodeSVG(token.qrData || `${token.bookingId || 'AFG20251015001'}-${token.id || 'A12'}`, 180);

    return `
      <div class="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-sm space-y-6 max-w-2xl mx-auto text-center">
        <!-- Top Green Confirmed Banner (Screen 8) -->
        <div class="p-3.5 bg-emerald-50 rounded-2xl border border-emerald-200 flex items-center justify-center gap-2 text-emerald-800 font-extrabold text-sm">
          <span class="w-6 h-6 rounded-full bg-emerald-600 text-white flex items-center justify-center text-xs">✓</span>
          <span>${t('bookingConfirmedTitle')} ${t('bookingConfirmedSubtitle')}</span>
        </div>

        <div class="space-y-1">
          <p class="text-xs text-slate-400 font-bold uppercase">${t('bookingIdLabel')}: <span class="font-mono text-slate-800">${token.bookingId || 'AFG20251015001'}</span></p>
          <p class="text-xs text-slate-500 font-bold uppercase mt-2">${t('tokenNumberLabel')}</p>
          <div class="text-5xl sm:text-6xl font-black text-emerald-600 font-mono tracking-tight">
            ${token.id || 'A12'}
          </div>
        </div>

        <!-- Scannable 2D QR Code (Screen 8) -->
        <div class="py-2">
          ${qrSvg}
          <p class="text-[11px] text-slate-400 mt-2 font-mono">Scan at Mandi Gate 2 • Auto Bay Assigned</p>
        </div>

        <!-- Center & Slot Summary -->
        <div class="p-4 bg-slate-50 rounded-2xl border border-slate-200 text-left text-xs space-y-2">
          <div class="flex justify-between">
            <span class="text-slate-500">Centre:</span>
            <strong class="text-slate-900">${token.mandi || 'Centre A, Shivaji Nagar, Indore'}</strong>
          </div>
          <div class="flex justify-between">
            <span class="text-slate-500">Crop & Quantity:</span>
            <strong class="text-slate-900">${token.crop || 'Wheat'} - ${token.qtyQuintal || 50} quintals</strong>
          </div>
          <div class="flex justify-between">
            <span class="text-slate-500">Date & Time:</span>
            <strong class="text-slate-900">${token.date || '15 Oct 2025'}, ${token.timeSlot || '10:00 - 11:00 AM'}</strong>
          </div>
          <div class="flex justify-between">
            <span class="text-slate-500">Assigned Parking Bay:</span>
            <strong class="text-emerald-700">${token.parkingLane || 'Lane TT-04'}</strong>
          </div>
        </div>

        <!-- Action Buttons (Screen 8) -->
        <div class="space-y-2 pt-2">
          <button onclick="FarmerPortal.setView('bookings')" class="btn-large w-full bg-emerald-600 hover:bg-emerald-700 text-white shadow-md text-base">
            📋 ${t('btnViewMyBooking')}
          </button>

          <button onclick="FarmerPortal.setView('qr-checkin')" class="btn-large w-full bg-blue-600 hover:bg-blue-700 text-white text-sm shadow-sm">
            🚪 ${t('btnGateCheckinView')}
          </button>

          <button onclick="CenterDesk.openPrintSlipModal('${token.id}')" class="btn-large w-full bg-slate-900 hover:bg-slate-800 text-white text-sm">
            🖨️ View & Print Mandi Slip
          </button>
        </div>
      </div>
    `;
  }

  // =========================================================================
  // 7. SCREEN 16: QR CHECK-IN AT MANDI GATE
  // =========================================================================
  renderQRCheckin(t, token) {
    const qrSvg = generateQRCodeSVG(token.qrData || `${token.bookingId || 'AFG20251015001'}-${token.id || 'A12'}`, 220);
    const isChecked = token.status === 'Checked-In' || token.isCheckedIn;

    return `
      <div class="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-sm space-y-6 max-w-lg mx-auto text-center">
        <div class="flex items-center justify-between border-b border-slate-100 pb-4">
          <button onclick="FarmerPortal.setView('dashboard')" class="btn-back-circle">
            <i data-lucide="arrow-left" class="w-4 h-4">←</i>
          </button>
          <span class="text-xs font-bold text-slate-400">Gate Verification</span>
        </div>

        <div>
          <h3 class="text-2xl font-black text-slate-900">${t('qrCheckinTitle')}</h3>
          <p class="text-xs text-slate-500 mt-1">Show this QR code to the scanner at Mandi Intake Gate 2</p>
        </div>

        <!-- Large QR Display (Screen 16) -->
        <div class="p-4 bg-slate-50 rounded-3xl border border-slate-200">
          ${qrSvg}
          <div class="mt-3 space-y-1">
            <p class="text-xs text-slate-400 font-bold uppercase">${t('bookingIdLabel')}: <span class="font-mono text-slate-800">${token.bookingId || 'AFG20251015001'}</span></p>
            <p class="text-3xl font-black text-emerald-600 font-mono">${token.id || 'A12'}</p>
          </div>
        </div>

        <!-- Dynamic Status / Confirmation Banner (Screen 16) -->
        ${isChecked ? `
          <div class="p-4 bg-emerald-50 rounded-2xl border border-emerald-300 text-emerald-900 text-left flex items-start gap-3">
            <span class="text-2xl">✅</span>
            <div>
              <h4 class="text-xs sm:text-sm font-black text-emerald-900">Check-in Successful!</h4>
              <p class="text-xs text-emerald-700 mt-0.5">
                You can now proceed into the centre yard: <strong>${token.parkingLane || 'Lane TT-04'}</strong>.
              </p>
            </div>
          </div>
        ` : `
          <button onclick="FarmerPortal.handleGateCheckIn()" class="btn-large w-full bg-emerald-600 hover:bg-emerald-700 text-white shadow-lg shadow-emerald-600/20 text-base font-black">
            ${t('btnScanGateQR')}
          </button>
        `}

        <button onclick="FarmerPortal.setView('live-queue')" class="btn-large w-full bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold">
          View Live Queue Status ➔
        </button>
      </div>
    `;
  }

  // =========================================================================
  // 8. SCREEN 10: LIVE QUEUE - TRACKING
  // =========================================================================
  renderLiveQueue(t, farmer) {
    const queueData = farmer.queueTracking || {
      token: 'A12',
      farmersAhead: 4,
      estWaitMins: 20,
      centre: 'Centre A (Shivaji Nagar, Indore Mandi)',
      queueList: [
        { token: 'A12', label: 'A12 (You)', wait: '20 min', status: 'current', isUser: true },
        { token: 'A11', label: 'A11', wait: '10 min', status: 'waiting', isUser: false },
        { token: 'A10', label: 'A10', wait: '15 min', status: 'waiting', isUser: false },
        { token: 'A09', label: 'A09', wait: '20 min', status: 'waiting', isUser: false },
        { token: 'A08', label: 'A08', wait: '25 min', status: 'waiting', isUser: false }
      ]
    };

    return `
      <div class="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-sm space-y-6 max-w-2xl mx-auto">
        <div class="flex items-center justify-between border-b border-slate-100 pb-4">
          <button onclick="FarmerPortal.setView('dashboard')" class="btn-back-circle">
            <i data-lucide="arrow-left" class="w-4 h-4">←</i>
          </button>
          <span class="text-xs font-bold text-slate-400">Live Yard Queue</span>
        </div>

        <div>
          <h3 class="text-2xl font-black text-slate-900">Live Queue - ${queueData.centre}</h3>
          <p class="text-xs text-slate-500">Real-time gate inspection & weighbridge queue tracker</p>
        </div>

        <!-- Highlight Card (Screen 10) -->
        <div class="grid grid-cols-3 gap-3 p-5 bg-emerald-50 rounded-2xl border border-emerald-200 text-center">
          <div>
            <span class="text-[11px] text-slate-500 font-bold block">Your Token</span>
            <strong class="text-3xl font-black text-emerald-700 font-mono">${queueData.token}</strong>
          </div>

          <div>
            <span class="text-[11px] text-slate-500 font-bold block">${t('farmersAheadLabel')}</span>
            <strong class="text-3xl font-black text-slate-900 font-mono">${queueData.farmersAhead}</strong>
          </div>

          <div>
            <span class="text-[11px] text-slate-500 font-bold block">${t('estWaitLabel')}</span>
            <strong class="text-3xl font-black text-amber-700 font-mono">~${queueData.estWaitMins} m</strong>
          </div>
        </div>

        <!-- Queue Overview List (Screen 10) -->
        <div class="space-y-2 pt-2">
          <h4 class="text-xs font-bold text-slate-700 uppercase tracking-wide">Queue Overview</h4>
          
          <div class="divide-y divide-slate-100 border border-slate-200 rounded-2xl overflow-hidden">
            ${queueData.queueList.map(q => `
              <div class="p-3.5 flex items-center justify-between ${q.isUser ? 'bg-emerald-50/70 font-extrabold' : 'bg-white font-medium text-slate-700'}">
                <div class="flex items-center gap-3">
                  <span class="w-6 h-6 rounded-full flex items-center justify-center text-xs ${q.isUser ? 'bg-emerald-600 text-white' : 'bg-slate-100 text-slate-500'}">
                    ${q.isUser ? '✓' : '•'}
                  </span>
                  <span class="text-sm ${q.isUser ? 'text-emerald-900 font-black' : 'text-slate-900'}">${q.label}</span>
                </div>
                <span class="text-xs font-mono font-bold ${q.isUser ? 'text-emerald-800' : 'text-slate-500'}">${q.wait}</span>
              </div>
            `).join('')}
          </div>
        </div>

        <button onclick="FarmerPortal.render()" class="btn-large w-full bg-emerald-600 hover:bg-emerald-700 text-white shadow-md text-base">
          🔄 ${t('btnRefreshQueue')}
        </button>
      </div>
    `;
  }

  // =========================================================================
  // 9. SCREENS 11 & 12: PROCUREMENT PROCESS & STATUS (5-Stage Stepper)
  // =========================================================================
  renderProcurement(t, farmer, token) {
    const steps = farmer.procurementSteps || [
      { id: 1, name: 'Crop verification', status: 'completed', time: 'Completed (10:05 AM)', desc: 'Crop variety and vehicle verified.' },
      { id: 2, name: 'Weighing', status: 'in_progress', time: 'In Progress', desc: 'Electronic weighbridge weighing.' },
      { id: 3, name: 'Quality check', status: 'pending', time: 'Pending', desc: 'Moisture analysis.' },
      { id: 4, name: 'Acceptance', status: 'pending', time: 'Pending', desc: 'Superintendent sign-off.' },
      { id: 5, name: 'Procurement completed', status: 'pending', time: 'Pending', desc: 'Receipt issued.' }
    ];

    return `
      <div class="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-sm space-y-6 max-w-2xl mx-auto">
        <div class="flex items-center justify-between border-b border-slate-100 pb-4">
          <button onclick="FarmerPortal.setView('dashboard')" class="btn-back-circle">
            <i data-lucide="arrow-left" class="w-4 h-4">←</i>
          </button>
          <span class="text-xs font-bold text-slate-400">Step 2 of 5 Active</span>
        </div>

        <div>
          <h3 class="text-2xl font-black text-slate-900">${t('procurementProcessTitle')}</h3>
          <p class="text-xs text-slate-500 mt-1">
            Booking ID: <strong class="text-slate-800 font-mono">${token.bookingId || 'AFG20251015001'}</strong> • ${token.crop || 'Wheat'} (${token.qtyQuintal || 50} Qtl)
          </p>
        </div>

        <!-- 5-Step Process Timeline (Screen 11) -->
        <div class="space-y-4 pt-2">
          ${steps.map(s => {
            const isDone = s.status === 'completed';
            const isCurr = s.status === 'in_progress';

            return `
              <div class="flex items-start gap-4 p-3.5 rounded-2xl border ${isCurr ? 'border-emerald-500 bg-emerald-50/50 shadow-sm' : isDone ? 'border-emerald-200 bg-emerald-50/20' : 'border-slate-100 bg-slate-50 opacity-70'}">
                <div class="w-8 h-8 rounded-full flex items-center justify-center text-xs font-black flex-shrink-0 ${isDone ? 'bg-emerald-600 text-white' : isCurr ? 'bg-emerald-600 text-white animate-pulse' : 'bg-slate-200 text-slate-500'}">
                  ${isDone ? '✓' : s.id}
                </div>
                <div class="flex-1 text-left">
                  <div class="flex items-center justify-between">
                    <h4 class="text-sm font-extrabold ${isCurr ? 'text-emerald-900' : 'text-slate-900'}">${s.name}</h4>
                    <span class="text-[11px] font-bold ${isDone ? 'text-emerald-700' : isCurr ? 'text-amber-700' : 'text-slate-400'}">${s.time}</span>
                  </div>
                  <p class="text-xs text-slate-500 mt-0.5">${s.desc}</p>
                </div>
              </div>
            `;
          }).join('')}
        </div>

        <!-- Current Stage Card (Screen 11 Bottom) -->
        <div class="p-5 bg-slate-50 rounded-2xl border border-slate-200 text-center space-y-2">
          <span class="text-[11px] text-slate-400 font-bold uppercase">${t('currentStageLabel')}</span>
          <div class="flex items-center justify-center gap-2 text-2xl font-black text-slate-900">
            <span>⚖️</span>
            <span>Weighing (Gross Tare Net)</span>
          </div>
          <p class="text-xs text-slate-500">Gross: 52.40 Qtl • Tare: 2.40 Qtl • Net Certified: 50.00 Qtl</p>
        </div>

        <button onclick="CenterDesk.openPrintSlipModal('${token.id}')" class="btn-large w-full bg-slate-900 hover:bg-slate-800 text-white text-sm">
          🖨️ View & Print Certified Mandi Slip
        </button>
      </div>
    `;
  }

  // =========================================================================
  // 10. SCREEN 13: PAYMENT STATUS (DBT Direct Bank Transfer)
  // =========================================================================
  renderPayment(t, farmer, token) {
    return `
      <div class="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-sm space-y-6 max-w-2xl mx-auto">
        <div class="flex items-center justify-between border-b border-slate-100 pb-4">
          <button onclick="FarmerPortal.setView('dashboard')" class="btn-back-circle">
            <i data-lucide="arrow-left" class="w-4 h-4">←</i>
          </button>
          <span class="text-xs font-bold text-slate-400">Direct Benefit Transfer</span>
        </div>

        <div>
          <h3 class="text-2xl font-black text-slate-900">${t('quickPayment')}</h3>
          <p class="text-xs text-slate-500">
            Booking ID: <strong class="text-slate-800 font-mono">${token.bookingId || 'AFG20251015001'}</strong> • ${token.crop || 'Wheat'} (50 q)
          </p>
        </div>

        <!-- Big Amount Card (Screen 13) -->
        <div class="p-6 bg-emerald-50 rounded-3xl border border-emerald-200 text-center space-y-2">
          <span class="text-xs font-bold text-emerald-800 uppercase tracking-wide">Procurement Amount</span>
          <div class="text-4xl sm:text-5xl font-black text-emerald-700 font-mono">
            ₹${(token.expectedTotal || 113750).toLocaleString('en-IN')}
          </div>
          <div>
            <span class="inline-block px-3 py-1 rounded-full text-xs font-bold bg-emerald-600 text-white shadow-sm">
              ✓ Payment Completed
            </span>
          </div>
        </div>

        <!-- Details Grid (Screen 13) -->
        <div class="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
          <div class="bg-slate-50 p-4 rounded-2xl border border-slate-200">
            <span class="text-slate-400 block mb-0.5">Payment Date</span>
            <strong class="text-slate-900 text-sm">15 Oct 2025</strong>
          </div>

          <div class="bg-slate-50 p-4 rounded-2xl border border-slate-200">
            <span class="text-slate-400 block mb-0.5">Transaction ID / UTR</span>
            <strong class="text-slate-900 text-sm font-mono">${token.utrNo || 'TXN1234567890'}</strong>
          </div>

          <div class="bg-slate-50 p-4 rounded-2xl border border-slate-200 sm:col-span-2">
            <span class="text-slate-400 block mb-0.5">Linked Bank Account (DBT Verified)</span>
            <strong class="text-slate-900 text-sm">Bank of India •••• 4821 (IFSC: BKID0009821)</strong>
          </div>
        </div>

        <!-- Payment History Timeline (Screen 13) -->
        <div class="space-y-2 pt-1">
          <h4 class="text-xs font-bold text-slate-700 uppercase tracking-wide">Payment History</h4>
          <div class="divide-y divide-slate-100 border border-slate-200 rounded-2xl overflow-hidden text-xs">
            <div class="p-3.5 flex justify-between items-center bg-white">
              <div>
                <strong class="text-slate-900">Payment Received</strong>
                <p class="text-[11px] text-slate-400">16 Oct 2025 • Direct NEFT/DBT</p>
              </div>
              <span class="font-mono font-bold text-emerald-700 text-sm">+ ₹${(token.expectedTotal || 113750).toLocaleString('en-IN')}</span>
            </div>

            <div class="p-3.5 flex justify-between items-center bg-white">
              <div>
                <strong class="text-slate-900">Amount Credited</strong>
                <p class="text-[11px] text-slate-400">15 Oct 2025 • PFMS Batch #4891</p>
              </div>
              <span class="font-mono font-bold text-emerald-700 text-sm">+ ₹${(token.expectedTotal || 113750).toLocaleString('en-IN')}</span>
            </div>
          </div>
        </div>
      </div>
    `;
  }

  // =========================================================================
  // 11. SCREEN 14: NOTIFICATIONS
  // =========================================================================
  renderNotifications(t, farmer) {
    const notifications = farmer.notifications || [];

    return `
      <div class="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-sm space-y-6 max-w-2xl mx-auto">
        <div class="flex items-center justify-between border-b border-slate-100 pb-4">
          <button onclick="FarmerPortal.setView('dashboard')" class="btn-back-circle">
            <i data-lucide="arrow-left" class="w-4 h-4">←</i>
          </button>
          <span class="text-xs font-bold text-slate-400">${notifications.length} Alerts</span>
        </div>

        <div>
          <h3 class="text-2xl font-black text-slate-900">${t('quickNotifications')}</h3>
          <p class="text-xs text-slate-500">Official updates via SMS & AgriFlow App</p>
        </div>

        <!-- Notifications List (Screen 14) -->
        <div class="space-y-3">
          ${notifications.map(n => `
            <div class="p-4 rounded-2xl border border-slate-200 bg-slate-50 flex items-start gap-3.5">
              <div class="w-9 h-9 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center flex-shrink-0 text-base">
                ${n.tag === 'SMS' ? '📩' : n.tag === 'Gate' ? '🚪' : '🔔'}
              </div>
              <div class="flex-1">
                <div class="flex items-center justify-between">
                  <h4 class="text-xs sm:text-sm font-bold text-slate-900">${n.title}</h4>
                  <span class="px-2 py-0.5 rounded-full text-[10px] font-bold ${n.tag === 'SMS' ? 'bg-blue-100 text-blue-700' : 'bg-emerald-100 text-emerald-700'}">${n.tag || 'App'}</span>
                </div>
                <p class="text-xs text-slate-600 mt-1">${n.body}</p>
                <span class="text-[10px] text-slate-400 block mt-1">${n.time}</span>
              </div>
            </div>
          `).join('')}
        </div>
      </div>
    `;
  }

  // =========================================================================
  // 12. SCREEN 9: MY BOOKINGS
  // =========================================================================
  renderMyBookings(t, farmer) {
    const all = farmer.bookings || [];
    let filtered = all;
    if (this.bookingsFilter === 'booked') {
      filtered = all.filter(b => b.status === 'Booked');
    } else if (this.bookingsFilter === 'in_progress') {
      filtered = all.filter(b => b.status === 'In Progress');
    } else if (this.bookingsFilter === 'completed') {
      filtered = all.filter(b => b.status === 'Completed');
    }

    return `
      <div class="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-sm space-y-6 max-w-3xl mx-auto">
        <div class="flex items-center justify-between border-b border-slate-100 pb-4">
          <button onclick="FarmerPortal.setView('dashboard')" class="btn-back-circle">
            <i data-lucide="arrow-left" class="w-4 h-4">←</i>
          </button>
          <button onclick="FarmerPortal.setView('book-step1')" class="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold shadow-sm">
            + Book New Slot
          </button>
        </div>

        <div>
          <h3 class="text-2xl font-black text-slate-900">${t('quickMyBookings')}</h3>
          <p class="text-xs text-slate-500">Track current tokens, weighment history, and download slips</p>
        </div>

        <!-- Filter Tabs (Screen 9) -->
        <div class="flex items-center gap-2 border-b border-slate-100 pb-3 text-xs overflow-x-auto">
          <button onclick="FarmerPortal.setBookingsFilter('all')" class="px-3 py-1.5 rounded-xl font-bold transition ${this.bookingsFilter === 'all' ? 'bg-emerald-600 text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'}">
            All (${all.length})
          </button>
          <button onclick="FarmerPortal.setBookingsFilter('booked')" class="px-3 py-1.5 rounded-xl font-bold transition ${this.bookingsFilter === 'booked' ? 'bg-emerald-600 text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'}">
            Booked
          </button>
          <button onclick="FarmerPortal.setBookingsFilter('in_progress')" class="px-3 py-1.5 rounded-xl font-bold transition ${this.bookingsFilter === 'in_progress' ? 'bg-emerald-600 text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'}">
            In Progress
          </button>
          <button onclick="FarmerPortal.setBookingsFilter('completed')" class="px-3 py-1.5 rounded-xl font-bold transition ${this.bookingsFilter === 'completed' ? 'bg-emerald-600 text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'}">
            Completed
          </button>
        </div>

        <!-- Bookings Cards List (Screen 9) -->
        <div class="space-y-4">
          ${filtered.map(b => {
            const isBooked = b.status === 'Booked';
            const isProg = b.status === 'In Progress';
            const isDone = b.status === 'Completed';

            return `
              <div class="p-5 rounded-2xl border-2 border-slate-200 bg-white space-y-3 hover:border-emerald-500 transition">
                <div class="flex items-start justify-between">
                  <div>
                    <span class="text-xs font-mono font-bold text-slate-400">${b.bookingId}</span>
                    <h4 class="text-base font-black text-slate-900 mt-0.5">${b.crop} • ${b.qty} Qtl</h4>
                    <p class="text-xs text-slate-500">${b.center} • ${b.date}, ${b.timeSlot}</p>
                  </div>

                  <span class="px-3 py-1 rounded-full text-xs font-bold ${isBooked ? 'bg-blue-100 text-blue-800' : isProg ? 'bg-amber-100 text-amber-800' : isDone ? 'bg-emerald-100 text-emerald-800' : 'bg-rose-100 text-rose-800'}">
                    ${b.status}
                  </span>
                </div>

                <div class="flex items-center justify-between pt-2 border-t border-slate-100 text-xs">
                  <div>
                    <span class="text-slate-400">Token: </span>
                    <strong class="text-base font-black font-mono text-emerald-600">${b.token}</strong>
                  </div>

                  <div class="flex items-center gap-2">
                    <button onclick="FarmerPortal.setView('token-qr')" class="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-xl font-bold">
                      View QR Pass
                    </button>
                    <button onclick="CenterDesk.openPrintSlipModal('${b.token}')" class="px-3 py-1.5 bg-slate-900 hover:bg-slate-800 text-white rounded-xl font-bold">
                      Print Slip
                    </button>
                  </div>
                </div>
              </div>
            `;
          }).join('')}
        </div>
      </div>
    `;
  }
}

window.FarmerPortal = new FarmerPortalController();

