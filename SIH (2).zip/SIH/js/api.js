/**
 * KisanSetu - Live Backend API Bridge & Socket.IO Real-Time Connector
 * Connects the Frontend UI with the Node.js/Express/MongoDB Atlas Central Backend.
 * Seamlessly fails over to offline local storage if backend is not running.
 */

const KisanSetuApi = {
  // Configurable base URLs
  BASE_URL: 'http://localhost:5000/api',
  SOCKET_URL: 'http://localhost:5000',
  
  // Connection state
  isBackendConnected: false,
  socket: null,
  authToken: localStorage.getItem('kisansetu_jwt') || null,

  /**
   * Initialize API Bridge and WebSocket Listeners
   */
  async init() {
    await this.checkHealth();
    this.initWebSocket();
    this.renderBackendStatusIndicator();
    
    // Periodic heartbeat every 15 seconds
    setInterval(() => this.checkHealth(), 15000);
  },

  /**
   * Ping /api/health to detect whether Node.js backend is active
   */
  async checkHealth() {
    try {
      const response = await fetch(`${this.BASE_URL}/health`, {
        method: 'GET',
        headers: { 'Content-Type': 'application/json' },
        signal: AbortSignal.timeout(3000)
      });

      if (response.ok) {
        const data = await response.json();
        const wasDisconnected = !this.isBackendConnected;
        this.isBackendConnected = true;
        this.renderBackendStatusIndicator();

        if (wasDisconnected) {
          console.log('🟢 [KisanSetu Bridge]: Connected to Live Node.js / MongoDB Atlas Backend!');
          // Synchronize initial data from backend
          this.syncWithBackend();
        }
        return true;
      }
    } catch (err) {
      if (this.isBackendConnected) {
        console.warn('🟡 [KisanSetu Bridge]: Backend unreachable. Falling back to local offline mode.');
      }
      this.isBackendConnected = false;
      this.renderBackendStatusIndicator();
      return false;
    }
  },

  /**
   * Initialize Socket.IO connection for real-time yard updates
   */
  initWebSocket() {
    if (typeof io === 'undefined') return;

    try {
      this.socket = io(this.SOCKET_URL, {
        transports: ['websocket', 'polling'],
        reconnectionAttempts: 5,
        reconnectionDelay: 2000
      });

      this.socket.on('connect', () => {
        console.log('⚡ [Socket.IO]: Connected with socket ID:', this.socket.id);
        
        // Auto-join active center room
        const activeCenter = window.KisanStore ? window.KisanStore.getActiveMandi() : null;
        if (activeCenter && activeCenter.id) {
          this.socket.emit('join:center', activeCenter.id);
        }
      });

      // Real-time queue advance event
      this.socket.on('queue:updated', (data) => {
        console.log('⚡ [Socket.IO]: Received queue:updated event', data);
        if (window.CenterDesk && typeof window.CenterDesk.render === 'function') {
          window.CenterDesk.render();
        }
      });

      // Real-time token called event (Audio/Visual Alert)
      this.socket.on('token:called', (tokenData) => {
        console.log('🚨 [Socket.IO]: Token Called:', tokenData);
        this.showToast(`🚨 Token ${tokenData.token} called to ${tokenData.assignedBay || 'Bay'}!`, 'info');
      });

      // Targeted farmer personal notification
      this.socket.on('notification', (payload) => {
        console.log('📱 [Socket.IO]: Personal Farmer Notification:', payload);
        this.showToast(payload.message, 'success');
      });

    } catch (err) {
      console.warn('WebSocket init failed (offline mode):', err);
    }
  },

  /**
   * Helper: Standard Authenticated HTTP Fetcher
   */
  async request(endpoint, options = {}) {
    const url = `${this.BASE_URL}${endpoint}`;
    const headers = {
      'Content-Type': 'application/json',
      ...(options.headers || {})
    };

    if (this.authToken) {
      headers['Authorization'] = `Bearer ${this.authToken}`;
    }

    const config = {
      ...options,
      headers
    };

    const res = await fetch(url, config);
    const result = await res.json();

    if (!res.ok) {
      throw new Error(result.message || 'API request failed');
    }

    return result.data;
  },

  /**
   * 1. Authentication Endpoints
   */
  async sendOtp(phone) {
    return this.request('/auth/send-otp', {
      method: 'POST',
      body: JSON.stringify({ phone })
    });
  },

  async verifyOtp(phone, otp) {
    const data = await this.request('/auth/verify-otp', {
      method: 'POST',
      body: JSON.stringify({ phone, otp })
    });
    if (data.token) {
      this.setAuthToken(data.token);
    }
    return data;
  },

  async loginOfficial(email, password) {
    const data = await this.request('/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email, password })
    });
    if (data.token) {
      this.setAuthToken(data.token);
    }
    return data;
  },

  setAuthToken(token) {
    this.authToken = token;
    localStorage.setItem('kisansetu_jwt', token);
  },

  clearAuthToken() {
    this.authToken = null;
    localStorage.removeItem('kisansetu_jwt');
  },

  /**
   * 2. Procurement Centers & Slots
   */
  async getCenters(filters = {}) {
    const query = new URLSearchParams(filters).toString();
    return this.request(`/centers${query ? `?${query}` : ''}`);
  },

  async getSlots(centerCode, date) {
    return this.request(`/slots?centerCode=${centerCode}&date=${date}&status=AVAILABLE`);
  },

  /**
   * 3. Procurement Slot Booking
   */
  async bookSlot(bookingPayload) {
    return this.request('/bookings', {
      method: 'POST',
      body: JSON.stringify(bookingPayload)
    });
  },

  async getBookings() {
    return this.request('/bookings');
  },

  async trackBooking(bookingIdOrToken) {
    return this.request(`/bookings/track/${encodeURIComponent(bookingIdOrToken)}`);
  },

  async cancelBooking(bookingId, reason) {
    return this.request(`/bookings/${bookingId}/cancel`, {
      method: 'PATCH',
      body: JSON.stringify({ reason })
    });
  },

  /**
   * 4. Gate Check-In Operations
   */
  async gateCheckIn(qrPayloadOrData) {
    return this.request('/checkin/scan', {
      method: 'POST',
      body: JSON.stringify(qrPayloadOrData)
    });
  },

  /**
   * 5. Real-Time Yard Queue & Live ETA
   */
  async getLiveQueue(centerId) {
    return this.request(`/queue/${centerId}`);
  },

  async getLiveEta(bookingId) {
    return this.request(`/queue/eta/${bookingId}`);
  },

  async callNextVehicle(centerId, targetBay = 'BAY-01', lane = null) {
    return this.request('/queue/call-next', {
      method: 'POST',
      body: JSON.stringify({ centerId, targetBay, lane })
    });
  },

  /**
   * 6. Weighbridge Gross & Tare Weighment
   */
  async recordGrossWeight(bookingId, grossWeightKg, weighbridgeLane = 'WB-01') {
    return this.request('/weighment/gross', {
      method: 'POST',
      body: JSON.stringify({ bookingId, grossWeightKg, weighbridgeLane })
    });
  },

  async recordTareWeight(bookingId, tareWeightKg) {
    return this.request('/weighment/tare', {
      method: 'POST',
      body: JSON.stringify({ bookingId, tareWeightKg })
    });
  },

  /**
   * 7. Quality Testing / Moisture Assay
   */
  async recordQualityAssay(assayData) {
    return this.request('/quality/assay', {
      method: 'POST',
      body: JSON.stringify(assayData)
    });
  },

  /**
   * 8. MSP Billing & DBT Payout
   */
  async generateBill(bookingId) {
    return this.request('/bills/generate', {
      method: 'POST',
      body: JSON.stringify({ bookingId })
    });
  },

  async initiateDbtPayment(billId) {
    return this.request('/payments/initiate', {
      method: 'POST',
      body: JSON.stringify({ billId })
    });
  },

  async simulateBankCredit(paymentId) {
    return this.request('/payments/simulate-credit', {
      method: 'POST',
      body: JSON.stringify({ paymentId })
    });
  },

  /**
   * 9. District Telemetrics & Live Heatmap
   */
  async getHeatmap(filters = {}) {
    const query = new URLSearchParams(filters).toString();
    return this.request(`/district/heatmap${query ? `?${query}` : ''}`);
  },

  async getDistrictOverview(state, district) {
    const params = {};
    if (state && state !== 'all') params.state = state;
    if (district && district !== 'all') params.district = district;
    const query = new URLSearchParams(params).toString();
    return this.request(`/district/overview${query ? `?${query}` : ''}`);
  },

  /**
   * Synchronize local state with live MongoDB Atlas data
   */
  async syncWithBackend() {
    try {
      const heatmapData = await this.getHeatmap();
      if (heatmapData && heatmapData.heatmap && window.KisanStore) {
        console.log(`📊 [Sync]: Synced ${heatmapData.heatmap.length} pan-India APMC Mandis from MongoDB Atlas!`);
      }
    } catch (err) {
      console.warn('Backend sync failed:', err.message);
    }
  },

  /**
   * Visual Connection Badge in Top Header
   */
  renderBackendStatusIndicator() {
    let container = document.getElementById('backend-status-badge');
    if (!container) {
      // Find suitable insertion spot in top header
      const headerBrand = document.querySelector('.forest-header .flex.items-center.gap-3');
      if (headerBrand && headerBrand.parentNode) {
        container = document.createElement('div');
        container.id = 'backend-status-badge';
        container.className = 'ml-auto flex items-center gap-2 text-xs font-semibold';
        headerBrand.parentNode.appendChild(container);
      }
    }

    if (!container) return;

    if (this.isBackendConnected) {
      container.innerHTML = `
        <div class="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-emerald-950/80 text-emerald-300 border border-emerald-500/40 shadow-sm cursor-pointer" title="Live Node.js / Express Server connected to MongoDB Atlas">
          <span class="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
          <span class="w-2 h-2 rounded-full bg-emerald-400 -ml-3.5"></span>
          <span>Live Backend (Atlas)</span>
        </div>
      `;
    } else {
      container.innerHTML = `
        <div class="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-amber-950/80 text-amber-300 border border-amber-500/40 shadow-sm cursor-pointer" onclick="KisanSetuApi.checkHealth()" title="Click to reconnect. Backend is offline; running in local storage fallback.">
          <span class="w-2 h-2 rounded-full bg-amber-400"></span>
          <span>Offline Demo Mode</span>
        </div>
      `;
    }
  },

  /**
   * Toast notification helper
   */
  showToast(message, type = 'info') {
    const toast = document.createElement('div');
    const bgClass = type === 'success' ? 'bg-emerald-600 text-white' : type === 'error' ? 'bg-rose-600 text-white' : 'bg-slate-800 text-yellow-300';
    toast.className = `fixed bottom-5 right-5 z-[9999] px-4 py-3 rounded-xl shadow-2xl ${bgClass} text-sm font-semibold flex items-center gap-2 border border-white/20 transition-all duration-300 transform translate-y-2 opacity-0`;
    toast.innerHTML = `<span>🔔</span> <span>${message}</span>`;
    document.body.appendChild(toast);

    requestAnimationFrame(() => {
      toast.classList.remove('translate-y-2', 'opacity-0');
    });

    setTimeout(() => {
      toast.classList.add('translate-y-2', 'opacity-0');
      setTimeout(() => toast.remove(), 300);
    }, 4000);
  }
};

// Expose globally
window.KisanSetuApi = KisanSetuApi;

// Auto-initialize when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
  KisanSetuApi.init();
});
