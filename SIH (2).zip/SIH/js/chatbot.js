/**
 * KisanSetu - AI Help Chatbot (Kisan AI Sahayak / किसान AI सहायक)
 * Multi-Language AI Assistant supporting 7 Indian languages:
 * 1. English (en)
 * 2. Hindi / हिंदी (hi)
 * 3. Marathi / मराठी (mr)
 * 4. Punjabi / ਪੰਜਾਬੀ (pa)
 * 5. Gujarati / ગુજરાતી (gu)
 * 6. Bengali / বাংলা (bn)
 * 7. Tamil / தமிழ் (ta)
 * 
 * Features:
 * - Floating, non-intrusive collapsible widget (zero screen overcrowding)
 * - 1-tap fast question chips in all 7 languages
 * - Live state querying (real-time token status, mandi wait times, queue position)
 * - Text-to-Speech (speechSynthesis) read-aloud for illiterate or busy farmers
 * - Voice Input (SpeechRecognition) for hands-free voice questioning
 * - Knowledge base covering MSP rates, slot booking, gate QR pass, moisture norms, DBT/PFMS transfers
 */

class KisanChatbotController {
  constructor() {
    this.isOpen = false;
    this.currentLang = 'mr'; // default matches project default (Marathi/Maharashtra)
    this.messages = [];
    this.isSpeaking = false;
    this.isListening = false;
    this.recognition = null;
    this.speechUtterance = null;
    this.domMounted = false;

    // Multi-language text & knowledge base
    this.i18n = {
      en: {
        botTitle: 'Kisan AI Sahayak',
        botSubtitle: 'Online • 7 Languages Voice & Text AI',
        inputPlaceholder: 'Ask a question or select a topic below...',
        sendBtn: 'Send',
        listeningText: 'Listening... Speak now',
        welcomeMsg: "Namaste! I am **Kisan AI Sahayak**, your intelligent mandi assistant. I can assist you with slot booking, today's MSP rates, gate QR passes, grain quality standards, or DBT bank transfers. How can I help you today?",
        chips: [
          { label: '🌾 Today MSP Rates', query: 'What are today MSP rates?' },
          { label: '📅 How to book slot?', query: 'How do I book a mandi slot?' },
          { label: '🎫 My Token Status', query: 'What is my token status?' },
          { label: '💳 When does DBT arrive?', query: 'How does DBT payment work?' },
          { label: '📄 Required documents', query: 'What documents are required at mandi?' },
          { label: '⏱️ Mandi waiting time', query: 'How much is the mandi wait time?' }
        ],
        voiceLangTag: 'en-IN',
        fallbackMsg: "I understand you are asking about agricultural procurement. You can ask me about **MSP rates, slot booking, gate QR pass, grain moisture norms (<12%), or DBT payment**. You can also reach the National Kisan Call Center at **1800-180-1551** (Toll-Free)."
      },
      hi: {
        botTitle: 'किसान AI सहायक',
        botSubtitle: 'सक्रिय • ७ भाषाओं में आवाज़ व टेक्स्ट AI',
        inputPlaceholder: 'अपना सवाल पूछें या नीचे विकल्प चुनें...',
        sendBtn: 'भेजें',
        listeningText: 'सुन रहा हूँ... बोलिए',
        welcomeMsg: "नमस्ते किसान भाई! मैं **किसान AI सहायक** हूँ। स्लॉट बुकिंग, आज के न्यूनतम समर्थन मूल्य (MSP), मंडी टोकन स्थिति, अनाज नमी नियम, या सीधे बैंक खाते में भुगतान (DBT) से जुड़े किसी भी सवाल में आपकी पूरी मदद करूँगा।",
        chips: [
          { label: '🌾 आज के MSP भाव', query: 'आज के एमएसपी भाव क्या हैं?' },
          { label: '📅 स्लॉट कैसे बुक करें?', query: 'मंडी में स्लॉट कैसे बुक करें?' },
          { label: '🎫 मेरा टोकन स्टेटस', query: 'मेरा टोकन स्टेटस क्या है?' },
          { label: '💳 बैंक में पैसे कब आएंगे?', query: 'DBT भुगतान कब और कैसे मिलता है?' },
          { label: '📄 आवश्यक दस्तावेज', query: 'मंडी के लिए कौन से दस्तावेज चाहिए?' },
          { label: '⏱️ मंडी में भीड़ व समय', query: 'मंडी में कितना समय लगेगा?' }
        ],
        voiceLangTag: 'hi-IN',
        fallbackMsg: "मैं आपकी बात समझ रहा हूँ। आप मुझसे **एमएसपी दर, स्लॉट बुकिंग, गेट पास क्यूआर, नमी परीक्षण (<12%) या डीबीटी बैंक भुगतान** के बारे में पूछ सकते हैं। आप राष्ट्रीय किसान कॉल सेंटर **1800-180-1551** (निःशुल्क) पर भी कॉल कर सकते हैं।"
      },
      mr: {
        botTitle: 'किसान AI सहायक',
        botSubtitle: 'सक्रिय • ७ भाषांमध्ये व्हॉइस व टेक्स्ट AI',
        inputPlaceholder: 'तुमचा प्रश्न विचारा किंवा खालील पर्याय निवडा...',
        sendBtn: 'पाठवा',
        listeningText: 'ऐकत आहे... बोला',
        welcomeMsg: "नमस्कार शेतकरी बांधवांनो! मी **किसान AI सहायक** आहे. स्लॉट बुकिंग, आजचे हमीभाव (MSP), मंडी टोकन स्थिती, धान्यातील ओलावा प्रमाण, किंवा थेट बँक खात्यात जमा (DBT) बद्दल तुम्हाला हवी ती माहिती मी देऊ शकतो.",
        chips: [
          { label: '🌾 आजचे हमीभाव (MSP)', query: 'आजचे पिकांचे हमीभाव काय आहेत?' },
          { label: '📅 स्लॉट कसा बुक करायचा?', query: 'मंडीत स्लॉट कसा बुक करावा?' },
          { label: '🎫 माझा टोकन स्टेटस', query: 'माझ्या टोकनचा स्टेटस काय आहे?' },
          { label: '💳 बँकेत पैसे कधी जमा होतात?', query: 'DBT द्वारे पैसे कधी जमा होतात?' },
          { label: '📄 लागणारी कागदपत्रे', query: 'मंडीत जाताना कोणती कागदपत्रे लागतात?' },
          { label: '⏱️ मंडीत रांग व वेळ', query: 'मंडीत सध्या किती वेळ लागेल?' }
        ],
        voiceLangTag: 'mr-IN',
        fallbackMsg: "मी आपला प्रश्न समजून घेत आहे. आपण मला **हमीभाव (MSP), स्लॉट बुकिंग, गेट पास QR कोड, धान्यातील ओलावा (<१२%), किंवा DBT बँक जमा** याबद्दल विचारू शकता. अधिक माहितीसाठी किसान कॉल सेंटर **१८००-१८०-१५५१** (टोल-फ्री) वर संपर्क करू शकता."
      },
      pa: {
        botTitle: 'ਕਿਸਾਨ AI ਸਹਾਇਕ',
        botSubtitle: 'ਸਰਗਰਮ • 7 ਭਾਸ਼ਾਵਾਂ ਵਿੱਚ ਆਵਾਜ਼ ਅਤੇ ਟੈਕਸਟ AI',
        inputPlaceholder: 'ਆਪਣਾ ਸਵਾਲ ਪੁੱਛੋ ਜਾਂ ਹੇਠਾਂ ਦਿੱਤਾ ਵਿਕਲਪ ਚੁਣੋ...',
        sendBtn: 'ਭੇਜੋ',
        listeningText: 'ਸੁਣ ਰਿਹਾ ਹਾਂ... ਬੋਲੋ ਜੀ',
        welcomeMsg: "ਸਤਿ ਸ੍ਰੀ ਅਕਾਲ ਕਿਸਾਨ ਵੀਰੋ! ਮੈਂ **ਕਿਸਾਨ AI ਸਹਾਇਕ** ਹਾਂ। ਸਲਾਟ ਬੁਕਿੰਗ, ਅੱਜ ਦੇ ਸਰਕਾਰੀ ਐਮ.ਐਸ.ਪੀ. ਭਾਅ, ਮੰਡੀ ਟੋਕਨ, ਨਮੀ ਦੇ ਨਿਯਮ ਜਾਂ ਸਿੱਧੇ ਬੈਂਕ ਖਾਤੇ ਵਿੱਚ ਪੈਸਿਆਂ (DBT) ਬਾਰੇ ਕੋਈ ਵੀ ਸਵਾਲ ਪੁੱਛ ਸਕਦੇ ਹੋ।",
        chips: [
          { label: '🌾 ਅੱਜ ਦੇ MSP ਭਾਅ', query: 'ਅੱਜ ਦੇ MSP ਰੇਟ ਕੀ ਹਨ?' },
          { label: '📅 ਸਲਾਟ ਕਿਵੇਂ ਬੁੱਕ ਕਰੀਏ?', query: 'ਮੰਡੀ ਦਾ ਸਲਾਟ ਕਿਵੇਂ ਬੁੱਕ ਕਰੀਏ?' },
          { label: '🎫 ਮੇਰਾ ਟੋਕਨ ਸਟੇਟਸ', query: 'ਮੇਰਾ ਟੋਕਨ ਸਟੇਟਸ ਕੀ ਹੈ?' },
          { label: '💳 ਬੈਂਕ ਪੈਸੇ ਕਦੋਂ ਆਉਣਗੇ?', query: 'DBT ਰਾਹੀਂ ਬੈਂਕ ਪੈਸੇ ਕਦੋਂ ਆਉਂਦੇ ਹਨ?' },
          { label: '📄 ਲੋੜੀਂਦੇ ਦਸਤਾਵੇਜ਼', query: 'ਮੰਡੀ ਲਈ ਕਿਹੜੇ ਕਾਗਜ਼ ਚਾਹੀਦੇ ਹਨ?' },
          { label: '⏱️ ਮੰਡੀ ਵਿੱਚ ਭੀੜ ਤੇ ਸਮਾਂ', query: 'ਮੰਡੀ ਵਿੱਚ ਕਿੰਨਾ ਸਮਾਂ ਲੱਗੇਗਾ?' }
        ],
        voiceLangTag: 'pa-IN',
        fallbackMsg: "ਤੁਸੀਂ **ਸਰਕਾਰੀ MSP ਭਾਅ, ਸਲਾਟ ਬੁਕਿੰਗ, ਗੇਟ ਪਾਸ QR, ਨਮੀ ਦੇ ਮਾਪਦੰਡ (<12%) ਜਾਂ DBT ਭੁਗਤਾਨ** ਬਾਰੇ ਜਾਣਕਾਰੀ ਲੈ ਸਕਦੇ ਹੋ। ਕਿਸਾਨ ਹੈਲਪਲਾਈਨ **1800-180-1551** (ਟੋਲ-ਫ੍ਰੀ) 'ਤੇ ਵੀ ਸੰਪਰਕ ਕਰ ਸਕਦੇ ਹੋ।"
      },
      gu: {
        botTitle: 'કિસાન AI સહાયક',
        botSubtitle: 'ઓનલાઇન • ૭ ભાષાઓમાં અવાજ અને ટેક્સ્ટ AI',
        inputPlaceholder: 'તમારો પ્રશ્ન પૂછો અથવા નીચેથી વિકલ્પ પસંદ કરો...',
        sendBtn: 'મોકલો',
        listeningText: 'સાંભળી રહ્યો છું... બોલો',
        welcomeMsg: "નમસ્તે ખેડૂત મિત્રો! હું **કિસાન AI સહાયક** છું. સ્લોટ બુકિંગ, ટેકાના ભાવ (MSP), યાર્ડ ટોકન સ્થિતિ, ભેજ નિયમો અથવા સીધા બેંક ખાતામાં જમા (DBT) અંગે સંપૂર્ણ સહાય મેળવો.",
        chips: [
          { label: '🌾 આજના ટેકાના ભાવ (MSP)', query: 'આજના ટેકાના ભાવ શું છે?' },
          { label: '📅 સ્લોટ કેવી રીતે બુક કરવો?', query: 'યાર્ડમાં સ્લોટ કેવી રીતે બુક કરવો?' },
          { label: '🎫 મારો ટોકન સ્ટેટસ', query: 'મારો ટોકન સ્ટેટસ શું છે?' },
          { label: '💳 બેંકમાં નાણાં ક્યારે આવશે?', query: 'DBT નાણાં ક્યારે જમા થશે?' },
          { label: '📄 જરૂરી કાગળો', query: 'યાર્ડ માટે કયા દસ્તાવેજો જોઈએ?' },
          { label: '⏱️ યાર્ડમાં સમય અને લાઇન', query: 'યાર્ડમાં કેટલો સમય લાગશે?' }
        ],
        voiceLangTag: 'gu-IN',
        fallbackMsg: "તમે **ટેકાના ભાવ (MSP), સ્લોટ બુકિંગ, ગેટ પાસ QR, ભેજનું પ્રમાણ (<12%) અથવા DBT બેંક ચુકવણી** વિશે માહિતી મેળવી શકો છો. કિસાન કોલ સેન્ટર **1800-180-1551** (ટોલ-ફ્રી) પર પણ સંપર્ક કરી શકો છો."
      },
      bn: {
        botTitle: 'কিষাণ AI সহায়ক',
        botSubtitle: 'সক্রিয় • ৭টি ভাষায় ভয়েস ও টেক্সট AI',
        inputPlaceholder: 'আপনার প্রশ্ন লিখুন বা নিচের বিকল্পটি বেছে নিন...',
        sendBtn: 'পাঠান',
        listeningText: 'শুনছি... বলুন',
        welcomeMsg: "নমস্কার কৃষক বন্ধুরা! আমি **কিষাণ AI সহায়ক**। স্লট বুকিং, আজকের সরকারি এমএসপি (MSP) দর, মান্ডি টোকেন অবস্থা, আর্দ্রতার নিয়ম, বা সরাসরি ব্যাংক অ্যাকাউন্টে টাকা জমা (DBT) নিয়ে যেকোনো প্রশ্ন করতে পারেন।",
        chips: [
          { label: '🌾 আজকের MSP দর', query: 'আজকের ফসলের MSP দর কত?' },
          { label: '📅 স্লট কীভাবে বুক করবেন?', query: 'মান্ডিতে স্লট কীভাবে বুক করতে হয়?' },
          { label: '🎫 আমার টোকেন স্ট্যাটাস', query: 'আমার টোকেন স্ট্যাটাস কী?' },
          { label: '💳 ব্যাংকে টাকা কখন আসবে?', query: 'DBT পেমেন্ট কীভাবে এবং কখন পাওয়া যায়?' },
          { label: '📄 প্রয়োজনীয় নথিপত্র', query: 'মান্ডিতে কী কী নথিপত্র লাগবে?' },
          { label: '⏱️ মান্ডির লাইন ও সময়', query: 'মান্ডিতে কতক্ষণ অপেক্ষা করতে হবে?' }
        ],
        voiceLangTag: 'bn-IN',
        fallbackMsg: "আপনি **ফসলের MSP দর, স্লট বুকিং, গেট পাস QR, আর্দ্রতা মান (<১২%) বা DBT ব্যাংক পেমেন্ট** সম্পর্কে জিজ্ঞাসা করতে পারেন। কিষাণ কল সেন্টার **১৮০০-১৮০-১৫৫১** (টোল-ফ্রি) নম্বরে যোগাযোগ করতে পারেন।"
      },
      ta: {
        botTitle: 'கிசான் AI உதவியாளர்',
        botSubtitle: 'இணைப்பில் • 7 மொழிகளில் குரல் மற்றும் உரை AI',
        inputPlaceholder: 'உங்கள் கேள்வியைக் கேளுங்கள் அல்லது தேர்வு செய்யவும்...',
        sendBtn: 'அனுப்பு',
        listeningText: 'கேட்கிறது... பேசுங்கள்',
        welcomeMsg: "வணக்கம் விவசாய தோழர்களே! நான் **கிசான் AI உதவியாளர்**. டோக்கன் முன்பதிவு, இன்றைய குறைந்தபட்ச ஆதரவு விலை (MSP), மண்டி வரிசை நிலை, ஈரப்பதம் விதிகள் அல்லது நேரடி வங்கி வரவு (DBT) பற்றி நீங்கள் என்னிடம் கேட்கலாம்.",
        chips: [
          { label: '🌾 இன்றைய MSP விலை', query: 'இன்றைய MSP விலை என்ன?' },
          { label: '📅 டோக்கன் பதிவு செய்வது எப்படி?', query: 'மண்டியில் டோக்கன் பதிவு செய்வது எப்படி?' },
          { label: '🎫 என் டோக்கன் நிலை', query: 'என் டோக்கன் நிலை என்ன?' },
          { label: '💳 வங்கிக்கு பணம் எப்போது வரும்?', query: 'DBT பணம் எப்போது கிடைக்கும்?' },
          { label: '📄 தேவையான ஆவணங்கள்', query: 'மண்டிக்கு என்ன ஆவணங்கள் தேவை?' },
          { label: '⏱️ காத்திருப்பு நேரம்', query: 'மண்டியில் எவ்வளவு நேரம் ஆகும்?' }
        ],
        voiceLangTag: 'ta-IN',
        fallbackMsg: "நீங்கள் **குறைந்தபட்ச ஆதரவு விலை (MSP), டோக்கன் பதிவு, நுழைவுச்சீட்டு QR, தானிய ஈரப்பதம் (<12%) அல்லது DBT வங்கி பரிமாற்றம்** பற்றி கேட்கலாம். கிசான் அழைப்பு மையம் **1800-180-1551** (கட்டணமில்லா) ஐயும் தொடர்பு கொள்ளலாம்."
      }
    };
  }

  init() {
    // Sync language with KisanStore
    try {
      if (window.KisanStore) {
        const storeLang = window.KisanStore.getState().currentLanguage || 'mr';
        if (this.i18n[storeLang]) {
          this.currentLang = storeLang;
        }
        window.KisanStore.subscribe(() => {
          const newLang = window.KisanStore.getState().currentLanguage;
          if (newLang && this.i18n[newLang] && newLang !== this.currentLang) {
            this.currentLang = newLang;
            this.render();
          }
        });
      }
    } catch (e) {}

    // Add initial welcome message if empty
    if (this.messages.length === 0) {
      const strings = this.i18n[this.currentLang] || this.i18n.en;
      this.messages.push({
        id: 'msg_welcome',
        sender: 'bot',
        text: strings.welcomeMsg,
        time: this.getFormattedTime()
      });
    }

    this.mountDOM();
    this.render();
    this.initSpeechRecognition();
  }

  getFormattedTime() {
    const d = new Date();
    return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  }

  mountDOM() {
    if (this.domMounted) return;

    // Create chatbot container
    const container = document.createElement('div');
    container.id = 'kisansetu-ai-chatbot-root';
    container.className = 'fixed bottom-5 right-5 z-50 flex flex-col items-end print:hidden select-none font-sans';
    document.body.appendChild(container);
    this.domMounted = true;
  }

  toggleChat() {
    this.isOpen = !this.isOpen;
    if (this.isOpen) {
      // If voice is speaking on open, keep it or stop
    } else {
      this.stopSpeaking();
      this.stopListening();
    }
    this.render();
    if (this.isOpen) {
      setTimeout(() => {
        const input = document.getElementById('chatbot-user-input');
        if (input) input.focus();
        this.scrollToBottom();
      }, 100);
    }
  }

  setLanguage(lang) {
    if (!this.i18n[lang]) return;
    this.currentLang = lang;
    const strings = this.i18n[lang];

    // Also update global store if available
    if (window.KisanStore && typeof window.KisanStore.setLanguage === 'function') {
      window.KisanStore.setLanguage(lang);
    }

    // Add switch notification message
    this.messages.push({
      id: 'msg_' + Date.now(),
      sender: 'bot',
      text: strings.welcomeMsg,
      time: this.getFormattedTime()
    });

    this.render();
    this.scrollToBottom();
  }

  initSpeechRecognition() {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) {
      return;
    }
    try {
      this.recognition = new SpeechRecognition();
      this.recognition.continuous = false;
      this.recognition.interimResults = false;

      this.recognition.onstart = () => {
        this.isListening = true;
        this.renderListeningState();
      };

      this.recognition.onresult = (event) => {
        const transcript = event.results[0][0].transcript;
        this.isListening = false;
        this.renderListeningState();
        if (transcript) {
          this.handleUserSend(transcript);
        }
      };

      this.recognition.onerror = (e) => {
        console.warn('Speech recognition error:', e);
        this.isListening = false;
        this.renderListeningState();
      };

      this.recognition.onend = () => {
        this.isListening = false;
        this.renderListeningState();
      };
    } catch (e) {
      console.warn('Speech recognition init error:', e);
    }
  }

  toggleVoiceInput() {
    if (!this.recognition) {
      alert('Voice recognition is not supported in this browser. Please type your question.');
      return;
    }
    if (this.isListening) {
      this.recognition.stop();
      this.isListening = false;
      this.renderListeningState();
    } else {
      const strings = this.i18n[this.currentLang] || this.i18n.en;
      this.recognition.lang = strings.voiceLangTag || 'hi-IN';
      try {
        this.recognition.start();
      } catch (e) {
        console.warn('Voice start error:', e);
      }
    }
  }

  stopListening() {
    if (this.recognition && this.isListening) {
      try { this.recognition.stop(); } catch (e) {}
      this.isListening = false;
    }
  }

  speakText(rawText) {
    if (!('speechSynthesis' in window)) {
      alert('Text-to-speech is not supported in this browser.');
      return;
    }

    if (this.isSpeaking) {
      window.speechSynthesis.cancel();
      this.isSpeaking = false;
      this.render();
      return;
    }

    // Strip markdown formatting for cleaner speech
    const cleanText = rawText
      .replace(/\*\*(.*?)\*\*/g, '$1')
      .replace(/👉/g, '')
      .replace(/🌾|📅|🎫|💳|📄|⏱️|✅|❌|₹/g, ' ')
      .replace(/[\(\)]/g, ' ')
      .trim();

    const strings = this.i18n[this.currentLang] || this.i18n.en;
    const utterance = new SpeechSynthesisUtterance(cleanText);
    utterance.lang = strings.voiceLangTag || 'hi-IN';
    utterance.rate = 0.95;

    // Try to pick regional voice if available
    const voices = window.speechSynthesis.getVoices();
    const matchedVoice = voices.find(v => v.lang.startsWith(this.currentLang) || v.lang.includes(strings.voiceLangTag));
    if (matchedVoice) utterance.voice = matchedVoice;

    utterance.onstart = () => {
      this.isSpeaking = true;
      this.renderSpeakerState();
    };

    utterance.onend = () => {
      this.isSpeaking = false;
      this.renderSpeakerState();
    };

    utterance.onerror = () => {
      this.isSpeaking = false;
      this.renderSpeakerState();
    };

    window.speechSynthesis.cancel();
    window.speechSynthesis.speak(utterance);
  }

  stopSpeaking() {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      this.isSpeaking = false;
    }
  }

  handleUserSend(text) {
    const query = (text || '').trim();
    if (!query) return;

    // Add user message
    this.messages.push({
      id: 'usr_' + Date.now(),
      sender: 'user',
      text: query,
      time: this.getFormattedTime()
    });

    this.render();
    this.scrollToBottom();

    // Clear input
    const input = document.getElementById('chatbot-user-input');
    if (input) input.value = '';

    // Show simulated AI thinking
    const botThinkingId = 'think_' + Date.now();
    this.messages.push({
      id: botThinkingId,
      sender: 'bot',
      isThinking: true,
      text: '...',
      time: this.getFormattedTime()
    });
    this.render();
    this.scrollToBottom();

    setTimeout(() => {
      // Remove thinking indicator
      this.messages = this.messages.filter(m => m.id !== botThinkingId);

      // Generate intelligent answer
      const botResponse = this.generateResponse(query);
      this.messages.push({
        id: 'bot_' + Date.now(),
        sender: 'bot',
        text: botResponse.text,
        actions: botResponse.actions,
        time: this.getFormattedTime()
      });

      this.render();
      this.scrollToBottom();
    }, 450);
  }

  /**
   * Comprehensive Multi-Language Knowledge Engine
   */
  generateResponse(query) {
    const q = query.toLowerCase();
    const lang = this.currentLang;
    const state = window.KisanStore ? window.KisanStore.getState() : {};
    const activeToken = state.farmer?.activeToken;
    const selectedState = state.selectedState || 'Maharashtra';
    const selectedDistrict = state.selectedDistrict || 'Pune';

    // 1. MSP Rates Query
    if (
      q.includes('msp') || q.includes('rate') || q.includes('price') || q.includes('भाव') || 
      q.includes('हमीभाव') || q.includes('टेका') || q.includes('દર') || q.includes('விலை') ||
      q.includes('soybean') || q.includes('rice') || q.includes('mustard') || q.includes('wheat') ||
      q.includes('सोयाबीन') || q.includes('भात') || q.includes('तांदूळ') || q.includes('गहू') || q.includes('मोहरी')
    ) {
      return this.getMspResponse(lang);
    }

    // 2. Token Status Query
    if (
      q.includes('token') || q.includes('टोकन') || q.includes('status') || q.includes('स्थिती') || 
      q.includes('माझा') || q.includes('मेरा') || q.includes('நிலை') || q.includes('টোকেন') ||
      q.includes('queue') || q.includes('रांग') || q.includes('नंबर')
    ) {
      return this.getTokenStatusResponse(lang, activeToken);
    }

    // 3. Slot Booking Query
    if (
      q.includes('slot') || q.includes('स्लॉट') || q.includes('book') || q.includes('बुक') || 
      q.includes('कसा') || q.includes('कैसे') || q.includes('ਕਿਵੇਂ') || q.includes('नोंदणी') || 
      q.includes('பதிவு') || q.includes('বুকিং')
    ) {
      return this.getSlotBookingResponse(lang, selectedState, selectedDistrict);
    }

    // 4. DBT / Bank Payment Query
    if (
      q.includes('dbt') || q.includes('bank') || q.includes('payment') || q.includes('पैसा') || 
      q.includes('पैसे') || q.includes('बँक') || q.includes('खाता') || q.includes('pfms') || 
      q.includes('ரூபாய்') || q.includes('টাকা') || q.includes('નાણાં')
    ) {
      return this.getDbtResponse(lang);
    }

    // 5. Required Documents Query
    if (
      q.includes('document') || q.includes('कागद') || q.includes('दस्तावेज') || q.includes('कागदपत्रे') || 
      q.includes('aadhaar') || q.includes('आधार') || q.includes('7/12') || q.includes('सातबारा') || 
      q.includes('ஆவணங்கள்') || q.includes('নথি') || q.includes('દસ્તાવેજ')
    ) {
      return this.getDocumentsResponse(lang);
    }

    // 6. Mandi Wait Time / Congestion Query
    if (
      q.includes('wait') || q.includes('time') || q.includes('भीड़') || q.includes('गर्दी') || 
      q.includes('वेळ') || q.includes('समय') || q.includes('heatmap') || q.includes('ਟ੍ਰੈਫਿਕ') || 
      q.includes('જામ') || q.includes('நேரம்') || q.includes('দেরি')
    ) {
      return this.getCongestionResponse(lang, state);
    }

    // 7. Quality / Moisture Query
    if (
      q.includes('moisture') || q.includes('quality') || q.includes('नमी') || q.includes('ओलावा') || 
      q.includes('दर्जा') || q.includes('grade') || q.includes('वजन') || q.includes('ஈரப்பதம்') || 
      q.includes('আর্দ্রতা') || q.includes('ભેજ')
    ) {
      return this.getQualityResponse(lang);
    }

    // Default Fallback Response in current language
    const fallback = (this.i18n[lang] || this.i18n.en).fallbackMsg;
    return {
      text: fallback,
      actions: [
        { label: '🌾 MSP Rates', query: 'What are today MSP rates?' },
        { label: '📅 Book Slot', query: 'How do I book a mandi slot?' },
        { label: '🗺️ Open Heatmap', action: 'openHeatmap' }
      ]
    };
  }

  getMspResponse(lang) {
    const responses = {
      en: {
        text: "🌾 **Official Govt MSP Rates (2024-25 / 2025-26)**:\n\n" +
              "• **Soybean (सोयाबीन)**: ₹4,892 / quintal\n" +
              "• **Paddy / Rice (धान / भात)**: ₹2,320 / quintal (Grade A: ₹2,340)\n" +
              "• **Mustard (सरसों / मोहरी)**: ₹5,650 / quintal\n" +
              "• **Wheat (गेहूं / गहू)**: ₹2,275 / quintal\n" +
              "• **Cotton (कपास / कापूस)**: ₹7,121 / quintal (Medium: ₹6,620)\n" +
              "• **Gram / Chana (चना / हरभरा)**: ₹5,440 / quintal\n\n" +
              "💡 *All KisanSetu procurement is guaranteed at 100% Govt MSP without commission deductions.*",
        actions: [{ label: '📅 Book Slot for Crop', action: 'bookSlot' }]
      },
      hi: {
        text: "🌾 **वर्तमान सरकारी न्यूनतम समर्थन मूल्य (MSP दरें)**:\n\n" +
              "• **सोयाबीन**: ₹4,892 / क्विंटल\n" +
              "• **धान (चावल)**: ₹2,320 / क्विंटल (ग्रेड A: ₹2,340)\n" +
              "• **सरसों**: ₹5,650 / क्विंटल\n" +
              "• **गेहूं**: ₹2,275 / क्विंटल\n" +
              "• **कपास**: ₹7,121 / क्विंटल\n" +
              "• **चना (हरभरा)**: ₹5,440 / क्विंटल\n\n" +
              "💡 *किसानसेतू पोर्टल पर बिना किसी आढ़तिया/बिचौलिए के 100% सरकारी एमएसपी पर तुलाई की जाती है।*",
        actions: [{ label: '📅 स्लॉट बुक करें', action: 'bookSlot' }]
      },
      mr: {
        text: "🌾 **शासकीय हमीभाव (MSP) दर सूची २०२४-२५**:\n\n" +
              "• **सोयाबीन**: ₹४,८९२ / क्विंटल\n" +
              "• **धान / भात**: ₹२,३२० / क्विंटल (ग्रेड A: ₹२,३४०)\n" +
              "• **मोहरी (Mustard)**: ₹५,६५० / क्विंटल\n" +
              "• **गहू**: ₹२,२७५ / क्विंटल\n" +
              "• **कापूस**: ₹७,१२१ / क्विंटल\n" +
              "• **चना (हरभरा)**: ₹५,४४० / क्विंटल\n\n" +
              "💡 *किसानसेतू द्वारे थेट हमीभावाने खरेदी केली जाते, कोणतेही दलालीचे पैसे कापले जात नाहीत.*",
        actions: [{ label: '📅 स्लॉट बुक करा', action: 'bookSlot' }]
      },
      pa: {
        text: "🌾 **ਸਰਕਾਰੀ ਐਮ.ਐਸ.ਪੀ. (MSP) ਰੇਟ ਸੂਚੀ**:\n\n" +
              "• **ਸੋਇਆਬੀਨ**: ₹4,892 / ਕੁਇੰਟਲ\n" +
              "• **ਝੋਨਾ / ਧਾਨ**: ₹2,320 / ਕੁਇੰਟਲ (ਗ੍ਰੇਡ A: ₹2,340)\n" +
              "• **ਸਰ੍ਹੋਂ (Mustard)**: ₹5,650 / ਕੁਇੰਟਲ\n" +
              "• **ਕਣਕ**: ₹2,275 / ਕੁਇੰਟਲ\n" +
              "• **ਕਪਾਹ / ਨਰਮਾ**: ₹7,121 / ਕੁਇੰਟਲ\n\n" +
              "💡 *ਕਿਸਾਨਸੇਤੂ 'ਤੇ 100% ਸਰਕਾਰੀ ਭਾਅ ਸਿੱਧਾ ਕਿਸਾਨ ਦੇ ਖਾਤੇ ਵਿੱਚ ਪਾਇਆ ਜਾਂਦਾ ਹੈ।*",
        actions: [{ label: '📅 ਸਲਾਟ ਬੁੱਕ ਕਰੋ', action: 'bookSlot' }]
      },
      gu: {
        text: "🌾 **સરકારી ટેકાના ભાવ (MSP) યાદી**:\n\n" +
              "• **સોયાબીન**: ₹૪,૮૯૨ / ક્વિન્ટલ\n" +
              "• **ડાંગર (ચોખા)**: ₹૨,૩૨૦ / ક્વિન્ટલ (ગ્રેડ A: ₹૨,૩૪૦)\n" +
              "• **રાયડો (સરસવ)**: ₹૫,૬૫૦ / ક્વિન્ટલ\n" +
              "• **ઘઉં**: ₹૨,૨૭૫ / ક્વિન્ટલ\n" +
              "• **કપાસ**: ₹૭,૧૨૧ / ક્વિન્ટલ\n\n" +
              "💡 *કિસાનસેતુમાં સંપૂર્ણ ટેકાના ભાવ સાથે પારદર્શક વજન કરવામાં આવે છે.*",
        actions: [{ label: '📅 સ્લોટ બુક કરો', action: 'bookSlot' }]
      },
      bn: {
        text: "🌾 **সরকারি ন্যূনতম সমর্থন মূল্য (MSP) তালিকা**:\n\n" +
              "• **সয়াবিন**: ₹৪,৮৯২ / কুইন্টাল\n" +
              "• **ধান**: ₹২,৩২০ / কুইন্টাল (গ্রেড A: ₹২,৩৪০)\n" +
              "• **সরিষা**: ₹৫,৬৫০ / কুইন্টাল\n" +
              "• **গম**: ₹২,২৭৫ / কুইন্টাল\n" +
              "• **তুলা**: ₹৭,১২১ / কুইন্টাল\n\n" +
              "💡 *কিসানসেতুতে কোনো মধ্যস্বত্বভোগী ছাড়া সম্পূর্ণ সরকারি এমএসপিতে ফসল কেনা হয়।*",
        actions: [{ label: '📅 স্লট বুক করুন', action: 'bookSlot' }]
      },
      ta: {
        text: "🌾 **அரசு குறைந்தபட்ச ஆதரவு விலை (MSP)**:\n\n" +
              "• **சோயாபீன்**: ₹4,892 / குவிண்டால்\n" +
              "• **நெல்**: ₹2,320 / குவிண்டால் (தரம் A: ₹2,340)\n" +
              "• **கடுகு**: ₹5,650 / குவிண்டால்\n" +
              "• **கோதுமை**: ₹2,275 / குவிண்டால்\n" +
              "• **பருத்தி**: ₹7,121 / குவிண்டால்\n\n" +
              "💡 *கிசான்சேது மூலம் 100% அரசு நிர்ணய விலையில் எந்த இடைத்தரகர் கழிவும் இன்றி பணம் வரவு வைக்கப்படும்.*",
        actions: [{ label: '📅 டோக்கன் பதிவு செய்க', action: 'bookSlot' }]
      }
    };
    return responses[lang] || responses.en;
  }

  getTokenStatusResponse(lang, activeToken) {
    if (!activeToken) {
      const msgs = {
        en: "🎫 You do not have an active slot booking yet. You can book a slot in under 60 seconds with instant AI slot recommendations!",
        hi: "🎫 आपके पास अभी कोई सक्रिय टोकन नहीं है। आप 1 मिनट में किसान पोर्टल से आसान स्लॉट बुक कर सकते हैं!",
        mr: "🎫 तुमच्याकडे सध्या कोणतेही सक्रिय टोकन नाही. तुम्ही किसान पोर्टलवरून अवघ्या ६० सेकंदात AI स्लॉट बुक करू शकता!",
        pa: "🎫 ਤੁਹਾਡੇ ਕੋਲ ਅਜੇ ਕੋਈ ਬੁੱਕ ਕੀਤਾ ਟੋਕਨ ਨਹੀਂ ਹੈ। ਤੁਸੀਂ 1 ਮਿੰਟ ਵਿੱਚ ਆਪਣਾ ਸਲਾਟ ਬੁੱਕ ਕਰ ਸਕਦੇ ਹੋ!",
        gu: "🎫 તમારી પાસે હાલમાં કોઈ સક્રિય ટોકન નથી. તમે કિસાન પોર્ટલ પરથી સરળતાથી સ્લોટ બુક કરી શકો છો!",
        bn: "🎫 আপনার কোনো সক্রিয় টোকেন বুক করা নেই। আপনি এখনই কৃষক পোর্টালে গিয়ে স্লট বুক করতে পারেন!",
        ta: "🎫 உங்களிடம் தற்போது முன்பதிவு செய்யப்பட்ட டோக்கன் இல்லை. உடனே எளிதாக டோக்கன் பதிவு செய்யலாம்!"
      };
      return {
        text: msgs[lang] || msgs.en,
        actions: [{ label: '📅 Book My Slot', action: 'bookSlot' }]
      };
    }

    const tNum = activeToken.id || activeToken.tokenNo || 'A-018';
    const center = activeToken.centerName || 'Pune APMC Yard';
    const crop = activeToken.cropName || activeToken.crop || 'Soybean';
    const status = activeToken.status || 'Active in Queue';
    const slot = activeToken.slotTime || activeToken.timeSlot || '10:00 AM - 12:00 PM';

    const responses = {
      en: {
        text: `🎫 **Your Active Mandi Token Detail**:\n\n` +
              `• **Token Number**: \`${tNum}\`\n` +
              `• **Procurement Center**: ${center}\n` +
              `• **Crop**: ${crop}\n` +
              `• **Assigned Slot**: ⏱️ ${slot}\n` +
              `• **Current Status**: **${status}**\n\n` +
              `📱 Keep your QR Gate Pass ready on your phone when arriving at the Mandi weighbridge gate.`,
        actions: [{ label: '🔍 View Gate QR Pass', action: 'viewPass' }]
      },
      hi: {
        text: `🎫 **आपके सक्रिय टोकन की जानकारी**:\n\n` +
              `• **टोकन नंबर**: \`${tNum}\`\n` +
              `• **खरीद केंद्र**: ${center}\n` +
              `• **फसल**: ${crop}\n` +
              `• **निर्धारित समय (स्लॉट)**: ⏱️ ${slot}\n` +
              `• **वर्तमान स्थिति**: **${status}**\n\n` +
              `📱 मंडी गेट पर प्रवेश के लिए अपना डिजिटल क्यूआर पास तैयार रखें।`,
        actions: [{ label: '🔍 गेट क्यूआर पास देखें', action: 'viewPass' }]
      },
      mr: {
        text: `🎫 **तुमच्या सक्रिय टोकनचा तपशील**:\n\n` +
              `• **टोकन क्रमांक**: \`${tNum}\`\n` +
              `• **खरेदी केंद्र**: ${center}\n` +
              `• **पीक**: ${crop}\n` +
              `• **नेमून दिलेली वेळ**: ⏱️ ${slot}\n` +
              `• **सध्याची स्थिती**: **${status}**\n\n` +
              `📱 बाजार समितीच्या प्रवेशद्वारावर वजन काट्यावर दाखवण्यासाठी तुमचा डिजिटल QR पास तयार ठेवा.`,
        actions: [{ label: '🔍 गेट QR पास उघडा', action: 'viewPass' }]
      },
      pa: {
        text: `🎫 **ਤੁਹਾਡਾ ਮੰਡੀ ਟੋਕਨ ਸਟੇਟਸ**:\n\n` +
              `• **ਟੋਕਨ ਨੰਬਰ**: \`${tNum}\`\n` +
              `• **ਮੰਡੀ ਕੇਂਦਰ**: ${center}\n` +
              `• **ਫਸਲ**: ${crop}\n` +
              `• **ਸਮਾਂ**: ⏱️ ${slot}\n` +
              `• **ਸਥਿਤੀ**: **${status}**\n\n` +
              `📱 ਗੇਟ 'ਤੇ ਐਂਟਰੀ ਲਈ ਆਪਣਾ ਡਿਜੀਟਲ QR ਪਾਸ ਦਿਖਾਓ।`,
        actions: [{ label: '🔍 QR ਪਾਸ ਦੇਖੋ', action: 'viewPass' }]
      },
      gu: {
        text: `🎫 **તમારી ટોકન વિગત**:\n\n` +
              `• **ટોકન નંબર**: \`${tNum}\`\n` +
              `• **યાર્ડ કેન્દ્ર**: ${center}\n` +
              `• **પાક**: ${crop}\n` +
              `• **સમય સ્લોટ**: ⏱️ ${slot}\n` +
              `• **સ્થિતિ**: **${status}**\n\n` +
              `📱 યાર્ડના દરવાજે બતાવવા તમારો QR પાસ સાચવી રાખો.`,
        actions: [{ label: '🔍 QR પાસ જુઓ', action: 'viewPass' }]
      },
      bn: {
        text: `🎫 **আপনার মান্ডি টোকেনের বিবরণ**:\n\n` +
              `• **টোকেন নম্বর**: \`${tNum}\`\n` +
              `• **কেন্দ্র**: ${center}\n` +
              `• **ফসল**: ${crop}\n` +
              `• **সময়**: ⏱️ ${slot}\n` +
              `• **বর্তমান অবস্থা**: **${status}**\n\n` +
              `📱 মান্ডির গেটে দেখানোর জন্য আপনার ডিজিটাল QR পাস তৈরি রাখুন।`,
        actions: [{ label: '🔍 QR পাস দেখুন', action: 'viewPass' }]
      },
      ta: {
        text: `🎫 **உங்கள் டோக்கன் விவரம்**:\n\n` +
              `• **டோக்கன் எண்**: \`${tNum}\`\n` +
              `• **கொள்முதல் மையம்**: ${center}\n` +
              `• **பயிர்**: ${crop}\n` +
              `• **நேரம்**: ⏱️ ${slot}\n` +
              `• **தற்போதைய நிலை**: **${status}**\n\n` +
              `📱 நுழைவு வாயிலில் காட்ட உங்கள் QR சீட்டை தயார் நிலையில் வைத்திருக்கவும்.`,
        actions: [{ label: '🔍 QR பாஸ் பார்க்க', action: 'viewPass' }]
      }
    };

    return responses[lang] || responses.en;
  }

  getSlotBookingResponse(lang, stateName, districtName) {
    const responses = {
      en: {
        text: `📅 **How to Book a Mandi Slot in 3 Simple Steps**:\n\n` +
              `1️⃣ **Step 1**: Choose your crop (Soybean, Rice, Mustard) and quantity.\n` +
              `2️⃣ **Step 2**: Select **${stateName}**, choose your district (**${districtName}**), and pick your nearest APMC Mandi.\n` +
              `3️⃣ **Step 3**: Select your preferred date. Our **AI Recommended Engine** automatically highlights slots with **zero waiting time**!\n\n` +
              `✅ Instant digital SMS token & QR gate pass generated immediately.`,
        actions: [{ label: '🚀 Open Slot Booking Now', action: 'bookSlot' }]
      },
      hi: {
        text: `📅 **स्लॉट बुक करने के ३ आसान चरण**:\n\n` +
              `1️⃣ **चरण १**: अपनी फसल और मात्रा (क्विंटल) चुनें।\n` +
              `2️⃣ **चरण २**: **${stateName}** राज्य व **${districtName}** जिला चुनकर नजदीकी मंडी चुनें।\n` +
              `3️⃣ **चरण ३**: तारीख चुनें। हमारा **AI इंजन** सबसे कम भीड़ और शून्य वेटिंग वाला समय अपने आप सुझाएगा!\n\n` +
              `✅ स्लॉट कन्फर्म होते ही तुरंत डिजिटल QR गेट पास और एसएमएस मिल जाता है।`,
        actions: [{ label: '🚀 अभी स्लॉट बुक करें', action: 'bookSlot' }]
      },
      mr: {
        text: `📅 **मंडी स्लॉट बुक करण्याचे ३ सोपे टप्पे**:\n\n` +
              `1️⃣ **टप्पा १**: तुमचे पीक (सोयाबीन, भात, मोहरी) व अंदाजे वजन निवडा.\n` +
              `2️⃣ **टप्पा २**: राज्य **${stateName}** आणि जिल्हा **${districtName}** निवडून जवळची बाजार समिती निवडा.\n` +
              `3️⃣ **टप्पा ३**: तारीख निवडा. आमची **AI प्रणाली** ज्या वेळेत गर्दी कमी असेल तो स्लॉट हिरव्या रंगात सुचवेल!\n\n` +
              `✅ बुकिंग होताच तत्काळ डिजिटल QR गेट पास व SMS मिळतो.`,
        actions: [{ label: '🚀 आता स्लॉट बुक करा', action: 'bookSlot' }]
      },
      pa: {
        text: `📅 **ਸਲਾਟ ਬੁਕਿੰਗ ਦੇ 3 ਆਸਾਨ ਕਦਮ**:\n\n` +
              `1️⃣ ਆਪਣੀ ਫਸਲ ਅਤੇ ਮਾਤਰਾ ਚੁਣੋ।\n` +
              `2️⃣ ਆਪਣਾ ਜ਼ਿਲ੍ਹਾ (**${districtName}**) ਅਤੇ ਨੇੜਲੀ ਮੰਡੀ ਚੁਣੋ।\n` +
              `3️⃣ ਸਾਡਾ **AI ਇੰਜਣ** ਸਭ ਤੋਂ ਘੱਟ ਭੀੜ ਵਾਲਾ ਸਲਾਟ ਆਪਣੇ-ਆਪ ਸੁਝਾਏਗਾ।\n\n` +
              `✅ ਤੁਰੰਤ QR ਕੋਡ ਵਾਲਾ ਮੰਡੀ ਪਾਸ ਮਿਲ ਜਾਵੇਗਾ।`,
        actions: [{ label: '🚀 ਸਲਾਟ ਬੁੱਕ ਕਰੋ', action: 'bookSlot' }]
      },
      gu: {
        text: `📅 **સ્લોટ બુકિંગના ૩ સરળ પગલાં**:\n\n` +
              `1️⃣ પાક અને જથ્થો પસંદ કરો.\n` +
              `2️⃣ તમારો જિલ્લો (**${districtName}**) અને નજીકનું યાર્ડ પસંદ કરો.\n` +
              `3️⃣ **AI ભલામણ** મુજબ ઓછી ભીડ વાળો સમય પસંદ કરો.\n\n` +
              `✅ તાત્કાલિક QR ગેટ પાસ મળી જશે.`,
        actions: [{ label: '🚀 સ્લોટ બુક કરો', action: 'bookSlot' }]
      },
      bn: {
        text: `📅 **স্লট বুক করার ৩টি সহজ ধাপ**:\n\n` +
              `1️⃣ ফসল ও পরিমাণ নির্বাচন করুন।\n` +
              `2️⃣ আপনার জেলা (**${districtName}**) এবং নিকটস্থ মান্ডি বেছে নিন।\n` +
              `3️⃣ **AI ইঞ্জিন** সবচেয়ে কম ভিড়ের স্লট স্বয়ংক্রিয়ভাবে দেখাবে।\n\n` +
              `✅ সাথে সাথে ডিজিটাল QR গেট পাস তৈরি হবে।`,
        actions: [{ label: '🚀 স্লট বুক করুন', action: 'bookSlot' }]
      },
      ta: {
        text: `📅 **டோக்கன் பதிவு செய்யும் 3 எளிய முறைகள்**:\n\n` +
              `1️⃣ பயிர் மற்றும் அளவைத் தேர்ந்தெடுக்கவும்.\n` +
              `2️⃣ உங்கள் மாவட்டம் (**${districtName}**) மற்றும் அருகிலுள்ள மண்டியைத் தேர்வு செய்யவும்.\n` +
              `3️⃣ **AI பரிந்துரை** மூலம் கூட்டம் இல்லாத நேரத்தைத் தேர்ந்தெடுக்கவும்.\n\n` +
              `✅ உடனடியாக டிஜிட்டல் QR சீட்டு கிடைக்கும்.`,
        actions: [{ label: '🚀 முன்பதிவு செய்ய', action: 'bookSlot' }]
      }
    };
    return responses[lang] || responses.en;
  }

  getDbtResponse(lang) {
    const responses = {
      en: {
        text: "💳 **Govt Direct Benefit Transfer (DBT / PFMS) Process**:\n\n" +
              "• **Zero Middlemen**: Money is sent straight from the State Procurement Fund into your Aadhaar-seeded bank account.\n" +
              "• **Settlement Speed**: Within **2 to 4 hours** of weighbridge QC approval (or instant RTGS via PFMS).\n" +
              "• **SMS Notification**: You receive an official UTR transaction reference code on your mobile.\n" +
              "• **No Deductions**: 100% full MSP rate value is disbursed without any unauthorized cuts.",
        actions: [{ label: '🌾 View MSP Rates', query: 'What are today MSP rates?' }]
      },
      hi: {
        text: "💳 **सरकारी प्रत्यक्ष लाभ अंतरण (DBT / PFMS) भुगतान नियम**:\n\n" +
              "• **सीधे खाते में**: तुलाई व गुणवत्ता जांच (QC) पास होते ही पैसा बिना किसी बिचौलिए के सीधे आपके आधार लिंक बैंक खाते में भेजा जाता है।\n" +
              "• **भुगतान समय**: तुलाई पर्ची कटने के **२ से ४ घंटे** के भीतर (तत्काल PFMS RTGS)।\n" +
              "• **एसएमएस पुष्टि**: यूटीआर (UTR) नंबर और जमा राशि का सरकारी एसएमएस आपके फोन पर आता है।\n" +
              "• **कोई कटौती नहीं**: १००% पूरे सरकारी एमएसपी का भुगतान किया जाता है।",
        actions: [{ label: '🌾 एमएसपी दरें देखें', query: 'आज के एमएसपी भाव क्या हैं?' }]
      },
      mr: {
        text: "💳 **शासकीय थेट बँक हस्तांतरण (DBT / PFMS) प्रक्रिया**:\n\n" +
              "• **थेट खात्यात पैसे**: वजन पावती व QC मंजूर होताच रक्कम थेट तुमच्या आधार-संलग्न बँक खात्यात वर्ग होते.\n" +
              "• **जमा होण्याचा वेळ**: बाजार समितीत मालाची तुलाई झाल्यानंतर **२ ते ४ तासांच्या आत**.\n" +
              "• **अधिकृत SMS**: पैसे जमा होताच बँकेचा अधिकृत UTR नंबर व संदेश मोबाइलवर येतो.\n" +
              "• **१००% हमीभाव**: दलाल किंवा मध्यस्थांशिवाय १ रुपयाही न कापता पूर्ण रक्कम जमा होते.",
        actions: [{ label: '🌾 हमीभाव पहा', query: 'आजचे पिकांचे हमीभाव काय आहेत?' }]
      },
      pa: {
        text: "💳 **ਸਰਕਾਰੀ DBT ਬੈਂਕ ਭੁਗਤਾਨ ਜਾਣਕਾਰੀ**:\n\n" +
              "• ਫਸਲ ਦੀ ਤੋਲਾਈ ਤੋਂ ਬਾਅਦ ਪੈਸੇ ਸਿੱਧੇ ਤੁਹਾਡੇ ਆਧਾਰ ਲਿੰਕ ਬੈਂਕ ਖਾਤੇ ਵਿੱਚ ਭੇਜੇ ਜਾਂਦੇ ਹਨ।\n" +
              "• ਸਮਾਂ: **2 ਤੋਂ 4 ਘੰਟੇ** ਦੇ ਅੰਦਰ ਤੁਰੰਤ RTGS / PFMS ਰਾਹੀਂ।\n" +
              "• ਬਿਨਾਂ ਕਿਸੇ ਕਮਿਸ਼ਨ ਦੇ 100% ਪੂਰੀ ਸਰਕਾਰੀ ਰਕਮ ਮਿਲਦੀ ਹੈ।",
        actions: [{ label: '🌾 MSP ਭਾਅ ਦੇਖੋ', query: 'ਅੱਜ ਦੇ MSP ਰੇਟ ਕੀ ਹਨ?' }]
      },
      gu: {
        text: "💳 **સરકારી DBT બેંક ચુકવણી પદ્ધતિ**:\n\n" +
              "• વજન અને ગુણવત્તા પાસ થતાં જ નાણાં સીધા આધાર લિંક બેંક ખાતામાં જમા થાય છે.\n" +
              "• સમય: **૨ થી ૪ કલાકની અંદર**.\n" +
              "• કોઈ વચેટિયા કે કમિશન વિના ૧૦૦% સંપૂર્ણ ટેકાના ભાવ મળે છે.",
        actions: [{ label: '🌾 ટેકાના ભાવ જુઓ', query: 'આજના ટેકાના ભાવ શું છે?' }]
      },
      bn: {
        text: "💳 **সরকারি DBT ব্যাংক পেমেন্ট প্রক্রিয়া**:\n\n" +
              "• ওজন সম্পন্ন হওয়ার পর টাকা সরাসরি আপনার আধার লিংকড ব্যাংক অ্যাকাউন্টে জমা হয়।\n" +
              "• সময়: মাত্র **২ থেকে ৪ ঘণ্টার মধ্যে**।\n" +
              "• কোনো কমিশন বা কাটছাঁট ছাড়া ১০০% সম্পূর্ণ MSP মূল্য দেওয়া হয়।",
        actions: [{ label: '🌾 MSP দর দেখুন', query: 'আজকের ফসলের MSP দর কত?' }]
      },
      ta: {
        text: "💳 **அரசு நேரடி வங்கி பரிமாற்றம் (DBT) விவரம்**:\n\n" +
              "• எடை போடப்பட்ட பிறகு இடைத்தரகர்கள் இன்றி பணம் நேரடியாக ஆதார் இணைக்கப்பட்ட வங்கிக் கணக்கில் வரவு வைக்கப்படும்.\n" +
              "• நேரம்: **2 முதல் 4 மணி நேரத்திற்குள்**.\n" +
              "• 100% முழு குறைந்தபட்ச ஆதரவு விலை எந்த பிடித்தமும் இன்றி வழங்கப்படும்.",
        actions: [{ label: '🌾 MSP விலை பார்க்க', query: 'இன்றைய MSP விலை என்ன?' }]
      }
    };
    return responses[lang] || responses.en;
  }

  getDocumentsResponse(lang) {
    const responses = {
      en: {
        text: "📄 **Checklist of Required Documents for Mandi Entry**:\n\n" +
              "1️⃣ **Aadhaar Card** (or PM-Kisan 12-digit Beneficiary ID)\n" +
              "2️⃣ **Land Record** (Satbara 7/12 Extract, Khasra, or Khatauni copy)\n" +
              "3️⃣ **Bank Passbook / Cancelled Cheque** (with active IFSC & DBT-enabled account)\n" +
              "4️⃣ **Digital Token SMS / QR Gate Pass** (on your smartphone or printed slip)\n" +
              "5️⃣ **Vehicle RC / Tractor Number** (registered during slot booking)",
        actions: [{ label: '📅 Book Slot Now', action: 'bookSlot' }]
      },
      hi: {
        text: "📄 **मंडी में लाते समय आवश्यक दस्तावेजों की सूची**:\n\n" +
              "1️⃣ **आधार कार्ड** (या पीएम-किसान १२-अंकीय लाभार्थी आईडी)\n" +
              "2️⃣ **जमीन का रिकॉर्ड** (खसरा, खतौनी या ७/१२ की प्रति)\n" +
              "3️⃣ **बैंक पासबुक** (डीबीटी सक्रिय और सही आईएफएससी कोड)\n" +
              "4️⃣ **डिजिटल टोकन एसएमएस या क्यूआर गेट पास** (मोबाइल में)\n" +
              "5️⃣ **वाहन / ट्रैक्टर का नंबर**",
        actions: [{ label: '📅 अभी स्लॉट बुक करें', action: 'bookSlot' }]
      },
      mr: {
        text: "📄 **बाजार समितीत येताना लागणारी आवश्यक कागदपत्रे**:\n\n" +
              "1️⃣ **आधार कार्ड** (किंवा PM-किसान लाभार्थी ओळख क्रमांक)\n" +
              "2️⃣ **जमिनीचा ७/१२ उतारा** (चालू वर्षाची संगणकीकृत प्रत)\n" +
              "3️⃣ **बँक पासबुक** (आधार लिंक केलेले बँक खाते)\n" +
              "4️⃣ **डिजिटल टोकन SMS किंवा QR गेट पास** (मोबाईलमध्ये किंवा प्रिंट)\n" +
              "5️⃣ **गाडी / ट्रॅक्टर नंबर**",
        actions: [{ label: '📅 स्लॉट बुक करा', action: 'bookSlot' }]
      },
      pa: {
        text: "📄 **ਮੰਡੀ ਲਈ ਲੋੜੀਂਦੇ ਦਸਤਾਵੇਜ਼**:\n\n" +
              "1️⃣ ਆਧਾਰ ਕਾਰਡ ਜਾਂ PM-ਕਿਸਾਨ ਆਈਡੀ\n" +
              "2️⃣ ਜ਼ਮੀਨ ਦੀ ਜਮ੍ਹਾਂਬੰਦੀ / ਫਰਦ\n" +
              "3️⃣ ਬੈਂਕ ਪਾਸਬੁੱਕ (ਆਧਾਰ ਲਿੰਕ ਖਾਤਾ)\n" +
              "4️⃣ ਮੋਬਾਈਲ ਵਿੱਚ ਡਿਜੀਟਲ QR ਟੋਕਨ ਪਾਸ\n" +
              "5️⃣ ਟਰੈਕਟਰ / ਗੱਡੀ ਦਾ ਨੰਬਰ",
        actions: [{ label: '📅 ਸਲਾਟ ਬੁੱਕ ਕਰੋ', action: 'bookSlot' }]
      },
      gu: {
        text: "📄 **યાર્ડમાં જરૂરી દસ્તાવેજોની યાદી**:\n\n" +
              "1️⃣ આધાર કાર્ડ અથવા PM-કિસાન આઈડી\n" +
              "2️⃣ ૭/૧૨ અથવા ૮-અ જમીનની નકલ\n" +
              "3️⃣ બેંક પાસબુક (DBT સક્રિય)\n" +
              "4️⃣ મોબાઈલમાં ડિજિટલ QR ટોકન પાસ\n" +
              "5️⃣ વાહન / ટ્રેક્ટર નંબર",
        actions: [{ label: '📅 સ્લોટ બુક કરો', action: 'bookSlot' }]
      },
      bn: {
        text: "📄 **মান্ডিতে প্রবেশের প্রয়োজনীয় নথিপত্র**:\n\n" +
              "1️⃣ আধার কার্ড বা পিএম-কিসান আইডি\n" +
              "2️⃣ জমির পরচা / খতিয়ান\n" +
              "3️⃣ ব্যাংক পাসবই (আধার লিংকড অ্যাকাউন্ট)\n" +
              "4️⃣ মোবাইলে ডিজিটাল QR টোকেন পাস\n" +
              "5️⃣ গাড়ি বা ট্রাক্টরের নম্বর",
        actions: [{ label: '📅 স্লট বুক করুন', action: 'bookSlot' }]
      },
      ta: {
        text: "📄 **மண்டிக்கு கொண்டுவர வேண்டிய ஆவணங்கள்**:\n\n" +
              "1️⃣ ஆதார் அட்டை அல்லது PM-கிசான் எண்\n" +
              "2️⃣ பட்டா / சிட்டா / நில ஆவணம்\n" +
              "3️⃣ வங்கி கணக்கு புத்தகம்\n" +
              "4️⃣ டிஜிட்டல் QR டோக்கன் சீட்டு\n" +
              "5️⃣ வாகனப் பதிவு எண்",
        actions: [{ label: '📅 டோக்கன் பதிவு செய்ய', action: 'bookSlot' }]
      }
    };
    return responses[lang] || responses.en;
  }

  getCongestionResponse(lang, state) {
    const mandis = state.mandis || [];
    const highMandi = mandis.find(m => m.congestionLevel === 'high' || m.status === 'High');
    const lowMandi = mandis.find(m => m.congestionLevel === 'low' || m.status === 'Low');

    const responses = {
      en: {
        text: "⏱️ **Live Mandi Traffic & Wait Times**:\n\n" +
              `• **Optimal Intake**: ${lowMandi ? lowMandi.name : 'Pune Gultekdi APMC'} has less than **15-20 min** wait time with open fast bays.\n` +
              (highMandi ? `• **Heavy Traffic Alert**: ${highMandi.name} has a queue of ~${highMandi.liveQueue || 45} vehicles. Detour recommended to nearby yards.\n\n` : '\n') +
              "🗺️ You can inspect the interactive **Live Heatmap** to see real-time godown capacity across all APMCs in India.",
        actions: [{ label: '🗺️ Open Live Heatmap', action: 'openHeatmap' }]
      },
      hi: {
        text: "⏱️ **लाइव मंडी भीड़ व प्रतीक्षा समय**:\n\n" +
              `• **सुगम केंद्र**: ${lowMandi ? lowMandi.name : 'पुणे गुलटेकडी मंडी'} में केवल **१५-२० मिनट** की कतार है।\n` +
              (highMandi ? `• **भारी जाम सूचना**: ${highMandi.name} में लगभग ${highMandi.liveQueue || 45} गाड़ियाँ कतार में हैं।\n\n` : '\n') +
              "🗺️ वास्तविक समय में सभी मंडियों की भीड़ देखने के लिए **लाइव हीटमैप** खोलें।",
        actions: [{ label: '🗺️ लाइव हीटमैप खोलें', action: 'openHeatmap' }]
      },
      mr: {
        text: "⏱️ **बाजार समितीतील गर्दी व रांगेची सद्यस्थिती**:\n\n" +
              `• **कमी गर्दी असलेले केंद्र**: ${lowMandi ? lowMandi.name : 'पुणे गुलटेकडी APMC'} येथे केवळ **१५ ते २० मिनिटे** प्रतीक्षा वेळ आहे.\n` +
              (highMandi ? `• **जास्त गर्दीचा इशारा**: ${highMandi.name} येथे सध्या सुमारे ${highMandi.liveQueue || 45} वाहने रांगेत आहेत.\n\n` : '\n') +
              "🗺️ सर्व केंद्रांची रिअल-टाइम स्थिती पाहण्यासाठी आमचा **लाईव्ह हीटमॅप** तपासा.",
        actions: [{ label: '🗺️ लाईव्ह हीटमॅप उघडा', action: 'openHeatmap' }]
      },
      pa: {
        text: "⏱️ **ਮੰਡੀ ਵਿੱਚ ਭੀੜ ਅਤੇ ਉਡੀਕ ਦਾ ਸਮਾਂ**:\n\n" +
              `• **ਤੇਜ਼ ਐਂਟਰੀ**: ${lowMandi ? lowMandi.name : 'ਪੁਣੇ APMC'} ਵਿੱਚ ਸਿਰਫ਼ **15-20 ਮਿੰਟ** ਉਡੀਕ ਹੈ।\n` +
              "🗺️ ਸਾਰੀਆਂ ਮੰਡੀਆਂ ਦੀ ਲਾਈਵ ਭੀੜ ਦੇਖਣ ਲਈ **ਲਾਈਵ ਹੀਟਮੈਪ** ਦੇਖੋ।",
        actions: [{ label: '🗺️ ਲਾਈਵ ਹੀਟਮੈਪ ਖੋਲ੍ਹੋ', action: 'openHeatmap' }]
      },
      gu: {
        text: "⏱️ **યાર્ડમાં ટ્રાફિક અને સમયની વિગત**:\n\n" +
              `• **સરળ પ્રવેશ**: ${lowMandi ? lowMandi.name : 'પૂણે APMC'} માં માત્ર **૧૫-૨૦ મિનિટ** રાહ જોવી પડશે.\n` +
              "🗺️ તમામ યાર્ડની સ્થિતિ જોવા માટે **લાઈવ હીટમેપ** જુઓ.",
        actions: [{ label: '🗺️ લાઈવ હીટમેપ ખોલો', action: 'openHeatmap' }]
      },
      bn: {
        text: "⏱️ **মান্ডিতে ভিড় ও অপেক্ষার সময়**:\n\n" +
              `• **দ্রুত প্রবেশ**: ${lowMandi ? lowMandi.name : 'পুনে APMC'} কেন্দ্রে মাত্র **১৫-২০ মিনিট** অপেক্ষা করতে হচ্ছে।\n` +
              "🗺️ সব মান্ডির লাইভ তথ্য জানতে **হিটম্যাপ** দেখুন।",
        actions: [{ label: '🗺️ লাইভ হিটম্যাপ খুলুন', action: 'openHeatmap' }]
      },
      ta: {
        text: "⏱️ **மண்டி நெரிசல் & காத்திருப்பு நேரம்**:\n\n" +
              `• **குறைந்த காத்திருப்பு**: ${lowMandi ? lowMandi.name : 'புனே APMC'} மையத்தில் **15-20 நிமிடங்கள்** மட்டுமே.\n` +
              "🗺️ நேரடி நிலவரத்தை அறிய **லைவ் வரைபடத்தை** பார்க்கவும்.",
        actions: [{ label: '🗺️ வரைபடம் பார்க்க', action: 'openHeatmap' }]
      }
    };
    return responses[lang] || responses.en;
  }

  getQualityResponse(lang) {
    const responses = {
      en: {
        text: "🔬 **Govt Grain Quality & Moisture Standards (QC Norms)**:\n\n" +
              "• **Grade A (100% MSP)**: Moisture below **12.0%**, clean grain with less than 2% foreign matter.\n" +
              "• **Grade B (Fair Average)**: Moisture between **12.0% - 14.0%** (eligible for immediate drying bay).\n" +
              "• **Caution (>14.0% Moisture)**: Grain will require on-site solar drying before weighbridge approval.\n\n" +
              "⚖️ *All weighing is conducted digitally on certified electronic weighbridges without manual tampering.*",
        actions: [{ label: '🌾 Check MSP Rates', query: 'What are today MSP rates?' }]
      },
      hi: {
        text: "🔬 **सरकारी अनाज गुणवत्ता एवं नमी मानक (QC नियम)**:\n\n" +
              "• **ग्रेड A (१००% एमएसपी)**: नमी **१२% से कम**, साफ दाना और कंकड़ २% से कम।\n" +
              "• **ग्रेड B (स्वीकार्य)**: नमी **१२% से १४%** के बीच।\n" +
              "• **ध्यान दें (>१४% नमी)**: यदि अनाज बहुत गीला है तो तुलाई से पहले धूप में सुखाना होगा।\n\n" +
              "⚖️ *तुलाई १००% कंप्यूटरीकृत धर्मकांटे पर पारदर्शी तरीके से होती है।*",
        actions: [{ label: '🌾 एमएसपी दरें देखें', query: 'आज के एमएसपी भाव क्या हैं?' }]
      },
      mr: {
        text: "🔬 **शेतीमाल गुणवत्ता व ओलावा प्रमाण (QC नियम)**:\n\n" +
              "• **ग्रेड A (१००% हमीभाव)**: धान्यातील ओलावा **१२% पेक्षा कमी** असावा, कचरा २% पेक्षा कमी.\n" +
              "• **ग्रेड B**: ओलावा **१२% ते १४%** दरम्यान.\n" +
              "• **सावधान (>१४% ओलावा)**: धान्य जास्त ओले असल्यास वाळवण्यासाठी वेळ दिला जातो.\n\n" +
              "⚖️ *सर्व वजन प्रमाणित इलेक्ट्रॉनिक वजन काट्यावर (Computerized Weighbridge) अचूक केले जाते.*",
        actions: [{ label: '🌾 हमीभाव पहा', query: 'आजचे पिकांचे हमीभाव काय आहेत?' }]
      },
      pa: {
        text: "🔬 **ਫਸਲ ਦੀ ਗੁਣਵੱਤਾ ਅਤੇ ਨਮੀ ਦੇ ਨਿਯਮ**:\n\n" +
              "• ਗ੍ਰੇਡ A: ਨਮੀ **12% ਤੋਂ ਘੱਟ** (ਪੂਰਾ 100% ਸਰਕਾਰੀ ਰੇਟ)।\n" +
              "• ਗ੍ਰੇਡ B: ਨਮੀ **12% ਤੋਂ 14%** ਤੱਕ।\n" +
              "• 14% ਤੋਂ ਵੱਧ ਨਮੀ ਵਾਲੀ ਫਸਲ ਨੂੰ ਸੁਕਾਉਣ ਦੀ ਲੋੜ ਹੁੰਦੀ ਹੈ।\n" +
              "⚖️ ਸਾਰੀ ਤੋਲਾਈ ਡਿਜੀਟਲ ਕੰਪਿਊਟਰ ਕੰਡੇ 'ਤੇ ਹੁੰਦੀ ਹੈ।",
        actions: [{ label: '🌾 MSP ਭਾਅ ਦੇਖੋ', query: 'ਅੱਜ ਦੇ MSP ਰੇਟ ਕੀ ਹਨ?' }]
      },
      gu: {
        text: "🔬 **પાકની ગુણવત્તા અને ભેજના નિયમો**:\n\n" +
              "• ગ્રેડ A: ભેજનું પ્રમાણ **૧૨% થી ઓછું** (૧૦૦% ટેકાના ભાવ).\n" +
              "• ગ્રેડ B: ભેજ **૧૨% થી ૧૪%** ની વચ્ચે.\n" +
              "• ૧૪% થી વધુ ભેજ હોય તો સુકવવું પડશે.\n" +
              "⚖️ વજન ૧૦૦% ડિજિટલ કાંટા પર થાય છે.",
        actions: [{ label: '🌾 ટેકાના ભાવ જુઓ', query: 'આજના ટેકાના ભાવ શું છે?' }]
      },
      bn: {
        text: "🔬 **ফসলের মান ও আর্দ্রতার নিয়ম**:\n\n" +
              "• গ্রেড A: আর্দ্রতা **১২% এর কম** (১০০% সম্পূর্ণ MSP)।\n" +
              "• গ্রেড B: আর্দ্রতা **১২% থেকে ১৪%**।\n" +
              "• ১৪% এর বেশি আর্দ্রতা থাকলে শুকিয়ে নিতে হবে।\n" +
              "⚖️ ওজন সম্পূর্ণ ডিজিটাল ওয়েব্রিজে করা হয়।",
        actions: [{ label: '🌾 MSP দর দেখুন', query: 'আজকের ফসলের MSP দর কত?' }]
      },
      ta: {
        text: "🔬 **தானிய தரம் & ஈரப்பதம் விதிகள்**:\n\n" +
              "• தரம் A: ஈரப்பதம் **12% க்கும் குறைவு** (100% முழு ஆதரவு விலை).\n" +
              "• தரம் B: ஈரப்பதம் **12% முதல் 14%** வரை.\n" +
              "• 14% க்கும் அதிகமான ஈரப்பதம் இருந்தால் காயவைக்க வேண்டும்.\n" +
              "⚖️ எடை 100% டிஜிட்டல் தராசில் துல்லியமாக போடப்படும்.",
        actions: [{ label: '🌾 MSP விலை பார்க்க', query: 'இன்றைய MSP விலை என்ன?' }]
      }
    };
    return responses[lang] || responses.en;
  }

  handleAction(actionType) {
    if (actionType === 'bookSlot') {
      if (window.App && typeof window.App.switchDashboard === 'function') {
        window.App.switchDashboard('farmer');
      } else if (window.FarmerPortal && typeof window.FarmerPortal.goToBookingStep === 'function') {
        window.FarmerPortal.goToBookingStep(1);
      }
      this.toggleChat(); // Minimize chat so user sees booking screen
    } else if (actionType === 'openHeatmap') {
      if (window.App && typeof window.App.openGlobalHeatmap === 'function') {
        window.App.openGlobalHeatmap();
      }
    } else if (actionType === 'viewPass') {
      if (window.App && typeof window.App.switchDashboard === 'function') {
        window.App.switchDashboard('farmer');
      }
      this.toggleChat();
    }
  }

  scrollToBottom() {
    const el = document.getElementById('chatbot-messages-container');
    if (el) {
      el.scrollTop = el.scrollHeight;
    }
  }

  renderSpeakerState() {
    const btn = document.getElementById('chatbot-global-speak-toggle');
    if (btn) {
      if (this.isSpeaking) {
        btn.innerHTML = '🔊 <span class="text-[10px] text-emerald-200 animate-pulse">Playing</span>';
      } else {
        btn.innerHTML = '🔊';
      }
    }
  }

  renderListeningState() {
    const micBtn = document.getElementById('chatbot-mic-btn');
    const input = document.getElementById('chatbot-user-input');
    const strings = this.i18n[this.currentLang] || this.i18n.en;

    if (micBtn) {
      if (this.isListening) {
        micBtn.classList.add('bg-rose-600', 'text-white', 'animate-pulse');
        micBtn.classList.remove('bg-slate-100', 'text-slate-600');
        if (input) input.placeholder = strings.listeningText || 'Listening...';
      } else {
        micBtn.classList.remove('bg-rose-600', 'text-white', 'animate-pulse');
        micBtn.classList.add('bg-slate-100', 'text-slate-600');
        if (input) input.placeholder = strings.inputPlaceholder || 'Ask a question...';
      }
    }
  }

  render() {
    const root = document.getElementById('kisansetu-ai-chatbot-root');
    if (!root) return;

    const strings = this.i18n[this.currentLang] || this.i18n.en;

    if (!this.isOpen) {
      // Sleek Floating Bubble (Non-overcrowded, elegant, with notification indicator)
      root.innerHTML = `
        <button 
          onclick="KisanChatbot.toggleChat()" 
          id="kisansetu-chatbot-fab" 
          class="group flex items-center gap-2.5 px-4 py-3 bg-gradient-to-r from-emerald-800 via-emerald-700 to-teal-800 hover:from-emerald-700 hover:to-teal-700 text-white rounded-full shadow-2xl hover:shadow-emerald-900/40 border-2 border-emerald-400/40 transition-all duration-200 transform hover:scale-105 active:scale-95"
          title="Open Kisan AI Sahayak"
        >
          <div class="relative w-7 h-7 rounded-full bg-emerald-950 flex items-center justify-center text-base shadow-inner">
            <span>🤖</span>
            <span class="absolute -top-0.5 -right-0.5 w-2.5 h-2.5 bg-emerald-400 border-2 border-emerald-900 rounded-full animate-ping"></span>
            <span class="absolute -top-0.5 -right-0.5 w-2.5 h-2.5 bg-emerald-400 border-2 border-emerald-900 rounded-full"></span>
          </div>
          <div class="flex flex-col text-left pr-1">
            <span class="text-xs font-black tracking-wide leading-tight">${strings.botTitle}</span>
            <span class="text-[10px] text-emerald-200 font-bold opacity-90 leading-tight">AI Help • 7 Languages</span>
          </div>
        </button>
      `;
      return;
    }

    // Expanded Chat Window
    root.innerHTML = `
      <!-- Chat Card Window -->
      <div class="w-[94vw] sm:w-[410px] h-[550px] max-h-[85vh] bg-white rounded-3xl shadow-2xl border border-emerald-900/20 flex flex-col overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        
        <!-- Header -->
        <div class="bg-gradient-to-r from-emerald-950 via-emerald-900 to-emerald-950 p-4 text-white flex items-center justify-between border-b border-emerald-800/80">
          <div class="flex items-center gap-2.5">
            <div class="w-10 h-10 rounded-2xl bg-gradient-to-br from-amber-400 to-yellow-500 text-emerald-950 flex items-center justify-center text-xl shadow-md border border-yellow-200/50 flex-shrink-0">
              🤖
            </div>
            <div>
              <div class="flex items-center gap-2">
                <h3 class="font-black text-sm tracking-tight text-white leading-tight">${strings.botTitle}</h3>
                <span class="px-1.5 py-0.2 rounded-full text-[9px] font-black bg-emerald-800 text-emerald-300 border border-emerald-600/60">
                  LIVE AI
                </span>
              </div>
              <p class="text-[11px] text-emerald-200 font-medium leading-tight mt-0.5 flex items-center gap-1.5">
                <span class="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
                <span>${strings.botSubtitle}</span>
              </p>
            </div>
          </div>

          <!-- Top Actions: Language Selector & Close -->
          <div class="flex items-center gap-1.5">
            <!-- In-Chat Language Selector Dropdown -->
            <select 
              onchange="KisanChatbot.setLanguage(this.value)" 
              class="bg-emerald-950/80 border border-emerald-700 text-yellow-300 rounded-xl px-2 py-1 text-[11px] font-bold focus:outline-none cursor-pointer"
              title="Change Chatbot Language"
            >
              <option value="mr" ${this.currentLang === 'mr' ? 'selected' : ''}>मराठी</option>
              <option value="hi" ${this.currentLang === 'hi' ? 'selected' : ''}>हिंदी</option>
              <option value="en" ${this.currentLang === 'en' ? 'selected' : ''}>English</option>
              <option value="pa" ${this.currentLang === 'pa' ? 'selected' : ''}>ਪੰਜਾਬੀ</option>
              <option value="gu" ${this.currentLang === 'gu' ? 'selected' : ''}>ગુજરાતી</option>
              <option value="bn" ${this.currentLang === 'bn' ? 'selected' : ''}>বাংলা</option>
              <option value="ta" ${this.currentLang === 'ta' ? 'selected' : ''}>தமிழ்</option>
            </select>

            <!-- Stop Speech Button if speaking -->
            <button 
              onclick="KisanChatbot.stopSpeaking()" 
              id="chatbot-global-speak-toggle"
              class="w-8 h-8 rounded-xl bg-emerald-950/80 hover:bg-emerald-800 border border-emerald-700/80 text-emerald-200 flex items-center justify-center text-xs transition"
              title="Voice narration"
            >
              🔊
            </button>

            <!-- Close Button -->
            <button 
              onclick="KisanChatbot.toggleChat()" 
              class="w-8 h-8 rounded-xl bg-emerald-950/80 hover:bg-rose-900/80 hover:text-white border border-emerald-700/80 text-emerald-300 flex items-center justify-center text-sm font-bold transition"
              title="Minimize Chatbot"
            >
              ✕
            </button>
          </div>
        </div>

        <!-- Quick Suggestions Strip (Horizontal scrollable chips) -->
        <div class="bg-slate-50 border-b border-slate-200 px-3 py-2 flex items-center gap-1.5 overflow-x-auto text-xs whitespace-nowrap">
          <span class="text-[10px] font-bold text-slate-400 uppercase tracking-wider flex-shrink-0">⚡ Quick:</span>
          ${strings.chips.map(chip => `
            <button 
              onclick="KisanChatbot.handleUserSend('${chip.query.replace(/'/g, "\\'")}')" 
              class="px-2.5 py-1 bg-white hover:bg-emerald-50 hover:border-emerald-300 hover:text-emerald-900 text-slate-700 border border-slate-200 rounded-xl text-[11px] font-bold shadow-xs transition flex-shrink-0"
            >
              ${chip.label}
            </button>
          `).join('')}
        </div>

        <!-- Message Feed Container -->
        <div id="chatbot-messages-container" class="flex-1 p-4 overflow-y-auto space-y-3.5 bg-gradient-to-b from-slate-50/50 to-white">
          ${this.messages.map(m => {
            const isBot = m.sender === 'bot';
            return `
              <div class="flex items-start gap-2.5 ${isBot ? 'justify-start' : 'justify-end'} animate-in fade-in duration-150">
                ${isBot ? `
                  <div class="w-7 h-7 rounded-xl bg-emerald-800 text-white flex items-center justify-center text-xs shadow-xs flex-shrink-0 mt-0.5">
                    🤖
                  </div>
                ` : ''}

                <div class="max-w-[84%] flex flex-col ${isBot ? 'items-start' : 'items-end'}">
                  <div class="p-3.5 rounded-2xl text-xs sm:text-[13px] leading-relaxed shadow-xs ${
                    isBot 
                      ? 'bg-white border border-slate-200 text-slate-800 rounded-tl-sm' 
                      : 'bg-emerald-700 text-white font-medium rounded-tr-sm shadow-emerald-800/10'
                  }">
                    ${m.isThinking ? `
                      <div class="flex items-center gap-1.5 py-1 text-slate-400">
                        <span class="w-2 h-2 rounded-full bg-emerald-600 animate-bounce"></span>
                        <span class="w-2 h-2 rounded-full bg-emerald-600 animate-bounce [animation-delay:0.2s]"></span>
                        <span class="w-2 h-2 rounded-full bg-emerald-600 animate-bounce [animation-delay:0.4s]"></span>
                      </div>
                    ` : `
                      <div class="whitespace-pre-line">${this.formatMarkdown(m.text)}</div>
                    `}
                  </div>

                  <!-- Action Buttons inside Bot Message -->
                  ${isBot && m.actions && m.actions.length > 0 ? `
                    <div class="flex items-center gap-1.5 flex-wrap mt-2">
                      ${m.actions.map(act => `
                        <button 
                          onclick="${act.action ? `KisanChatbot.handleAction('${act.action}')` : `KisanChatbot.handleUserSend('${(act.query || '').replace(/'/g, "\\'")}')`}"
                          class="px-3 py-1 bg-emerald-50 hover:bg-emerald-100 border border-emerald-300 text-emerald-900 rounded-xl text-[11px] font-bold transition flex items-center gap-1 shadow-2xs"
                        >
                          ${act.label}
                        </button>
                      `).join('')}
                    </div>
                  ` : ''}

                  <!-- Message Footer: Time + Read Aloud Button -->
                  <div class="flex items-center gap-2 mt-1 px-1 text-[10px] text-slate-400">
                    <span>${m.time}</span>
                    ${isBot && !m.isThinking ? `
                      <button 
                        onclick="KisanChatbot.speakText('${m.text.replace(/'/g, "\\'").replace(/\n/g, ' ')}')" 
                        class="hover:text-emerald-700 font-bold flex items-center gap-0.5 transition"
                        title="Listen to this message"
                      >
                        <span>🔊</span>
                        <span>Listen</span>
                      </button>
                    ` : ''}
                  </div>
                </div>

                ${!isBot ? `
                  <div class="w-7 h-7 rounded-xl bg-slate-200 text-slate-700 flex items-center justify-center text-xs shadow-xs flex-shrink-0 mt-0.5">
                    👤
                  </div>
                ` : ''}
              </div>
            `;
          }).join('')}
        </div>

        <!-- Input Footer -->
        <div class="p-3 border-t border-slate-200 bg-white">
          <form onsubmit="event.preventDefault(); KisanChatbot.handleUserSend(document.getElementById('chatbot-user-input').value)" class="flex items-center gap-2">
            
            <!-- Voice Input Mic Button -->
            <button 
              type="button" 
              onclick="KisanChatbot.toggleVoiceInput()" 
              id="chatbot-mic-btn"
              class="w-10 h-10 rounded-2xl bg-slate-100 hover:bg-emerald-100 text-slate-600 hover:text-emerald-800 flex items-center justify-center text-base transition flex-shrink-0 shadow-inner"
              title="Voice Input (Speak your question)"
            >
              🎙️
            </button>

            <!-- Text Input -->
            <input 
              type="text" 
              id="chatbot-user-input" 
              placeholder="${strings.inputPlaceholder}"
              autocomplete="off"
              class="flex-1 px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-2xl text-xs sm:text-sm text-slate-900 focus:outline-none focus:border-emerald-600 transition"
            />

            <!-- Send Button -->
            <button 
              type="submit" 
              class="px-4 py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-2xl text-xs font-black shadow-sm transition flex items-center justify-center flex-shrink-0"
              title="${strings.sendBtn}"
            >
              <span>➤</span>
            </button>
          </form>

          <div class="flex items-center justify-between text-[10px] text-slate-400 mt-2 px-1">
            <span>KisanSetu Multi-Language AI • 100% Free</span>
            <span class="flex items-center gap-1 font-semibold text-emerald-700">
              <span>🇮🇳</span>
              <span>7 Indian Languages</span>
            </span>
          </div>
        </div>

      </div>
    `;
  }

  formatMarkdown(text) {
    if (!text) return '';
    return text
      .replace(/\*\*(.*?)\*\*/g, '<strong class="font-black text-slate-900">$1</strong>')
      .replace(/\*(.*?)\*/g, '<em class="italic">$1</em>')
      .replace(/`([^`]+)`/g, '<code class="px-1.5 py-0.5 rounded bg-slate-100 border border-slate-200 text-emerald-900 font-mono text-[11px] font-bold">$1</code>');
  }
}

// Global Singleton
window.KisanChatbot = new KisanChatbotController();

// Auto-initialize when DOM is ready
function initKisanChatbotSafely() {
  try {
    if (window.KisanChatbot && typeof window.KisanChatbot.init === 'function') {
      window.KisanChatbot.init();
    }
  } catch (err) {
    console.error('Failed to init KisanChatbot:', err);
  }
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initKisanChatbotSafely);
} else {
  initKisanChatbotSafely();
}
window.addEventListener('load', initKisanChatbotSafely);
