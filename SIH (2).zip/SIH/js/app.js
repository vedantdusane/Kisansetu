/**
 * KisanSetu - Master App Controller
 * Dedicated Login & Onboarding pages for:
 * 1. Farmer (Matching Sketchflow screens: Welcome -> Language -> Mobile -> OTP -> Profile Setup)
 * 2. Mandi Center Official Admin Desk Login
 * 3. District Officer Command Admin Login
 */

class SoundSynthesizer {
  constructor() {
    this.ctx = null;
  }

  getAudioContext() {
    if (!this.ctx && (window.AudioContext || window.webkitAudioContext)) {
      const AudioContextClass = window.AudioContext || window.webkitAudioContext;
      this.ctx = new AudioContextClass();
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
    return this.ctx;
  }

  playBuzzer() {
    try {
      const ctx = this.getAudioContext();
      if (!ctx) return;
      const now = ctx.currentTime;
      const osc1 = ctx.createOscillator();
      const gain1 = ctx.createGain();
      osc1.type = 'sine';
      osc1.frequency.setValueAtTime(587.33, now);
      gain1.gain.setValueAtTime(0.2, now);
      gain1.gain.exponentialRampToValueAtTime(0.01, now + 0.3);
      osc1.connect(gain1);
      gain1.connect(ctx.destination);
      osc1.start(now);
      osc1.stop(now + 0.3);

      const osc2 = ctx.createOscillator();
      const gain2 = ctx.createGain();
      osc2.type = 'sine';
      osc2.frequency.setValueAtTime(880, now + 0.25);
      gain2.gain.setValueAtTime(0.2, now + 0.25);
      gain2.gain.exponentialRampToValueAtTime(0.001, now + 0.7);
      osc2.connect(gain2);
      gain2.connect(ctx.destination);
      osc2.start(now + 0.25);
      osc2.stop(now + 0.7);
    } catch (e) {}
  }

  playSuccess() {
    try {
      const ctx = this.getAudioContext();
      if (!ctx) return;
      const now = ctx.currentTime;
      [523.25, 659.25, 783.99].forEach((freq, i) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, now + i * 0.1);
        gain.gain.setValueAtTime(0.15, now + i * 0.1);
        gain.gain.exponentialRampToValueAtTime(0.001, now + i * 0.1 + 0.3);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(now + i * 0.1);
        osc.stop(now + i * 0.1 + 0.3);
      });
    } catch (e) {}
  }
}

window.AppAudio = new SoundSynthesizer();

class AppController {
  constructor() {
    this.currentView = 'gateway'; // 'gateway', 'farmer-welcome', 'farmer-lang', 'farmer-mobile', 'farmer-otp', 'farmer-profile', 'center-login', 'district-login', 'farmer', 'center', 'district'
    this.tempMobile = '9876543210';
    this.tempLang = 'en';
    this.profileSubStep = 'personal'; // 'personal', 'residence', 'land'
  }

  init() {
    try {
      const state = (window.KisanStore && typeof window.KisanStore.getState === 'function')
        ? window.KisanStore.getState()
        : { auth: { isLoggedIn: false } };

      if (state.auth && state.auth.isLoggedIn && state.auth.currentRole) {
        this.currentView = state.auth.currentRole;
      } else {
        this.currentView = 'gateway';
      }

      if (window.FarmerPortal && typeof window.FarmerPortal.init === 'function') {
        try { window.FarmerPortal.init(); } catch (e) { console.warn('FarmerPortal init:', e); }
      }
      if (window.CenterDesk && typeof window.CenterDesk.init === 'function') {
        try { window.CenterDesk.init(); } catch (e) { console.warn('CenterDesk init:', e); }
      }
      if (window.DistrictCommand && typeof window.DistrictCommand.init === 'function') {
        try { window.DistrictCommand.init(); } catch (e) { console.warn('DistrictCommand init:', e); }
      }

      this.render();

      if (window.KisanStore && typeof window.KisanStore.subscribe === 'function') {
        window.KisanStore.subscribe(() => {
          this.render();
        });
      }
    } catch (err) {
      console.error('AppController init error:', err);
      try { this.render(); } catch (e) {}
    }
  }

  setLanguage(lang) {
    this.tempLang = lang;
    window.KisanStore.setLanguage(lang);
    this.render();
  }

  setView(viewName) {
    this.currentView = viewName;
    this.render();
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  logout() {
    window.KisanStore.logout();
    this.currentView = 'gateway';
    this.render();
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  loginAs(role) {
    window.KisanStore.login(role, { role });
    this.currentView = role;
    if (window.AppAudio) window.AppAudio.playSuccess();
    this.render();
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  switchDashboard(role) {
    this.loginAs(role);
  }

  // --- Farmer Onboarding Flow Handlers (Images 1-5) ---

  handleRequestOtp(mobileNumber) {
    this.tempMobile = mobileNumber || '9876543210';
    if (window.AppAudio) window.AppAudio.playSuccess();
    this.setView('farmer-otp');
  }

  handleVerifyOtp(otp) {
    if (window.AppAudio) window.AppAudio.playSuccess();
    this.setView('farmer-profile');
  }

  setProfileSubStep(step) {
    this.profileSubStep = step;
    this.render();
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  handleFinishProfile(name, idType, idNum) {
    const state = window.KisanStore.getState();
    state.farmer.name = name || document.getElementById('input-farmer-name')?.value || 'Ramesh Patel';
    state.farmer.aadhaar = idNum || document.getElementById('input-farmer-id-num')?.value || 'XXXX-XXXX-4821';
    state.farmer.govIdType = idType || document.getElementById('select-gov-id')?.value || 'Aadhaar Card';

    // Save Residence if present
    if (document.getElementById('input-res-state')) {
      state.farmer.residence = {
        state: document.getElementById('input-res-state')?.value || 'Madhya Pradesh',
        district: document.getElementById('input-res-district')?.value || 'Indore',
        tehsil: document.getElementById('input-res-tehsil')?.value || 'Sanwer',
        village: document.getElementById('input-res-village')?.value || 'Sanwer Khurd',
        houseAddress: document.getElementById('input-res-address')?.value || 'House No. 42, Ward 3, Near Gram Panchayat Bhavan',
        pincode: document.getElementById('input-res-pincode')?.value || '453551',
        residenceType: document.getElementById('select-res-type')?.value || 'Permanent Resident (पैतृक निवासी)'
      };
    }

    // Save Land Credentials if present
    if (document.getElementById('input-land-acres')) {
      const acres = parseFloat(document.getElementById('input-land-acres')?.value) || 6.5;
      state.farmer.land = {
        totalAcres: acres,
        bighaEquivalent: `${(acres * 2.5).toFixed(2)} Bigha`,
        cultivableAcres: parseFloat(document.getElementById('input-land-cultivable')?.value) || 6.0,
        irrigatedAcres: parseFloat(document.getElementById('input-land-irrigated')?.value) || 5.0,
        unirrigatedAcres: 1.5,
        ownershipType: document.getElementById('select-land-ownership')?.value || 'Owner Cultivator (स्वयं मालिक)',
        khasraNo: document.getElementById('input-land-khasra')?.value || '142/3, 145/1',
        khatauniNo: document.getElementById('input-land-khatauni')?.value || 'KH-00942',
        credentialDocType: document.getElementById('select-land-doc')?.value || '7/12 Extract & Khasra-Khatauni (भू-अभिलेख)',
        pmKisanId: document.getElementById('input-land-pmkisan')?.value || 'MP-IND-2023-99824',
        soilType: document.getElementById('select-land-soil')?.value || 'Black Cotton Soil (काली मिट्टी)',
        waterSource: document.getElementById('select-land-water')?.value || 'Tube-well & Canal (नहर व नलकूप)'
      };
    }

    window.KisanStore.saveState();
    this.loginAs('farmer');
  }

  // --- Main View Renderer ---

  render() {
    const state = window.KisanStore.getState();
    const isLogged = state.auth && state.auth.isLoggedIn;
    const t = window.t;

    const langSelect = document.getElementById('global-language-select');
    if (langSelect) langSelect.value = state.currentLanguage || 'en';

    const stateSelect = document.getElementById('global-state-select');
    if (stateSelect) stateSelect.value = state.selectedState || 'Maharashtra';

    const districtSelect = document.getElementById('global-district-select');
    if (districtSelect && window.KisanStore) {
      const curState = state.selectedState || 'Maharashtra';
      const districts = window.KisanStore.getDistrictsForState(curState);
      const curDist = state.selectedDistrict || 'All Districts';
      districtSelect.innerHTML = `
        <option value="All Districts" class="text-slate-900" ${curDist === 'All Districts' || curDist === 'All' ? 'selected' : ''}>All Districts (${districts.length})</option>
        ${districts.map(d => {
          const cleanD = d.replace(/\s*\(.*?\)\s*/g, '');
          return `<option value="${d}" class="text-slate-900" ${curDist === d ? 'selected' : ''}>${cleanD}</option>`;
        }).join('')}
      `;
    }

    const brandTitleEl = document.getElementById('app-brand-title');
    if (brandTitleEl) brandTitleEl.textContent = t('appBrandTitle');

    const sloganEl = document.getElementById('app-slogan-text');
    if (sloganEl) sloganEl.textContent = t('appSlogan');

    const resetBtnText = document.getElementById('btn-reset-text');
    if (resetBtnText) resetBtnText.textContent = t('demoResetBtn');

    const canvasToggleText = document.getElementById('canvas-toggle-text');
    if (canvasToggleText) canvasToggleText.textContent = state.mobileCanvasMode ? 'Desktop View' : 'Mobile View';

    document.body.classList.toggle('mobile-canvas-active', !!state.mobileCanvasMode);
    const mainContainer = document.getElementById('main-app-container');
    if (mainContainer) mainContainer.classList.toggle('mobile-canvas-frame', !!state.mobileCanvasMode);

    const appTaglineEl = document.getElementById('app-tagline-text');
    if (appTaglineEl) appTaglineEl.textContent = t('appTagline');

    const switchBtn = document.getElementById('btn-switch-role');
    if (switchBtn) switchBtn.textContent = t('switchPortal');

    const navFarmer = document.getElementById('nav-btn-farmer');
    if (navFarmer) navFarmer.textContent = t('farmerRoleTitle');

    const navCenter = document.getElementById('nav-btn-center');
    if (navCenter) navCenter.textContent = t('centerRoleTitle');

    const navDistrict = document.getElementById('nav-btn-district');
    if (navDistrict) navDistrict.textContent = t('districtRoleTitle');

    const authHeaderActions = document.getElementById('auth-header-actions');
    const loginSection = document.getElementById('section-gateway-login');
    const farmerSection = document.getElementById('section-farmer-portal');
    const centerSection = document.getElementById('section-center-desk');
    const districtSection = document.getElementById('section-district-command');

    if (isLogged && (this.currentView === 'farmer' || this.currentView === 'center' || this.currentView === 'district')) {
      // Dashboard View
      if (authHeaderActions) authHeaderActions.classList.remove('hidden');
      if (loginSection) loginSection.classList.add('hidden');

      if (farmerSection) farmerSection.classList.toggle('hidden', this.currentView !== 'farmer');
      if (centerSection) centerSection.classList.toggle('hidden', this.currentView !== 'center');
      if (districtSection) districtSection.classList.toggle('hidden', this.currentView !== 'district');

      document.querySelectorAll('.dashboard-nav-btn').forEach(btn => {
        const v = btn.getAttribute('data-view');
        if (v === this.currentView) {
          btn.classList.add('bg-slate-900', 'text-white');
          btn.classList.remove('bg-white', 'text-slate-700');
        } else {
          btn.classList.remove('bg-slate-900', 'text-white');
          btn.classList.add('bg-white', 'text-slate-700');
        }
      });

      if (this.currentView === 'farmer' && window.FarmerPortal) window.FarmerPortal.render();
      if (this.currentView === 'center' && window.CenterDesk) window.CenterDesk.render();
      if (this.currentView === 'district' && window.DistrictCommand) window.DistrictCommand.render();
    } else {
      // Login or Gateway View
      if (authHeaderActions) authHeaderActions.classList.add('hidden');
      if (farmerSection) farmerSection.classList.add('hidden');
      if (centerSection) centerSection.classList.add('hidden');
      if (districtSection) districtSection.classList.add('hidden');

      if (loginSection) {
        loginSection.classList.remove('hidden');
        loginSection.innerHTML = this.renderAuthViews(t, state);
      }
    }

    try {
      if (window.lucide && typeof window.lucide.createIcons === 'function') {
        window.lucide.createIcons();
      }
    } catch (e) {
      console.warn('Lucide icons error:', e);
    }
  }

  renderAuthViews(t, state) {
    switch (this.currentView) {
      case 'farmer-welcome':
        return this.renderFarmerWelcome(t);
      case 'farmer-lang':
        return this.renderFarmerLang(t, state);
      case 'farmer-mobile':
        return this.renderFarmerMobile(t);
      case 'farmer-otp':
        return this.renderFarmerOtp(t);
      case 'farmer-profile':
        return this.renderFarmerProfile(t);
      case 'center-login':
        return this.renderCenterLogin(t);
      case 'district-login':
        return this.renderDistrictLogin(t);
      case 'gateway':
      default:
        return this.renderGatewayCards(t);
    }
  }

  // --- GATEWAY CARD SELECTOR ---
  renderGatewayCards(t) {
    const state = window.KisanStore ? window.KisanStore.getState() : {};
    const selectedState = state.selectedState || 'All India';

    return `
      <div class="space-y-8 py-4 max-w-5xl mx-auto">
        <!-- Hero Card with Lush Farm Background & Golden Wheat Emblem (Reference Image Match) -->
        <div class="farm-hero-card">
          <div class="gold-wheat-medallion">
            🌾
          </div>
          <h1 class="text-3xl sm:text-5xl font-black text-white tracking-tight drop-shadow-md">
            ${t('KISANSETU')}
          </h1>
          <p class="text-base sm:text-xl text-yellow-200 font-bold mt-2 max-w-xl drop-shadow">
            ${t('appSlogan')}
          </p>
          <div class="flex items-center gap-2 mt-4 flex-wrap justify-center">
            <span class="px-3 py-1 rounded-full text-xs font-black bg-emerald-950/80 text-yellow-300 border border-yellow-400/40 shadow-inner">
              🇮🇳 Pan-India APMC Network • 17 States • 26+ Mandis
            </span>
            <span class="px-3 py-1 rounded-full text-xs font-bold bg-white/20 text-white backdrop-blur-sm border border-white/20">
              Active Region: ${selectedState}
            </span>
          </div>
          <div class="mt-6 flex items-center gap-3 flex-wrap justify-center">
            <button onclick="App.openGlobalHeatmap()" class="px-5 py-2.5 bg-yellow-400 hover:bg-yellow-300 text-emerald-950 font-black rounded-2xl text-sm shadow-lg transition flex items-center gap-2 cursor-pointer">
              <span>🗺️</span>
              <span>${t('heatmapTitle')}</span>
            </button>
            <button onclick="App.setView('farmer-welcome')" class="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-2xl text-sm shadow-lg transition border border-emerald-400/50 flex items-center gap-2 cursor-pointer">
              <span>🌾</span>
              <span>${t('farmerRoleBtn')}</span>
            </button>
          </div>
        </div>

        <div class="text-center space-y-2 pt-2">
          <h2 class="text-2xl sm:text-3xl font-black text-slate-900">
            ${t('gatewayTitle')}
          </h2>
          <p class="text-xs sm:text-sm text-slate-600 max-w-xl mx-auto">
            ${t('gatewaySubtitle')}
          </p>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
          <!-- FARMER -->
          <div class="bg-white p-6 sm:p-8 rounded-3xl border-2 border-slate-200 hover:border-emerald-500 shadow-sm transition flex flex-col justify-between space-y-6">
            <div class="space-y-4">
              <div class="w-16 h-16 rounded-2xl bg-emerald-100 text-emerald-700 text-3xl flex items-center justify-center">
                🌾
              </div>
              <div>
                <h3 class="text-xl font-black text-slate-900">${t('farmerRoleTitle')}</h3>
                <p class="text-xs sm:text-sm text-slate-600 mt-2 leading-relaxed">
                  ${t('farmerRoleDesc')}
                </p>
              </div>
            </div>

            <button onclick="App.setView('farmer-welcome')" class="btn-large w-full bg-emerald-600 hover:bg-emerald-700 text-white shadow-md text-base">
              ${t('farmerRoleBtn')}
            </button>
          </div>

          <!-- CENTER OFFICIAL -->
          <div class="bg-white p-6 sm:p-8 rounded-3xl border-2 border-slate-200 hover:border-blue-500 shadow-sm transition flex flex-col justify-between space-y-6">
            <div class="space-y-4">
              <div class="w-16 h-16 rounded-2xl bg-blue-100 text-blue-700 text-3xl flex items-center justify-center">
                🏢
              </div>
              <div>
                <h3 class="text-xl font-black text-slate-900">${t('centerRoleTitle')}</h3>
                <p class="text-xs sm:text-sm text-slate-600 mt-2 leading-relaxed">
                  ${t('centerRoleDesc')}
                </p>
              </div>
            </div>

            <button onclick="App.setView('center-login')" class="btn-large w-full bg-blue-600 hover:bg-blue-700 text-white shadow-md text-base">
              ${t('centerRoleBtn')}
            </button>
          </div>

          <!-- DISTRICT OFFICER -->
          <div class="bg-white p-6 sm:p-8 rounded-3xl border-2 border-slate-200 hover:border-slate-800 shadow-sm transition flex flex-col justify-between space-y-6">
            <div class="space-y-4">
              <div class="w-16 h-16 rounded-2xl bg-slate-100 text-slate-700 text-3xl flex items-center justify-center">
                🏛️
              </div>
              <div>
                <h3 class="text-xl font-black text-slate-900">${t('districtRoleTitle')}</h3>
                <p class="text-xs sm:text-sm text-slate-600 mt-2 leading-relaxed">
                  ${t('districtRoleDesc')}
                </p>
              </div>
            </div>

            <button onclick="App.setView('district-login')" class="btn-large w-full bg-slate-900 hover:bg-slate-800 text-white shadow-md text-base">
              ${t('districtRoleBtn')}
            </button>
          </div>
        </div>
      </div>
    `;
  }

  // --- SCREEN 1: FARMER WELCOME (Exact Image 1) ---
  renderFarmerWelcome(t) {
    return `
      <div class="onboarding-card space-y-6 text-center">
        <!-- Top Back button to Gateway -->
        <div class="flex justify-start">
          <button onclick="App.setView('gateway')" class="btn-back-circle">
            <i data-lucide="arrow-left" class="w-4 h-4">←</i>
          </button>
        </div>

        <div class="w-16 h-16 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center text-3xl mx-auto">
          🌱
        </div>

        <div>
          <h2 class="text-2xl sm:text-3xl font-black text-slate-900">KisanSetu</h2>
          <p class="text-xs sm:text-sm font-extrabold text-emerald-700 mt-1">${t('welcomeTagline')}</p>
          <p class="text-xs text-slate-500 mt-2">${t('welcomeSubtitle')}</p>
        </div>

        <!-- 3 Feature Bullets (Matching Image 1) -->
        <div class="space-y-4 text-left pt-2">
          <div class="flex items-start gap-3">
            <div class="w-6 h-6 rounded-full bg-amber-100 text-amber-600 flex items-center justify-center flex-shrink-0 text-xs mt-0.5">
              ✓
            </div>
            <div>
              <h4 class="text-xs font-bold text-slate-900">${t('bullet1Title')}</h4>
              <p class="text-[11px] text-slate-500 mt-0.5">${t('bullet1Desc')}</p>
            </div>
          </div>

          <div class="flex items-start gap-3">
            <div class="w-6 h-6 rounded-full bg-amber-100 text-amber-600 flex items-center justify-center flex-shrink-0 text-xs mt-0.5">
              ✓
            </div>
            <div>
              <h4 class="text-xs font-bold text-slate-900">${t('bullet2Title')}</h4>
              <p class="text-[11px] text-slate-500 mt-0.5">${t('bullet2Desc')}</p>
            </div>
          </div>

          <div class="flex items-start gap-3">
            <div class="w-6 h-6 rounded-full bg-amber-100 text-amber-600 flex items-center justify-center flex-shrink-0 text-xs mt-0.5">
              ✓
            </div>
            <div>
              <h4 class="text-xs font-bold text-slate-900">${t('bullet3Title')}</h4>
              <p class="text-[11px] text-slate-500 mt-0.5">${t('bullet3Desc')}</p>
            </div>
          </div>
        </div>

        <button onclick="App.setView('farmer-lang')" class="btn-large w-full bg-emerald-600 hover:bg-emerald-700 text-white shadow-lg shadow-emerald-600/20 text-base">
          ${t('getStarted')}
        </button>

        <p class="text-[10px] text-slate-400 max-w-xs mx-auto leading-normal">
          ${t('bottomEmpower')}
        </p>
      </div>
    `;
  }

  // --- SCREEN 2: SELECT LANGUAGE (Exact Image 2) ---
  renderFarmerLang(t, state) {
    const current = state.currentLanguage || 'en';
    const langList = [
      { id: 'en', name: 'English', native: 'English' },
      { id: 'hi', name: 'Hindi', native: 'हिंदी' },
      { id: 'mr', name: 'Marathi', native: 'मराठी' },
      { id: 'pa', name: 'Punjabi', native: 'ਪੰਜਾਬੀ' },
      { id: 'gu', name: 'Gujarati', native: 'ગુજરાતી' },
      { id: 'bn', name: 'Bengali', native: 'বাংলা' },
      { id: 'ta', name: 'Tamil', native: 'தமிழ்' }
    ];

    return `
      <div class="onboarding-card space-y-6">
        <div class="flex items-center justify-between">
          <button onclick="App.setView('farmer-welcome')" class="btn-back-circle">
            <i data-lucide="arrow-left" class="w-4 h-4">←</i>
          </button>
          <span class="text-xs text-slate-400 font-bold">Step 1 of 3</span>
        </div>

        <div class="text-center space-y-1">
          <div class="w-12 h-12 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center text-xl mx-auto mb-2">
            🌐
          </div>
          <h3 class="text-xl font-black text-slate-900">${t('selectLanguageTitle')}</h3>
          <p class="text-xs text-slate-500">${t('selectLanguageSubtitle')}</p>
        </div>

        <!-- Language Radio Cards (Matching Image 2) -->
        <div class="space-y-2.5 max-h-80 overflow-y-auto pr-1">
          ${langList.map(l => `
            <div onclick="App.setLanguage('${l.id}')" class="lang-radio-card ${current === l.id ? 'active' : ''}">
              <div class="flex items-center gap-3">
                <span class="text-slate-400 text-base">🌐</span>
                <div>
                  <div class="font-extrabold text-xs text-slate-900">${l.name}</div>
                  <div class="text-[11px] text-slate-500 font-medium">${l.native}</div>
                </div>
              </div>
              <div class="w-5 h-5 rounded-full border-2 flex items-center justify-center ${current === l.id ? 'border-emerald-600 bg-emerald-600 text-white' : 'border-slate-300'}">
                ${current === l.id ? '<span class="text-[10px] font-bold">✓</span>' : ''}
              </div>
            </div>
          `).join('')}
        </div>

        <button onclick="App.setView('farmer-mobile')" class="btn-large w-full bg-emerald-600 hover:bg-emerald-700 text-white shadow-md text-base">
          ${t('continue')}
        </button>
      </div>
    `;
  }

  // --- SCREEN 3: MOBILE LOGIN / REGISTER (Exact Image 3) ---
  renderFarmerMobile(t) {
    return `
      <div class="onboarding-card space-y-6">
        <div class="flex items-center justify-between">
          <button onclick="App.setView('farmer-lang')" class="btn-back-circle">
            <i data-lucide="arrow-left" class="w-4 h-4">←</i>
          </button>
          <span class="text-xs text-slate-400 font-bold">Step 2 of 3</span>
        </div>

        <div class="text-center space-y-1">
          <div class="w-12 h-12 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center text-xl mx-auto mb-1">
            🌱
          </div>
          <h3 class="text-xl font-black text-slate-900">KisanSetu</h3>
          <p class="text-xs font-bold text-emerald-700">${t('welcomeTagline')}</p>
          <p class="text-[11px] text-slate-500">Smart procurement platform for farmers. Less waiting, more transparency.</p>
        </div>

        <!-- Mobile Number Input (Matching Image 3) -->
        <div class="space-y-1.5 pt-2">
          <label class="block text-xs font-bold text-slate-700">${t('mobileNumberLabel')}</label>
          <div class="flex items-center border-2 border-slate-200 rounded-2xl px-3 py-2.5 focus-within:border-emerald-600 transition bg-slate-50">
            <span class="text-xs font-bold text-slate-500 mr-2 border-r border-slate-300 pr-2">+91</span>
            <input type="tel" id="input-farmer-mobile" value="${this.tempMobile}" placeholder="${t('mobileNumberPlaceholder')}" class="w-full bg-transparent text-sm font-bold text-slate-900 focus:outline-none font-mono">
          </div>
          <p class="text-[10px] text-slate-400">${t('mobileHelpText')}</p>
        </div>

        <button onclick="App.handleRequestOtp(document.getElementById('input-farmer-mobile').value)" class="btn-large w-full bg-emerald-600 hover:bg-emerald-700 text-white shadow-md text-base">
          ${t('requestOtp')}
        </button>

        <div class="relative text-center my-2">
          <div class="border-t border-slate-200"></div>
          <span class="bg-white px-2 text-[10px] text-slate-400 font-bold uppercase relative -top-2">OR</span>
        </div>

        <button onclick="App.loginAs('farmer')" class="btn-large w-full bg-slate-100 hover:bg-slate-200 text-slate-800 text-sm">
          <span>⚡ One-Click Demo Login (Ramesh Patel)</span>
        </button>

        <p class="text-[10px] text-slate-400 text-center">${t('smsNotice')}</p>
      </div>
    `;
  }

  // --- SCREEN 4: OTP VERIFICATION (Exact Image 4) ---
  renderFarmerOtp(t) {
    return `
      <div class="onboarding-card space-y-6 text-center">
        <div class="flex items-center justify-between text-left">
          <button onclick="App.setView('farmer-mobile')" class="btn-back-circle">
            <i data-lucide="arrow-left" class="w-4 h-4">←</i>
          </button>
          <span class="text-xs text-slate-400 font-bold">Step 3 of 3</span>
        </div>

        <div class="w-14 h-14 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center text-2xl mx-auto">
          🔒
        </div>

        <div>
          <h3 class="text-xl font-black text-slate-900">${t('verifyOtpTitle')}</h3>
          <p class="text-xs text-slate-500 mt-1">${t('otpSentMsg')} <strong class="text-slate-800">+91 ${this.tempMobile}</strong></p>
        </div>

        <!-- OTP Field (Matching Image 4) -->
        <div class="space-y-1 text-left">
          <label class="block text-xs font-bold text-slate-700">${t('enterOtpLabel')}</label>
          <input type="text" id="input-otp-code" value="123456" maxlength="6" class="otp-input-field" placeholder="000000">
          <p class="text-[10px] text-slate-400 text-center">6/6 digits entered</p>
        </div>

        <button onclick="App.handleVerifyOtp(document.getElementById('input-otp-code').value)" class="btn-large w-full bg-emerald-600 hover:bg-emerald-700 text-white shadow-md text-base">
          ${t('verifyOtpBtn')}
        </button>

        <div class="text-xs text-slate-500">
          <span>${t('didntReceiveCode')} </span>
          <button onclick="alert('OTP re-sent: 123456')" class="font-bold text-amber-600 hover:underline">${t('resendOtp')}</button>
        </div>

        <!-- Demo Mode Box (Matching Image 4) -->
        <div class="p-3 bg-slate-50 rounded-xl border border-slate-200 text-[11px] text-slate-500 text-center font-medium">
          ${t('demoOtpNotice')}
        </div>
      </div>
    `;
  }

  // --- SCREEN 5: DETAILED FARMER PROFILE SETUP (Personal 1/3 -> Residence 2/3 -> Land Credentials 3/3) ---
  renderFarmerProfile(t) {
    const sub = this.profileSubStep || 'personal';

    let stepContent = '';
    if (sub === 'personal') {
      stepContent = `
        <div class="space-y-4 pt-1">
          <!-- Full Name -->
          <div>
            <label class="block text-xs font-bold text-slate-700 mb-1">${t('fullName')}</label>
            <input type="text" id="input-farmer-name" value="Ramesh Patel" placeholder="${t('fullNamePlaceholder')}" class="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-bold text-slate-900 focus:outline-none focus:border-emerald-600">
          </div>

          <!-- Gov ID Type -->
          <div>
            <label class="block text-xs font-bold text-slate-700 mb-1">${t('govIdType')}</label>
            <select id="select-gov-id" class="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-bold text-slate-900 focus:outline-none focus:border-emerald-600">
              <option value="Aadhaar Card" selected>Aadhaar Card (आधार कार्ड)</option>
              <option value="Kisan Credit Card">Kisan Credit Card (KCC)</option>
              <option value="Voter ID">Voter ID Card</option>
              <option value="PAN Card">PAN Card (आयकर पैन)</option>
            </select>
          </div>

          <!-- ID Number -->
          <div>
            <label class="block text-xs font-bold text-slate-700 mb-1">${t('govIdNumber')}</label>
            <input type="text" id="input-farmer-id-num" value="XXXX-XXXX-4821" placeholder="${t('govIdPlaceholder')}" class="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-bold text-slate-900 font-mono focus:outline-none focus:border-emerald-600">
          </div>

          <!-- Preferred Language -->
          <div>
            <label class="block text-xs font-bold text-slate-700 mb-1">${t('prefLanguage')}</label>
            <select onchange="App.setLanguage(this.value)" class="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-bold text-slate-900 focus:outline-none focus:border-emerald-600">
              <option value="en">English</option>
              <option value="hi" class="font-hindi">हिंदी (Hindi)</option>
              <option value="mr" class="font-hindi">मराठी (Marathi)</option>
              <option value="pa" class="font-punjabi">ਪੰਜਾਬੀ (Punjabi)</option>
              <option value="gu" class="font-gujarati">ગુજરાતી (Gujarati)</option>
              <option value="bn" class="font-bengali">বাংলা (Bengali)</option>
              <option value="ta" class="font-tamil">தமிழ் (Tamil)</option>
            </select>
          </div>

          <div class="pt-2 space-y-2">
            <button type="button" onclick="App.setProfileSubStep('residence')" class="btn-large w-full bg-emerald-600 hover:bg-emerald-700 text-white shadow-md text-base">
              ${t('btnNextResidence')}
            </button>
            <button type="button" onclick="App.handleFinishProfile()" class="btn-large w-full bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold">
              ⚡ Save & Quick Enter Dashboard
            </button>
          </div>
        </div>
      `;
    } else if (sub === 'residence') {
      stepContent = `
        <div class="space-y-4 pt-1">
          <div class="p-3 bg-blue-50 border border-blue-200 rounded-xl text-xs text-blue-900 font-medium">
            📍 ${t('residenceSubtitle')}
          </div>

          <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label class="block text-xs font-bold text-slate-700 mb-1">${t('stateLabel')}</label>
              <select id="input-res-state" class="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-900 focus:outline-none focus:border-emerald-600">
                <option value="Madhya Pradesh" selected>Madhya Pradesh (मध्य प्रदेश)</option>
                <option value="Maharashtra">Maharashtra (महाराष्ट्र)</option>
                <option value="Punjab">Punjab (ਪੰਜਾਬ)</option>
                <option value="Gujarat">Gujarat (ગુજરાત)</option>
                <option value="West Bengal">West Bengal (পশ্চিমবঙ্গ)</option>
                <option value="Tamil Nadu">Tamil Nadu (தமிழ்நாடு)</option>
                <option value="Rajasthan">Rajasthan (राजस्थान)</option>
                <option value="Uttar Pradesh">Uttar Pradesh (उत्तर प्रदेश)</option>
                <option value="Haryana">Haryana (हरियाणा)</option>
              </select>
            </div>

            <div>
              <label class="block text-xs font-bold text-slate-700 mb-1">${t('districtLabel')}</label>
              <input type="text" id="input-res-district" value="Indore" placeholder="e.g. Indore" class="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-bold text-slate-900 focus:outline-none focus:border-emerald-600">
            </div>
          </div>

          <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label class="block text-xs font-bold text-slate-700 mb-1">${t('tehsilLabel')}</label>
              <input type="text" id="input-res-tehsil" value="Sanwer" placeholder="${t('tehsilPlaceholder')}" class="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-bold text-slate-900 focus:outline-none focus:border-emerald-600">
            </div>

            <div>
              <label class="block text-xs font-bold text-slate-700 mb-1">${t('villageLabel')}</label>
              <input type="text" id="input-res-village" value="Sanwer Khurd" placeholder="${t('villagePlaceholder')}" class="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-bold text-slate-900 focus:outline-none focus:border-emerald-600">
            </div>
          </div>

          <div>
            <label class="block text-xs font-bold text-slate-700 mb-1">${t('houseAddressLabel')}</label>
            <input type="text" id="input-res-address" value="House No. 42, Ward 3, Near Gram Panchayat Bhavan" placeholder="${t('houseAddressPlaceholder')}" class="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-bold text-slate-900 focus:outline-none focus:border-emerald-600">
          </div>

          <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label class="block text-xs font-bold text-slate-700 mb-1">${t('pincodeLabel')}</label>
              <input type="text" id="input-res-pincode" value="453551" placeholder="${t('pincodePlaceholder')}" class="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-mono font-bold text-slate-900 focus:outline-none focus:border-emerald-600">
            </div>

            <div>
              <label class="block text-xs font-bold text-slate-700 mb-1">${t('residenceTypeLabel')}</label>
              <select id="select-res-type" class="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-900 focus:outline-none focus:border-emerald-600">
                <option value="Permanent Resident (पैतृक निवासी)" selected>${t('resTypePermanent')}</option>
                <option value="Farm House / Dhani / Khet (खेत पर आवास)">${t('resTypeFarm')}</option>
                <option value="Tenant / Rented (किराएदार / अस्थायी)">${t('resTypeTenant')}</option>
              </select>
            </div>
          </div>

          <div class="flex items-center gap-3 pt-2">
            <button type="button" onclick="App.setProfileSubStep('personal')" class="flex-1 py-3 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl transition">
              ${t('btnBackPersonal')}
            </button>
            <button type="button" onclick="App.setProfileSubStep('land')" class="flex-1 py-3 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl shadow-md transition">
              ${t('btnNextLand')}
            </button>
          </div>
        </div>
      `;
    } else if (sub === 'land') {
      stepContent = `
        <div class="space-y-4 pt-1">
          <div class="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-xs text-emerald-900 font-medium">
            🌾 ${t('landCredentialsSubtitle')}
          </div>

          <!-- Total Land with live conversion -->
          <div>
            <div class="flex justify-between items-center mb-1">
              <label class="block text-xs font-bold text-slate-700">${t('totalLandLabel')}</label>
              <span id="bigha-hint" class="text-[11px] font-bold text-emerald-700">${t('bighaConversionHint')}</span>
            </div>
            <div class="flex items-center border border-slate-200 rounded-xl bg-slate-50 px-3 py-2.5 focus-within:border-emerald-600">
              <input type="number" step="0.5" id="input-land-acres" value="6.5" oninput="document.getElementById('bigha-hint').textContent = 'Approx. ' + ((parseFloat(this.value)||0)*2.5).toFixed(2) + ' Bigha'" class="w-full bg-transparent font-mono font-bold text-sm text-slate-900 focus:outline-none">
              <span class="text-xs font-bold text-slate-500 ml-2">Acres</span>
            </div>
          </div>

          <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label class="block text-xs font-bold text-slate-700 mb-1">${t('cultivableAcresLabel')}</label>
              <input type="number" step="0.5" id="input-land-cultivable" value="6.0" class="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold font-mono text-slate-900 focus:outline-none focus:border-emerald-600">
            </div>

            <div>
              <label class="block text-xs font-bold text-slate-700 mb-1">${t('irrigatedAcresLabel')}</label>
              <input type="number" step="0.5" id="input-land-irrigated" value="5.0" class="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold font-mono text-slate-900 focus:outline-none focus:border-emerald-600">
            </div>
          </div>

          <div>
            <label class="block text-xs font-bold text-slate-700 mb-1">${t('ownershipStatusLabel')}</label>
            <select id="select-land-ownership" class="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-900 focus:outline-none focus:border-emerald-600">
              <option value="Owner Cultivator (स्वयं मालिक)" selected>${t('ownerCultivator')}</option>
              <option value="Joint Family Ownership">${t('jointOwnership')}</option>
              <option value="Leased / Tenant Farmer">${t('leasedTenant')}</option>
              <option value="Sharecropper (Batai)">${t('sharecropper')}</option>
            </select>
          </div>

          <!-- Khasra & Khatauni credentials -->
          <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label class="block text-xs font-bold text-slate-700 mb-1">${t('khasraNumberLabel')}</label>
              <input type="text" id="input-land-khasra" value="142/3, 145/1" placeholder="${t('khasraPlaceholder')}" class="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-mono font-bold text-slate-900 focus:outline-none focus:border-emerald-600">
            </div>

            <div>
              <label class="block text-xs font-bold text-slate-700 mb-1">${t('khatauniNumberLabel')}</label>
              <input type="text" id="input-land-khatauni" value="KH-00942" placeholder="${t('khatauniPlaceholder')}" class="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-mono font-bold text-slate-900 focus:outline-none focus:border-emerald-600">
            </div>
          </div>

          <!-- Land Verification Doc -->
          <div>
            <label class="block text-xs font-bold text-slate-700 mb-1">${t('landDocTypeLabel')}</label>
            <select id="select-land-doc" class="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-900 focus:outline-none focus:border-emerald-600">
              <option value="7/12 Extract & Khasra-Khatauni (भू-अभिलेख)" selected>${t('doc712')}</option>
              <option value="Patta / Land Title Passbook">${t('docPatta')}</option>
              <option value="Record of Rights (RoR)">${t('docRoR')}</option>
              <option value="KCC Land Record">${t('docKisanCredit')}</option>
            </select>
          </div>

          <!-- PM-Kisan & Soil Details -->
          <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label class="block text-xs font-bold text-slate-700 mb-1">${t('pmKisanIdLabel')}</label>
              <input type="text" id="input-land-pmkisan" value="MP-IND-2023-99824" placeholder="${t('pmKisanPlaceholder')}" class="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs font-mono font-bold text-slate-900 focus:outline-none focus:border-emerald-600">
            </div>

            <div>
              <label class="block text-xs font-bold text-slate-700 mb-1">${t('soilTypeLabel')}</label>
              <select id="select-land-soil" class="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-900 focus:outline-none focus:border-emerald-600">
                <option value="Black Cotton Soil (काली मिट्टी)" selected>${t('soilBlack')}</option>
                <option value="Alluvial Loam (दोमट मिट्टी)">${t('soilAlluvial')}</option>
                <option value="Red / Sandy Loam (लाल / रेतीली)">${t('soilRed')}</option>
              </select>
            </div>
          </div>

          <div>
            <label class="block text-xs font-bold text-slate-700 mb-1">${t('waterSourceLabel')}</label>
            <select id="select-land-water" class="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-900 focus:outline-none focus:border-emerald-600">
              <option value="Tube-well & Canal (नहर व नलकूप)" selected>${t('waterTubeWell')}</option>
              <option value="Govt Canal Irrigation">${t('waterCanal')}</option>
              <option value="Rain-fed / Monsoon">${t('waterRain')}</option>
            </select>
          </div>

          <div class="flex items-center gap-3 pt-2">
            <button type="button" onclick="App.setProfileSubStep('residence')" class="flex-1 py-3 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl transition">
              ${t('btnBackResidence')}
            </button>
            <button type="button" onclick="App.handleFinishProfile()" class="flex-1 py-3 bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-black rounded-xl shadow-md transition">
              ✅ ${t('enterFarmerDashboard')}
            </button>
          </div>
        </div>
      `;
    }

    return `
      <div class="onboarding-card max-w-xl space-y-6">
        <div class="flex items-center justify-between border-b border-slate-100 pb-3">
          <button onclick="App.setView('farmer-otp')" class="btn-back-circle">
            <i data-lucide="arrow-left" class="w-4 h-4">←</i>
          </button>
          <span class="text-xs text-slate-400 font-bold">
            ${sub === 'personal' ? 'Step 1 of 3: Personal' : sub === 'residence' ? 'Step 2 of 3: Residence' : 'Step 3 of 3: Land Holding'}
          </span>
        </div>

        <!-- 3-SubStep Stepper Navigation Pills -->
        <div class="grid grid-cols-3 gap-2">
          <button onclick="App.setProfileSubStep('personal')" class="p-2.5 rounded-xl border text-center transition ${sub === 'personal' ? 'bg-emerald-600 text-white border-emerald-600 shadow-sm font-black' : 'bg-slate-50 text-slate-600 border-slate-200 font-bold hover:bg-slate-100'}">
            <span class="text-xs block">👤 1. ${t('stepPersonalTab') || 'Personal'}</span>
          </button>

          <button onclick="App.setProfileSubStep('residence')" class="p-2.5 rounded-xl border text-center transition ${sub === 'residence' ? 'bg-emerald-600 text-white border-emerald-600 shadow-sm font-black' : 'bg-slate-50 text-slate-600 border-slate-200 font-bold hover:bg-slate-100'}">
            <span class="text-xs block">🏡 2. ${t('stepResidenceTab') || 'Residence'}</span>
          </button>

          <button onclick="App.setProfileSubStep('land')" class="p-2.5 rounded-xl border text-center transition ${sub === 'land' ? 'bg-emerald-600 text-white border-emerald-600 shadow-sm font-black' : 'bg-slate-50 text-slate-600 border-slate-200 font-bold hover:bg-slate-100'}">
            <span class="text-xs block">🌾 3. ${t('stepLandTab') || 'Land & Farm'}</span>
          </button>
        </div>

        ${stepContent}
      </div>
    `;
  }

  // --- DEDICATED MANDI CENTER OFFICIAL ADMIN LOGIN ---
  renderCenterLogin(t) {
    return `
      <div class="admin-card space-y-6">
        <div class="flex items-center justify-between">
          <button onclick="App.setView('gateway')" class="btn-back-circle">
            <i data-lucide="arrow-left" class="w-4 h-4">←</i>
          </button>
          <span class="text-xs px-2.5 py-1 bg-blue-100 text-blue-800 font-bold rounded-full">Official Gate Desk</span>
        </div>

        <div class="text-center space-y-1">
          <div class="w-14 h-14 rounded-2xl bg-blue-100 text-blue-700 text-2xl font-black flex items-center justify-center mx-auto mb-2">
            🏢
          </div>
          <h3 class="text-2xl font-black text-slate-900">${t('centerLoginTitle')}</h3>
          <p class="text-xs text-slate-500 max-w-sm mx-auto">${t('centerLoginDesc')}</p>
        </div>

        <!-- Official Login Form -->
        <form onsubmit="event.preventDefault(); App.loginAs('center')" class="space-y-4 pt-2">
          <div>
            <label class="block text-xs font-bold text-slate-700 mb-1">${t('centerCodeLabel')}</label>
            <select class="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-bold text-slate-900 focus:outline-none focus:border-blue-600">
              <option selected>MP-IND-004 • Indore Mandi (Laxmibai Nagar)</option>
              <option>MP-UJJ-002 • Ujjain Mandi (Agar Road)</option>
              <option>MP-DEW-001 • Dewas Mandi Hub</option>
              <option>MP-BHO-005 • Bhopal Mandi Central</option>
            </select>
          </div>

          <div>
            <label class="block text-xs font-bold text-slate-700 mb-1">${t('staffIdLabel')}</label>
            <input type="text" value="QC-VijaySharma" class="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-bold text-slate-900 font-mono focus:outline-none focus:border-blue-600">
          </div>

          <div>
            <label class="block text-xs font-bold text-slate-700 mb-1">${t('passwordLabel')}</label>
            <input type="password" value="secret123" class="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-bold text-slate-900 font-mono focus:outline-none focus:border-blue-600">
          </div>

          <div>
            <label class="block text-xs font-bold text-slate-700 mb-1">${t('terminalSelectLabel')}</label>
            <select class="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-bold text-slate-900 focus:outline-none focus:border-blue-600">
              <option selected>Terminal 02 • Weighbridge & QC Inspection Ramp</option>
              <option>Terminal 01 • Mandi Main Gate Intake Check-In</option>
              <option>Terminal 03 • Direct Benefit Transfer (DBT) Cashier</option>
            </select>
          </div>

          <div class="pt-2 space-y-3">
            <button type="submit" class="btn-large w-full bg-blue-600 hover:bg-blue-700 text-white shadow-md text-base">
              ${t('btnLoginCenter')}
            </button>
            <button type="button" onclick="App.loginAs('center')" class="btn-large w-full bg-slate-100 hover:bg-slate-200 text-slate-800 text-sm">
              ${t('demoCenterBtn')}
            </button>
          </div>
        </form>
      </div>
    `;
  }

  // --- DEDICATED DISTRICT OFFICER ADMIN LOGIN ---
  renderDistrictLogin(t) {
    return `
      <div class="admin-card space-y-6">
        <div class="flex items-center justify-between">
          <button onclick="App.setView('gateway')" class="btn-back-circle">
            <i data-lucide="arrow-left" class="w-4 h-4">←</i>
          </button>
          <span class="text-xs px-2.5 py-1 bg-slate-100 text-slate-800 font-bold rounded-full">District Command</span>
        </div>

        <div class="text-center space-y-1">
          <div class="w-14 h-14 rounded-2xl bg-slate-100 text-slate-700 text-2xl font-black flex items-center justify-center mx-auto mb-2">
            🏛️
          </div>
          <h3 class="text-2xl font-black text-slate-900">${t('districtLoginTitle')}</h3>
          <p class="text-xs text-slate-500 max-w-sm mx-auto">${t('districtLoginDesc')}</p>
        </div>

        <!-- District Officer Form -->
        <form onsubmit="event.preventDefault(); App.loginAs('district')" class="space-y-4 pt-2">
          <div>
            <label class="block text-xs font-bold text-slate-700 mb-1">${t('districtCadreLabel')}</label>
            <select class="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-bold text-slate-900 focus:outline-none focus:border-slate-800">
              <option selected>Indore District Division • All 24 Mandis</option>
              <option>Ujjain District Division • 18 Mandis</option>
              <option>Bhopal District Division • 15 Mandis</option>
            </select>
          </div>

          <div>
            <label class="block text-xs font-bold text-slate-700 mb-1">${t('officerIdLabel')}</label>
            <input type="text" value="MP-IAS-IND-01 (Dr. Anand Verma)" class="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-bold text-slate-900 font-mono focus:outline-none focus:border-slate-800">
          </div>

          <div>
            <label class="block text-xs font-bold text-slate-700 mb-1">${t('passphraseLabel')}</label>
            <input type="password" value="collectorPass@2025" class="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-bold text-slate-900 font-mono focus:outline-none focus:border-slate-800">
          </div>

          <div>
            <label class="block text-xs font-bold text-slate-700 mb-1">${t('authCodeLabel')}</label>
            <input type="text" value="849201" class="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-bold text-slate-900 font-mono focus:outline-none focus:border-slate-800">
          </div>

          <div class="pt-2 space-y-3">
            <button type="submit" class="btn-large w-full bg-slate-900 hover:bg-slate-800 text-white shadow-md text-base">
              ${t('btnLoginDistrict')}
            </button>
            <button type="button" onclick="App.loginAs('district')" class="btn-large w-full bg-slate-100 hover:bg-slate-200 text-slate-800 text-sm">
              ${t('demoDistrictBtn')}
            </button>
          </div>
        </form>
      </div>
    `;
  }

  resetAllData() {
    if (confirm('Reset demo data?')) {
      window.KisanStore.resetDemoData();
      this.render();
      alert('Demo data reset.');
    }
  }

  setSelectedState(stateName) {
    if (window.KisanStore) {
      window.KisanStore.setSelectedState(stateName);
    }
    if (window.FarmerPortal) {
      window.FarmerPortal.wizardDistrict = 'All Districts';
    }
    if (window.DistrictCommand) {
      window.DistrictCommand.selectedDistrict = 'All Districts';
    }
    this.render();
    if (this.currentView === 'farmer' && window.FarmerPortal) {
      window.FarmerPortal.render();
    }
    if (this.currentView === 'district' && window.DistrictCommand) {
      window.DistrictCommand.render();
    }
  }

  setSelectedDistrict(districtName) {
    if (window.KisanStore) {
      window.KisanStore.setSelectedDistrict(districtName);
    }
    if (window.FarmerPortal) {
      window.FarmerPortal.wizardDistrict = districtName;
    }
    if (window.DistrictCommand) {
      window.DistrictCommand.selectedDistrict = districtName;
    }
    this.render();
    if (this.currentView === 'farmer' && window.FarmerPortal) {
      window.FarmerPortal.render();
    }
    if (this.currentView === 'district' && window.DistrictCommand) {
      window.DistrictCommand.render();
    }
  }

  toggleCanvasMode() {
    if (window.KisanStore) {
      window.KisanStore.toggleMobileCanvasMode();
    }
    this.render();
  }

  openGlobalHeatmap(zone = 'All', stateName = '', heatLevel = 'All') {
    const modal = document.getElementById('mandi-heatmap-modal');
    if (!modal) return;
    modal.classList.remove('hidden');
    modal.classList.add('flex');
    this.renderHeatmapModal(zone, stateName, heatLevel);
  }

  closeGlobalHeatmap() {
    const modal = document.getElementById('mandi-heatmap-modal');
    if (!modal) return;
    modal.classList.add('hidden');
    modal.classList.remove('flex');
  }

  renderHeatmapModal(filterZone = 'All', filterState = '', filterHeat = 'All', filterDistrict = 'All Districts') {
    const container = document.getElementById('mandi-heatmap-modal-content');
    if (!container) return;

    const t = window.t;
    const currentState = filterState || (window.KisanStore ? window.KisanStore.getState().selectedState : 'Maharashtra');
    const currentDistrict = filterDistrict || (window.KisanStore ? window.KisanStore.getState().selectedDistrict : 'All Districts');
    const allMandisUnfiltered = window.KisanStore ? window.KisanStore.getAllIndiaMandis('All India', 'All') : [];
    const mandis = window.KisanStore ? window.KisanStore.getAllIndiaMandis(currentState, filterZone, filterHeat, currentDistrict) : [];
    const allStates = window.KisanStore ? window.KisanStore.getIndianStates() : [];
    const districtsList = window.KisanStore ? window.KisanStore.getDistrictsForState(currentState) : [];

    const normalCount = allMandisUnfiltered.filter(m => m.status === 'Normal' || m.congestionLevel === 'low').length;
    const moderateCount = allMandisUnfiltered.filter(m => m.status === 'Moderate' || m.congestionLevel === 'moderate').length;
    const heavyCount = allMandisUnfiltered.filter(m => m.status === 'High' || m.congestionLevel === 'high').length;

    const zones = ['All', 'North', 'West', 'Central', 'South', 'East'];

    container.innerHTML = `
      <div class="bg-white rounded-3xl border border-slate-200 shadow-2xl p-5 sm:p-7 max-h-[92vh] overflow-y-auto space-y-5">
        <!-- Modal Header -->
        <div class="flex items-start justify-between gap-3 border-b border-slate-100 pb-4">
          <div class="flex items-center gap-3">
            <div class="w-12 h-12 rounded-2xl bg-amber-100 text-amber-800 text-2xl flex items-center justify-center font-black flex-shrink-0 shadow-xs">
              🗺️
            </div>
            <div>
              <h3 class="text-xl sm:text-2xl font-black text-slate-900">${t('heatmapTitle')}</h3>
              <p class="text-xs text-slate-500">${t('heatmapSubtitle')} • ${currentState} (${districtsList.length} Districts, ${mandis.length} Mandis)</p>
            </div>
          </div>
          <button onclick="App.closeGlobalHeatmap()" class="btn-back-circle text-slate-500 hover:text-slate-900 text-lg font-bold">
            ✕
          </button>
        </div>

        <!-- 3-Tier Congestion Metric Badges (Normal, Moderate, Heavy) -->
        <div class="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
          <div onclick="App.renderHeatmapModal('${filterZone}', '${currentState}', '${filterHeat === 'Normal' ? 'All' : 'Normal'}', '${currentDistrict}')" class="cursor-pointer p-3.5 rounded-2xl border-2 transition flex items-center justify-between ${filterHeat === 'Normal' ? 'border-emerald-600 bg-emerald-50 shadow-sm ring-2 ring-emerald-400/20' : 'border-emerald-200/80 bg-emerald-50/50 hover:bg-emerald-50'}">
            <div class="flex items-center gap-2.5">
              <span class="w-3.5 h-3.5 rounded-full bg-emerald-500 flex-shrink-0"></span>
              <div>
                <div class="text-xs font-black text-emerald-950">Normal Flow</div>
                <div class="text-[10px] text-emerald-700 font-medium">&lt;20 min wait • Smooth entry</div>
              </div>
            </div>
            <span class="text-lg font-black text-emerald-900 font-mono">${normalCount} <span class="text-[10px] font-normal text-emerald-700">APMCs</span></span>
          </div>

          <div onclick="App.renderHeatmapModal('${filterZone}', '${currentState}', '${filterHeat === 'Moderate' ? 'All' : 'Moderate'}', '${currentDistrict}')" class="cursor-pointer p-3.5 rounded-2xl border-2 transition flex items-center justify-between ${filterHeat === 'Moderate' ? 'border-amber-600 bg-amber-50 shadow-sm ring-2 ring-amber-400/20' : 'border-amber-200/80 bg-amber-50/50 hover:bg-amber-50'}">
            <div class="flex items-center gap-2.5">
              <span class="w-3.5 h-3.5 rounded-full bg-amber-500 flex-shrink-0"></span>
              <div>
                <div class="text-xs font-black text-amber-950">Moderate Traffic</div>
                <div class="text-[10px] text-amber-700 font-medium">20-45 min wait • Steady intake</div>
              </div>
            </div>
            <span class="text-lg font-black text-amber-900 font-mono">${moderateCount} <span class="text-[10px] font-normal text-amber-700">APMCs</span></span>
          </div>

          <div onclick="App.renderHeatmapModal('${filterZone}', '${currentState}', '${filterHeat === 'Heavy' ? 'All' : 'Heavy'}', '${currentDistrict}')" class="cursor-pointer p-3.5 rounded-2xl border-2 transition flex items-center justify-between ${filterHeat === 'Heavy' ? 'border-rose-600 bg-rose-50 shadow-sm ring-2 ring-rose-400/20' : 'border-rose-200/80 bg-rose-50/50 hover:bg-rose-50'}">
            <div class="flex items-center gap-2.5">
              <span class="w-3.5 h-3.5 rounded-full bg-rose-500 animate-pulse flex-shrink-0"></span>
              <div>
                <div class="text-xs font-black text-rose-950">Heavy Congestion</div>
                <div class="text-[10px] text-rose-700 font-medium">&gt;45 min wait • Detour active</div>
              </div>
            </div>
            <span class="text-lg font-black text-rose-900 font-mono">${heavyCount} <span class="text-[10px] font-normal text-rose-700">APMCs</span></span>
          </div>
        </div>

        <!-- Filter Controls: Zone Pills + Heat Levels + State/District Dropdowns -->
        <div class="bg-slate-50 p-3 rounded-2xl border border-slate-200/80 space-y-2.5">
          <div class="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-2.5">
            <!-- Heat Level Filter Pills -->
            <div class="flex items-center gap-1.5 overflow-x-auto pb-1 sm:pb-0">
              <span class="text-[11px] font-bold text-slate-500 whitespace-nowrap mr-1">Heat:</span>
              <button onclick="App.renderHeatmapModal('${filterZone}', '${currentState}', 'All', '${currentDistrict}')" class="px-2.5 py-1 rounded-xl text-xs font-bold transition whitespace-nowrap ${filterHeat === 'All' ? 'bg-slate-900 text-white shadow-sm' : 'bg-white text-slate-700 hover:bg-slate-200/70 border border-slate-200'}">
                All Levels (${allMandisUnfiltered.length})
              </button>
              <button onclick="App.renderHeatmapModal('${filterZone}', '${currentState}', 'Normal', '${currentDistrict}')" class="px-2.5 py-1 rounded-xl text-xs font-bold transition whitespace-nowrap ${filterHeat === 'Normal' ? 'bg-emerald-600 text-white shadow-sm' : 'bg-white text-emerald-800 hover:bg-emerald-100/70 border border-emerald-200'}">
                🟢 Normal (${normalCount})
              </button>
              <button onclick="App.renderHeatmapModal('${filterZone}', '${currentState}', 'Moderate', '${currentDistrict}')" class="px-2.5 py-1 rounded-xl text-xs font-bold transition whitespace-nowrap ${filterHeat === 'Moderate' ? 'bg-amber-600 text-white shadow-sm' : 'bg-white text-amber-800 hover:bg-amber-100/70 border border-amber-200'}">
                🟡 Moderate (${moderateCount})
              </button>
              <button onclick="App.renderHeatmapModal('${filterZone}', '${currentState}', 'Heavy', '${currentDistrict}')" class="px-2.5 py-1 rounded-xl text-xs font-bold transition whitespace-nowrap ${filterHeat === 'Heavy' ? 'bg-rose-600 text-white shadow-sm' : 'bg-white text-rose-800 hover:bg-rose-100/70 border border-rose-200'}">
                🔴 Heavy (${heavyCount})
              </button>
            </div>

            <!-- State & District Selectors Inside Heatmap -->
            <div class="flex items-center gap-2 flex-wrap">
              <select onchange="App.renderHeatmapModal('${filterZone}', this.value, '${filterHeat}', 'All Districts')" class="bg-white border border-slate-200 rounded-xl px-2.5 py-1 text-xs font-bold text-slate-800 focus:outline-none focus:border-emerald-600">
                <option value="All India" ${currentState === 'All India' ? 'selected' : ''}>All India</option>
                ${allStates.map(s => `
                  <option value="${s.name}" ${currentState === s.name ? 'selected' : ''}>${s.name} (${s.nativeName || s.name})</option>
                `).join('')}
              </select>

              <select onchange="App.renderHeatmapModal('${filterZone}', '${currentState}', '${filterHeat}', this.value)" class="bg-white border border-slate-200 rounded-xl px-2.5 py-1 text-xs font-bold text-slate-800 focus:outline-none focus:border-emerald-600 max-w-[170px] truncate">
                <option value="All Districts" ${currentDistrict === 'All Districts' || currentDistrict === 'All' ? 'selected' : ''}>
                  All Districts (${districtsList.length})
                </option>
                ${districtsList.map(d => `
                  <option value="${d}" ${currentDistrict === d ? 'selected' : ''}>${d}</option>
                `).join('')}
              </select>
            </div>
          </div>

          <!-- Zone Pills -->
          <div class="flex items-center gap-1.5 overflow-x-auto pt-1 border-t border-slate-200/60">
            <span class="text-[11px] font-bold text-slate-500 whitespace-nowrap mr-1">Zone:</span>
            ${zones.map(z => `
              <button onclick="App.renderHeatmapModal('${z}', '${currentState}', '${filterHeat}', '${currentDistrict}')" class="px-2.5 py-1 rounded-xl text-xs font-bold transition whitespace-nowrap ${filterZone === z ? 'bg-emerald-700 text-white shadow-sm' : 'bg-white text-slate-700 hover:bg-slate-200/70 border border-slate-200'}">
                ${z === 'All' ? t('zoneAll') : z}
              </button>
            `).join('')}
          </div>
        </div>

        <!-- Mandi Grid Tiles -->
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5">
          ${mandis.length === 0 ? `
            <div class="col-span-full py-12 text-center text-slate-400">
              <p class="text-3xl mb-2">🌾</p>
              <p class="text-sm font-bold">No mandis found matching this filter (${filterHeat} Heat, ${filterZone} Zone, ${currentState}).</p>
              <p class="text-xs mt-1">Try clicking 'All Levels' or selecting 'All India'.</p>
            </div>
          ` : mandis.map(m => {
            const isHigh = m.status === 'High' || m.congestionLevel === 'high';
            const isMod = m.status === 'Moderate' || m.congestionLevel === 'moderate';
            const heatClass = isHigh ? 'heat-high' : isMod ? 'heat-moderate' : 'heat-low';
            const heatBadge = isHigh 
              ? '<span class="px-2 py-0.5 rounded-full text-[10px] font-black bg-rose-600 text-white border border-rose-700 shadow-xs flex items-center gap-1">🔴 Heavy Jam</span>' 
              : isMod 
              ? '<span class="px-2 py-0.5 rounded-full text-[10px] font-black bg-amber-500 text-white border border-amber-600 shadow-xs flex items-center gap-1">🟡 Moderate</span>' 
              : '<span class="px-2 py-0.5 rounded-full text-[10px] font-black bg-emerald-600 text-white border border-emerald-700 shadow-xs flex items-center gap-1">🟢 Normal</span>';

            return `
              <div class="heatmap-tile ${heatClass}" onclick="alert('📍 Mandi Detail: ${m.name}\\n• State: ${m.state} (${m.district})\\n• Congestion: ${isHigh ? 'Heavy Jam (>45 min wait)' : isMod ? 'Moderate Queue (20-45 min wait)' : 'Normal Flow (<20 min wait)'}\\n• Live Queue: ${m.liveQueue} vehicles\\n• Estimated Gate Wait: ${m.avgWait} mins\\n• Godown Storage Used: ${m.storagePct}%\\n• Detour Recommendation: ${m.detour ? 'Reroute to ' + m.detour + ' to save 35 mins' : 'Optimal arrival right now!'}')">
                <div class="flex items-start justify-between gap-2">
                  <div>
                    <span class="text-[10px] font-extrabold uppercase tracking-wider opacity-75">${m.state} • ${m.district}</span>
                    <h4 class="font-black text-sm text-slate-900 leading-tight mt-0.5">${m.name}</h4>
                  </div>
                  ${heatBadge}
                </div>

                <div class="grid grid-cols-2 gap-2 mt-3 text-xs bg-white/80 p-2 rounded-xl border border-black/5 shadow-xs">
                  <div>
                    <span class="text-[10px] opacity-75 block">${t('colAvgWait')}</span>
                    <span class="font-black text-sm font-mono ${isHigh ? 'text-rose-700' : isMod ? 'text-amber-700' : 'text-emerald-700'}">${m.avgWait} mins</span>
                  </div>
                  <div>
                    <span class="text-[10px] opacity-75 block">${t('colVehiclesInLine')}</span>
                    <span class="font-black text-sm font-mono text-slate-900">${m.liveQueue} veh</span>
                  </div>
                </div>

                <div class="mt-2.5">
                  <div class="flex justify-between text-[10px] font-bold mb-1 opacity-80">
                    <span>${t('colStorage')}</span>
                    <span>${m.storagePct}% (${m.storageMT ? m.storageMT.toLocaleString('en-IN') + ' MT' : ''})</span>
                  </div>
                  <div class="w-full bg-black/10 rounded-full h-1.5 overflow-hidden">
                    <div class="h-1.5 rounded-full ${m.storagePct > 85 ? 'bg-rose-500' : m.storagePct > 60 ? 'bg-amber-500' : 'bg-emerald-500'}" style="width: ${m.storagePct}%"></div>
                  </div>
                </div>

                ${m.detour ? `
                  <div class="mt-2.5 pt-2 border-t border-black/5 flex items-center gap-1.5 text-[10px] font-extrabold text-amber-950">
                    <span>⚡ Detour:</span>
                    <span class="truncate">${m.detour}</span>
                  </div>
                ` : `
                  <div class="mt-2.5 pt-2 border-t border-black/5 flex items-center gap-1.5 text-[10px] font-extrabold text-emerald-900">
                    <span>✓ Smooth intake - fast lane open</span>
                  </div>
                `}
              </div>
            `;
          }).join('')}
        </div>

        <!-- Footer Action Inside Modal -->
        <div class="pt-3 border-t border-slate-100 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
          <span class="text-slate-500">Real-time heat density allows farmers and truck operators to avoid gridlocked yards.</span>
          <button onclick="App.closeGlobalHeatmap()" class="btn-large w-full sm:w-auto px-6 py-2.5 bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold rounded-xl">
            Close Heatmap
          </button>
        </div>
      </div>
    `;
  }
}

window.App = new AppController();

function initKisanAppSafely() {
  try {
    if (window.App && typeof window.App.init === 'function') {
      window.App.init();
    }
  } catch (err) {
    console.error('Failed to initialize KisanSetu App:', err);
  }
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initKisanAppSafely);
} else {
  initKisanAppSafely();
}
window.addEventListener('load', initKisanAppSafely);

