/**
 * KisanSetu - Role-Based Access Control Middleware (requireRole)
 * Enforces strict authorization policies:
 * - Never trusts client-submitted role fields
 * - Extracts verified role solely from authenticated req.user
 * - Admins possess superuser override permissions
 */

const { errorResponse } = require('../utils/response');

const requireRole = (...allowedRoles) => {
  return (req, res, next) => {
    // 1. Ensure authentication was performed first
    if (!req.user || !req.user.role) {
      return errorResponse(res, 401, 'Unauthorized. Please authenticate first.');
    }

    const userRole = req.user.role;

    // 2. Allow if user role matches one of allowedRoles, or if user is ADMIN
    if (allowedRoles.includes(userRole) || userRole === 'ADMIN') {
      return next();
    }

    // 3. Block unauthorized roles with 403 Forbidden
    return errorResponse(
      res,
      403,
      `Access forbidden. This endpoint requires [${allowedRoles.join(', ')}] role privilege. Your current role is '${userRole}'.`
    );
  };
};

module.exports = {
  requireRole
};
