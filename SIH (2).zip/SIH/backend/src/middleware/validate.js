/**
 * KisanSetu - Joi Schema Validation Middleware
 * Validates request body, query, or params against standard Joi schemas.
 */

const { errorResponse } = require('../utils/response');

const validate = (schema, property = 'body') => {
  return (req, res, next) => {
    const { error, value } = schema.validate(req[property], {
      abortEarly: false, // Return all validation errors, not just the first
      stripUnknown: true // Strip unknown fields for cleanliness
    });

    if (error) {
      const errorDetails = error.details.map((detail) => ({
        field: detail.path.join('.'),
        message: detail.message.replace(/['"]/g, '')
      }));

      return errorResponse(res, 422, 'Validation failed. Please check your inputs.', errorDetails);
    }

    // Replace request payload with sanitized, validated data
    req[property] = value;
    next();
  };
};

module.exports = validate;
