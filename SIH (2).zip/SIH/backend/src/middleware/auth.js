/**
 * KisanSetu - JWT Authentication Middleware (requireAuth)
 * Extracts and verifies Bearer token from the Authorization header.
 * Attaches verified User document to req.user.
 */

const jwt = require('jsonwebtoken');
const config = require('../config/env');
const User = require('../models/User');
const { errorResponse } = require('../utils/response');

const requireAuth = async (req, res, next) => {
  try {
    let token = null;

    // 1. Extract token from Authorization header (Bearer <token>)
    if (req.headers.authorization && req.headers.authorization.startsWith('Bearer ')) {
      token = req.headers.authorization.split(' ')[1];
    }

    if (!token) {
      return errorResponse(res, 401, 'Access denied. No authentication token provided in Authorization header.');
    }

    // 2. Verify token signature and expiration
    const decoded = jwt.verify(token, config.jwt.secret);

    // 3. Ensure user still exists in database and is active
    const user = await User.findById(decoded.id);

    if (!user) {
      return errorResponse(res, 401, 'Invalid session. The user belonging to this token no longer exists.');
    }

    if (!user.isActive) {
      return errorResponse(res, 403, 'Account is inactive or suspended. Please contact district administrator.');
    }

    // 4. Attach verified user and token claims to request
    req.user = user;
    req.tokenPayload = decoded;

    next();
  } catch (error) {
    if (error.name === 'JsonWebTokenError') {
      return errorResponse(res, 401, 'Invalid authentication token. Please log in again.');
    }
    if (error.name === 'TokenExpiredError') {
      return errorResponse(res, 401, 'Authentication token has expired. Please refresh your session.');
    }
    return errorResponse(res, 500, 'Authentication error occurred.', error.message);
  }
};

module.exports = {
  requireAuth
};
