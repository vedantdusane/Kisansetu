/**
 * KisanSetu - Live Twilio Real Cellular Call & SMS Verification Script
 * Triggers an ACTUAL phone call to the farmer's physical mobile phone.
 * Run: node src/testTwilio.js
 */

const https = require('https');
const fs = require('fs');
const path = require('path');
const config = require('./config/env');

// Helper to make authenticated Twilio API requests using native HTTPS
function twilioRequest(method, endpoint, postData = null, sid, token) {
  return new Promise((resolve, reject) => {
    const authHeader = 'Basic ' + Buffer.from(`${sid}:${token}`).toString('base64');
    const options = {
      hostname: 'api.twilio.com',
      port: 443,
      path: `/2010-04-01/Accounts/${sid}${endpoint}`,
      method: method,
      headers: {
        'Authorization': authHeader,
        ...(postData ? {
          'Content-Type': 'application/x-www-form-urlencoded',
          'Content-Length': Buffer.byteLength(postData)
        } : {})
      }
    };

    const req = https.request(options, (res) => {
      let body = '';
      res.on('data', (chunk) => body += chunk);
      res.on('end', () => {
        try {
          const parsed = JSON.parse(body);
          if (res.statusCode >= 200 && res.statusCode < 300) {
            resolve(parsed);
          } else {
            reject(new Error(parsed.message || `Twilio Error (${res.statusCode}): ${body}`));
          }
        } catch (e) {
          reject(new Error(`Invalid response: ${body}`));
        }
      });
    });

    req.on('error', (err) => reject(err));
    if (postData) req.write(postData);
    req.end();
  });
}

async function runTwilioTest() {
  console.log('🌾 =========================================================');
  console.log('🌾 [KisanSetu - Real Cellular IVR Voice Call Trigger]');
  console.log('🌾 =========================================================\n');

  // Sanitize Account SID (strip any leading 'q' or spaces)
  let rawSid = (config.twilio.accountSid || '').trim();
  if (rawSid.startsWith('qAC') || rawSid.startsWith('QAC')) {
    rawSid = rawSid.substring(1);
  }
  const token = (config.twilio.authToken || '').trim();
  const recipientPhone = '+919067741198';

  console.log(`📋 Account SID:  ${rawSid}`);
  console.log(`🔑 Auth Token:   ${token.substring(0, 4)}••••••••••••••••${token.slice(-4)}`);
  console.log(`📱 Target Phone: ${recipientPhone}\n`);

  if (!rawSid.startsWith('AC')) {
    console.error('❌ Invalid Twilio Account SID! SIDs must start with "AC".');
    process.exit(1);
  }

  // 1. Verify Twilio Credentials & Check Account Balance
  process.stdout.write('⏳ [1/3] Authenticating with Twilio Telephony Cloud... ');
  let account;
  try {
    account = await twilioRequest('GET', '.json', null, rawSid, token);
    console.log('✅ Authenticated!');
    console.log(`   Account Name:   "${account.friendly_name}"`);
    console.log(`   Account Status: ${account.status.toUpperCase()}`);
  } catch (err) {
    console.log('❌ Authentication Failed!');
    console.error(`   Details: ${err.message}`);
    process.exit(1);
  }

  // 2. Discover Twilio Virtual Phone Number
  process.stdout.write('\n⏳ [2/3] Detecting assigned Twilio Caller Phone Number... ');
  let twilioNumber = config.twilio.phoneNumber;
  try {
    const numbersList = await twilioRequest('GET', '/IncomingPhoneNumbers.json', null, rawSid, token);
    if (numbersList.incoming_phone_numbers && numbersList.incoming_phone_numbers.length > 0) {
      twilioNumber = numbersList.incoming_phone_numbers[0].phone_number;
      console.log(`✅ Found: ${twilioNumber}`);

      // Save discovered Twilio number into .env
      const envPath = path.join(__dirname, '../.env');
      if (fs.existsSync(envPath)) {
        let envContent = fs.readFileSync(envPath, 'utf8');
        envContent = envContent.replace(/TWILIO_PHONE_NUMBER=.*/g, `TWILIO_PHONE_NUMBER=${twilioNumber}`);
        envContent = envContent.replace(/TWILIO_ACCOUNT_SID=.*/g, `TWILIO_ACCOUNT_SID=${rawSid}`);
        fs.writeFileSync(envPath, envContent, 'utf8');
      }
    } else {
      console.log('⚠️ No active Twilio phone number found in your account!');
      console.log('👉 Go to Twilio Console ➔ Phone Numbers ➔ "Get a Number" to activate a free virtual number.');
      process.exit(1);
    }
  } catch (err) {
    console.log(`❌ Error fetching phone numbers: ${err.message}`);
    process.exit(1);
  }

  // 3. Initiate Real Cellular IVR Voice Call
  console.log(`\n⏳ [3/3] Placing Live Cellular Voice Call to ${recipientPhone}...`);

  // Authentic KisanSetu Mandi IVR TwiML Voice Script
  const twiml = `
    <Response>
      <Pause length="1"/>
      <Say voice="Polly.Aditi" language="hi-IN">
        नमस्ते! यह किसान सेतु स्मार्ट मंडी ऑपरेटिंग सिस्टम से स्वचालित सूचना है।
        आपका टोकन नंबर ए बारह स्वीकृत हो गया है।
        कृपया अपना ट्रैक्टर तुरंत वे ब्रिज लेन टी टी शून्य चार पर लेकर आएं।
        धन्यवाद!
      </Say>
      <Pause length="1"/>
      <Say voice="alice" language="en-IN">
        Hello! This is an automated update from KisanSetu Smart APMC Mandi.
        Your token A-12 has been called to Weighbridge Bay 1.
        Please proceed immediately. Thank you!
      </Say>
    </Response>
  `.trim().replace(/\s+/g, ' ');

  const callParams = new URLSearchParams({
    To: recipientPhone,
    From: twilioNumber,
    Twiml: twiml
  }).toString();

  try {
    const call = await twilioRequest('POST', '/Calls.json', callParams, rawSid, token);
    console.log('\n============================================================');
    console.log('🎉 📞 PHONE CALL PLACED SUCCESSFULLY!');
    console.log(`   Call SID:    ${call.sid}`);
    console.log(`   From:        ${call.from}`);
    console.log(`   To:          ${call.to}`);
    console.log(`   Status:      ${call.status.toUpperCase()} (Ringing...)`);
    console.log('============================================================');
    console.log('👉 Pick up your mobile phone! You will hear the KisanSetu automated IVR voice!');
  } catch (err) {
    console.log('\n❌ Failed to place call:');
    console.error(`   ${err.message}`);
    if (err.message.includes('unverified')) {
      console.log('\n💡 Twilio Trial Note: In a Twilio trial account, your destination phone number must be verified in the Twilio console:');
      console.log(`   Open: https://console.twilio.com/us1/develop/phone-numbers/manage/verified`);
      console.log(`   Add: ${recipientPhone}`);
    }
  }
}

runTwilioTest();
