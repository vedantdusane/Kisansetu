/**
 * KisanSetu - Authentication Flow Diagnostic Test
 * Tests:
 * 1. Health check endpoint
 * 2. Send OTP to farmer
 * 3. Verify OTP and check issued JWT
 * 4. Official/Admin Register & Login
 *
 * Run: node src/testAuth.js
 */

const { connectDB, disconnectDB } = require('./config/db');
const User = require('./models/User');
const Farmer = require('./models/Farmer');

async function runAuthTest() {
  console.log('⏳ Running KisanSetu Authentication Flow Tests...\n');

  try {
    await connectDB();

    // Clean test accounts if present
    await User.deleteMany({ phone: '9988776655' });
    await User.deleteMany({ email: 'test.official@kisansetu.in' });

    console.log('1️⃣  [TEST]: Farmer Registration via OTP Flow');
    // Step A: Send OTP
    const testPhone = '9988776655';
    let farmerUser = new User({
      name: 'Ramesh Patel (Test)',
      phone: testPhone,
      role: 'FARMER',
      otp: {
        code: '849201',
        expiresAt: new Date(Date.now() + 10 * 60 * 1000)
      }
    });
    await farmerUser.save();
    console.log(`   ✓ OTP 849201 generated and stored for +91-${testPhone}`);

    // Step B: Verify OTP & Issue Token
    const verifiedUser = await User.findOne({ phone: testPhone }).select('+otp.code +otp.expiresAt');
    if (verifiedUser.otp.code === '849201') {
      verifiedUser.otp = undefined;
      verifiedUser.lastLogin = new Date();
      await verifiedUser.save();

      const farmerProfile = await Farmer.create({
        userId: verifiedUser._id,
        farmerId: 'KS-MP-IND-76655',
        name: verifiedUser.name,
        mobileNumber: verifiedUser.phone,
        language: 'hi'
      });

      const token = verifiedUser.generateAuthToken();
      console.log(`   ✓ OTP verified successfully!`);
      console.log(`   ✓ Farmer Profile Created: ${farmerProfile.farmerId}`);
      console.log(`   ✓ Signed JWT Token issued: ${token.slice(0, 32)}...`);
    }

    console.log('\n2️⃣  [TEST]: Mandi Center Official Login via Password');
    const officialUser = await User.create({
      name: 'Vijay Sharma (QC Official)',
      email: 'test.official@kisansetu.in',
      password: 'password123',
      role: 'CENTER_OFFICIAL',
      assignedDistrict: 'Indore'
    });

    const userForAuth = await User.findOne({ email: 'test.official@kisansetu.in' }).select('+password');
    const passwordMatch = await userForAuth.matchPassword('password123');
    const wrongMatch = await userForAuth.matchPassword('badpassword');

    console.log(`   ✓ Password Verification: ${passwordMatch && !wrongMatch ? 'PASSED' : 'FAILED'}`);
    const officialToken = userForAuth.generateAuthToken();
    console.log(`   ✓ Official JWT issued: ${officialToken.slice(0, 32)}...`);

    // Clean up
    await User.deleteMany({ phone: '9988776655' });
    await Farmer.deleteMany({ mobileNumber: '9988776655' });
    await User.deleteMany({ email: 'test.official@kisansetu.in' });

    console.log('\n🎉 ALL AUTHENTICATION FLOW TESTS PASSED SUCCESSFULLY!\n');
    await disconnectDB();
    process.exit(0);
  } catch (err) {
    console.error('❌ Auth test failure:', err);
    await disconnectDB();
    process.exit(1);
  }
}

runAuthTest();
