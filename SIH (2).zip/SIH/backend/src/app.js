/**
 * KisanSetu - Express Application Factory
 * Configures middleware, API routing, security headers, and error handling.
 */

const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const config = require('./config/env');
const errorHandler = require('./middleware/errorHandler');
const { successResponse, errorResponse } = require('./utils/response');

// Import Route Handlers
const authRoutes = require('./routes/authRoutes');
const farmerRoutes = require('./routes/farmerRoutes');
const centerRoutes = require('./routes/centerRoutes');
const slotRoutes = require('./routes/slotRoutes');
const bookingRoutes = require('./routes/bookingRoutes');
const checkinRoutes = require('./routes/checkinRoutes');
const queueRoutes = require('./routes/queueRoutes');
const weighmentRoutes = require('./routes/weighmentRoutes');
const qualityRoutes = require('./routes/qualityRoutes');
const billRoutes = require('./routes/billRoutes');
const paymentRoutes = require('./routes/paymentRoutes');
const districtRoutes = require('./routes/districtRoutes');

const app = express();

// Security Headers
app.use(helmet());

// CORS Setup (Allows React frontend or PWA)
app.use(
  cors({
    origin: '*', // In production, replace with config.frontendUrl
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'PATCH'],
    allowedHeaders: ['Content-Type', 'Authorization']
  })
);

// Body Parsers
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));

// HTTP Request Logger
if (config.nodeEnv === 'development') {
  app.use(morgan('dev'));
}

// Health Check Endpoint
app.get('/api/health', (req, res) => {
  return successResponse(res, 200, 'KisanSetu Backend Operating System is Healthy and Active', {
    version: '1.0.0',
    service: 'KisanSetu Central Core',
    timestamp: new Date().toISOString(),
    demoMode: config.demoMode
  });
});

// API Routes Mounting
app.use('/api/auth', authRoutes);
app.use('/api/farmers', farmerRoutes);
app.use('/api/centers', centerRoutes);
app.use('/api/slots', slotRoutes);
app.use('/api/bookings', bookingRoutes);
app.use('/api/checkin', checkinRoutes);
app.use('/api/queue', queueRoutes);
app.use('/api/weighment', weighmentRoutes);
app.use('/api/quality', qualityRoutes);
app.use('/api/bills', billRoutes);
app.use('/api/payments', paymentRoutes);
app.use('/api/district', districtRoutes);

// 404 Catch-All Handler
app.use('*', (req, res) => {
  return errorResponse(res, 404, `Endpoint not found: ${req.method} ${req.originalUrl}`);
});

// Global Error Handler
app.use(errorHandler);

module.exports = app;
