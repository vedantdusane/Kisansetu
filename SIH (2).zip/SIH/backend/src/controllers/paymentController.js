/**
 * KisanSetu - DBT Payment Controller
 * Manages government Direct Benefit Transfer payouts directly to farmer bank accounts.
 */

const Payment = require('../models/Payment');
const { Bill } = require('../models/Bill');
const Booking = require('../models/Booking');
const Farmer = require('../models/Farmer');
const { successResponse, errorResponse } = require('../utils/response');

/**
 * POST /api/payments/initiate
 * Initiate DBT disbursement through PFMS / Aadhaar Payment Bridge
 */
async function initiatePayment(req, res) {
  try {
    const { billId } = req.body;
    if (!billId) {
      return errorResponse(res, 400, 'billId is required.');
    }

    const bill = await Bill.findById(billId);
    if (!bill) {
      return errorResponse(res, 404, 'Procurement bill not found.');
    }

    const farmer = await Farmer.findById(bill.farmerId);
    const booking = await Booking.findById(bill.bookingId);

    const dbtReferenceId = `DBT-${new Date().toISOString().replace(/[^0-9]/g, '').slice(0, 8)}-${Math.floor(100000 + Math.random() * 900000)}`;

    const bankDetails = farmer?.bankDetails || {
      accountHolderName: farmer?.name || bill.farmerName,
      bankName: 'State Bank of India',
      accountNumberMasked: 'XXXXXX4821',
      ifscCode: 'SBIN0001428',
      aadhaarLinked: true
    };

    const payment = await Payment.create({
      dbtReferenceId,
      billId: bill._id,
      bookingId: bill.bookingId,
      farmerId: bill.farmerId,
      amount: bill.netPayableAmount,
      beneficiary: bankDetails,
      paymentGateway: 'PFMS_AADHAAR_BRIDGE',
      status: 'INITIATED'
    });

    bill.status = 'PAYMENT_PROCESSING';
    await bill.save();

    if (booking) {
      booking.paymentId = payment._id;
      booking.transitionStatus(
        'PAYMENT_PROCESSING',
        req.user._id,
        `DBT payment of ₹${bill.netPayableAmount} queued in PFMS bank gateway. Ref: ${dbtReferenceId}`
      );
      await booking.save();
    }

    return successResponse(res, 201, `DBT Transfer of ₹${bill.netPayableAmount} initiated successfully!`, {
      payment
    });
  } catch (err) {
    return errorResponse(res, 500, 'Error initiating DBT payment.', err.message);
  }
}

/**
 * POST /api/payments/simulate-credit
 * Simulates RBI & Public Financial Management System (PFMS) bank credit confirmation
 */
async function simulateCredit(req, res) {
  try {
    const { paymentId } = req.body;
    if (!paymentId) {
      return errorResponse(res, 400, 'paymentId is required.');
    }

    const payment = await Payment.findById(paymentId);
    if (!payment) {
      return errorResponse(res, 404, 'Payment record not found.');
    }

    // Generate real-looking bank UTR reference
    const utrNumber = `UTR${Date.now().toString().slice(-8)}${Math.floor(1000 + Math.random() * 9000)}`;

    payment.status = 'BANK_CREDITED';
    payment.utrNumber = utrNumber;
    payment.creditedAt = new Date();
    await payment.save();

    // Update Bill
    await Bill.findByIdAndUpdate(payment.billId, { status: 'SETTLED' });

    // Update Booking to Final 13th Stage: COMPLETED
    const booking = await Booking.findById(payment.bookingId);
    if (booking) {
      booking.transitionStatus(
        'COMPLETED',
        req.user._id,
        `DBT Funds Settled: ₹${payment.amount} credited to account ending in ${payment.beneficiary.accountNumberMasked.slice(-4)}. UTR: ${utrNumber}`
      );
      await booking.save();
    }

    return successResponse(res, 200, `DBT payment settled! ₹${payment.amount} credited.`, {
      settlement: {
        paymentId: payment._id,
        dbtReferenceId: payment.dbtReferenceId,
        utrNumber,
        creditedAmount: payment.amount,
        bankName: payment.beneficiary.bankName,
        creditedAt: payment.creditedAt,
        finalBookingStatus: 'COMPLETED'
      }
    });
  } catch (err) {
    return errorResponse(res, 500, 'Error settling DBT payment.', err.message);
  }
}

/**
 * GET /api/payments/bill/:billId
 * Get payment tracking details
 */
async function getPaymentByBill(req, res) {
  try {
    const { billId } = req.params;
    const payment = await Payment.findOne({ billId });
    if (!payment) {
      return errorResponse(res, 404, 'No DBT transfer records found for this bill.');
    }

    return successResponse(res, 200, 'Payment details retrieved.', { payment });
  } catch (err) {
    return errorResponse(res, 500, 'Error retrieving payment.', err.message);
  }
}

module.exports = {
  initiatePayment,
  simulateCredit,
  getPaymentByBill
};
