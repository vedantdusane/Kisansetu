/**
 * KisanSetu - Capacity Slot Controller
 * Manages appointment time slots, quota limits, and emergency blocking.
 */

const Slot = require('../models/Slot');
const Center = require('../models/Center');
const { successResponse, errorResponse } = require('../utils/response');

/**
 * @desc    Get slots for a center and date
 * @route   GET /api/slots
 * @access  Public / Authenticated
 */
const getSlots = async (req, res, next) => {
  try {
    const { centerId, centerCode, date, status } = req.query;

    const filter = {};

    if (centerId) {
      filter.centerId = centerId;
    }

    if (centerCode) {
      filter.centerCode = centerCode.toUpperCase();
    }

    if (date) {
      filter.date = date;
    }

    if (status) {
      filter.status = status;
    }

    const slots = await Slot.find(filter).sort({ date: 1, startTime: 1 });

    return successResponse(res, 200, `Found ${slots.length} time slot(s)`, slots);
  } catch (error) {
    next(error);
  }
};

/**
 * @desc    Create a single capacity slot
 * @route   POST /api/slots
 * @access  Private (ADMIN, CENTER_OFFICIAL)
 */
const createSlot = async (req, res, next) => {
  try {
    const { centerId, date, startTime, endTime, maxBookings = 30 } = req.body;

    const center = await Center.findById(centerId);
    if (!center) {
      return errorResponse(res, 404, 'Referenced procurement center does not exist.');
    }

    const existingSlot = await Slot.findOne({
      centerId,
      date,
      startTime
    });

    if (existingSlot) {
      return errorResponse(
        res,
        409,
        `A slot already exists for center ${center.centerId} on ${date} at ${startTime}.`
      );
    }

    const slot = await Slot.create({
      centerId: center._id,
      centerCode: center.centerId,
      date,
      startTime,
      endTime,
      maxBookings
    });

    return successResponse(res, 201, 'Slot created successfully', slot);
  } catch (error) {
    next(error);
  }
};

/**
 * @desc    Generate a standard daily schedule of hourly slots (e.g. 09:00 AM - 05:00 PM)
 * @route   POST /api/slots/generate-day
 * @access  Private (ADMIN, CENTER_OFFICIAL)
 */
const generateDailySlots = async (req, res, next) => {
  try {
    const { centerId, date, capacityPerSlot = 30 } = req.body;

    const center = await Center.findById(centerId);
    if (!center) {
      return errorResponse(res, 404, 'Procurement center not found.');
    }

    const standardHours = [
      { start: '09:00 AM', end: '10:00 AM' },
      { start: '10:00 AM', end: '11:00 AM' },
      { start: '11:00 AM', end: '12:00 PM' },
      { start: '12:00 PM', end: '01:00 PM' },
      { start: '02:00 PM', end: '03:00 PM' },
      { start: '03:00 PM', end: '04:00 PM' },
      { start: '04:00 PM', end: '05:00 PM' }
    ];

    const createdSlots = [];

    for (const h of standardHours) {
      const existing = await Slot.findOne({ centerId: center._id, date, startTime: h.start });
      if (!existing) {
        const slot = await Slot.create({
          centerId: center._id,
          centerCode: center.centerId,
          date,
          startTime: h.start,
          endTime: h.end,
          maxBookings: capacityPerSlot
        });
        createdSlots.push(slot);
      }
    }

    return successResponse(
      res,
      201,
      `Successfully generated ${createdSlots.length} appointment slot(s) for ${center.name} on ${date}`,
      createdSlots
    );
  } catch (error) {
    next(error);
  }
};

/**
 * @desc    Update slot (e.g., Emergency block, change quota)
 * @route   PUT /api/slots/:id
 * @access  Private (ADMIN, CENTER_OFFICIAL)
 */
const updateSlot = async (req, res, next) => {
  try {
    const { id } = req.params;
    const { isBlocked, maxBookings } = req.body;

    const slot = await Slot.findById(id);
    if (!slot) {
      return errorResponse(res, 404, 'Time slot not found.');
    }

    if (isBlocked !== undefined) {
      slot.isBlocked = isBlocked;
    }

    if (maxBookings !== undefined) {
      slot.maxBookings = maxBookings;
    }

    await slot.save();

    return successResponse(res, 200, `Slot updated. Status: ${slot.status}`, slot);
  } catch (error) {
    next(error);
  }
};

module.exports = {
  getSlots,
  createSlot,
  generateDailySlots,
  updateSlot
};
