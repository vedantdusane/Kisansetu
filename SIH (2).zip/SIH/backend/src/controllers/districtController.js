/**
 * KisanSetu - District Telemetrics & Congestion Heatmap Controller
 * Powers administrative oversight, storage saturation alarms, and smart traffic diversion.
 */

const Center = require('../models/Center');
const Booking = require('../models/Booking');
const { Bill } = require('../models/Bill');
const { successResponse, errorResponse } = require('../utils/response');

/**
 * GET /api/district/overview
 * Macro KPI telemetrics for District Collectors & Ministry Officials
 */
async function getDistrictOverview(req, res) {
  try {
    const { state, district } = req.query;
    const filter = {};
    if (state) filter.state = state;
    if (district) filter.district = district;

    const centers = await Center.find(filter);
    const centerIds = centers.map((c) => c._id);

    const today = new Date().toISOString().split('T')[0];

    // Compute aggregated operational metrics
    const [todayBookings, totalBills] = await Promise.all([
      Booking.find({ centerId: { $in: centerIds }, date: today }),
      Bill.find({ centerId: { $in: centerIds } })
    ]);

    let totalCapacity = 0;
    let totalStorageUsed = 0;
    centers.forEach((c) => {
      totalCapacity += c.storageCapacity || 0;
      totalStorageUsed += c.storageUsed || 0;
    });

    const averageSaturation = totalCapacity > 0 ? Math.round((totalStorageUsed / totalCapacity) * 100) : 0;

    let totalDisbursedAmt = 0;
    totalBills.forEach((b) => {
      if (b.status === 'SETTLED' || b.status === 'PAYMENT_PROCESSING') {
        totalDisbursedAmt += b.netPayableAmount || 0;
      }
    });

    const activeTrucksInYards = todayBookings.filter((b) =>
      ['CHECKED_IN', 'WAITING', 'CALLED', 'WEIGHING', 'QUALITY_CHECK'].includes(b.status)
    ).length;

    return successResponse(res, 200, 'District overview metrics retrieved.', {
      kpis: {
        totalMandis: centers.length,
        totalStorageCapacityMT: totalCapacity,
        totalStorageUsedMT: totalStorageUsed,
        averageSaturationPct: averageSaturation,
        todayRegisteredAppointments: todayBookings.length,
        activeTrucksInYards,
        totalDisbursedDbtAmountInr: totalDisbursedAmt
      }
    });
  } catch (err) {
    return errorResponse(res, 500, 'Error fetching district overview.', err.message);
  }
}

/**
 * GET /api/district/heatmap
 * Live Congestion Spectrum for all Mandi Yards with detour recommendations
 */
async function getMandiHeatmap(req, res) {
  try {
    const { state, zone } = req.query;
    const filter = { active: true };
    if (state) filter.state = state;
    if (zone) filter.zone = zone;

    const centers = await Center.find(filter);
    const today = new Date().toISOString().split('T')[0];

    // Build real-time heatmap items
    const heatmap = await Promise.all(
      centers.map(async (center) => {
        const queueCount = await Booking.countDocuments({
          centerId: center._id,
          date: today,
          status: { $in: ['CHECKED_IN', 'WAITING'] }
        });

        const saturation = center.storageSaturationPct || 50;

        // Determine visual congestion status
        let congestionLevel = 'LOW'; // 🟢
        let waitTimeMins = queueCount * 5;
        let detourAdvice = null;

        if (saturation > 85 || waitTimeMins > 45) {
          congestionLevel = 'HIGH'; // 🔴
          waitTimeMins = Math.max(50, waitTimeMins);
          detourAdvice = `Heavy load! Recommend rerouting incoming grain to nearest sub-yard (${center.district} North SWC Godown) to save ~40 mins.`;
        } else if (saturation > 65 || waitTimeMins > 20) {
          congestionLevel = 'MODERATE'; // 🟡
          waitTimeMins = Math.max(25, waitTimeMins);
          detourAdvice = 'Moderate truck line. Direct small pickup carriers to Lane 2.';
        } else {
          waitTimeMins = Math.max(10, waitTimeMins);
          detourAdvice = 'Optimal intake flow. All weighbridges operational.';
        }

        return {
          centerId: center.centerId,
          name: center.name,
          district: center.district,
          state: center.state,
          zone: center.zone,
          coordinates: center.coordinates,
          congestionLevel,
          storageCapacityMT: center.storageCapacity,
          storageUsedMT: center.storageUsed,
          storageSaturationPct: saturation,
          vehiclesInQueue: queueCount,
          averageWaitMins: waitTimeMins,
          detourAdvice,
          acceptedCrops: center.acceptedCrops
        };
      })
    );

    return successResponse(res, 200, 'Live Mandi Heatmap retrieved.', { heatmap });
  } catch (err) {
    return errorResponse(res, 500, 'Error calculating mandi heatmap.', err.message);
  }
}

/**
 * GET /api/district/alerts
 * Automated bottleneck & load redirection alarms
 */
async function getCongestionAlerts(req, res) {
  try {
    const { state } = req.query;
    const filter = { active: true };
    if (state) filter.state = state;

    const centers = await Center.find(filter);
    const alerts = [];

    centers.forEach((c) => {
      if (c.storageSaturationPct >= 85) {
        alerts.push({
          id: `ALT-${c.centerId}-STORAGE`,
          centerCode: c.centerId,
          centerName: c.name,
          district: c.district,
          severity: 'CRITICAL',
          type: 'STORAGE_SATURATION',
          message: `${c.name} godowns are ${c.storageSaturationPct}% full (${c.storageAvailable} MT remaining). Action: Trigger inter-district rail freight dispatch to CWC Silos.`,
          timestamp: new Date().toISOString()
        });
      } else if (c.storageSaturationPct >= 75) {
        alerts.push({
          id: `ALT-${c.centerId}-HIGH-LOAD`,
          centerCode: c.centerId,
          centerName: c.name,
          district: c.district,
          severity: 'WARNING',
          type: 'HIGH_INTAKE_VOLUME',
          message: `${c.name} experiencing heavy arrival rate. Recommend opening secondary overflow parking bay.`,
          timestamp: new Date().toISOString()
        });
      }
    });

    return successResponse(res, 200, 'Active operational alerts retrieved.', {
      totalAlerts: alerts.length,
      alerts
    });
  } catch (err) {
    return errorResponse(res, 500, 'Error fetching alerts.', err.message);
  }
}

module.exports = {
  getDistrictOverview,
  getMandiHeatmap,
  getCongestionAlerts
};
