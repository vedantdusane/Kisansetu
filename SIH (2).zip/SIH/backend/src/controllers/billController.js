/**
 * KisanSetu - MSP Billing Controller
 * Generates official procurement invoices, price settlements, and MSP subsidy records.
 */

const { Bill, GOV_MSP_RATES } = require('../models/Bill');
const Booking = require('../models/Booking');
const Weighment = require('../models/Weighment');
const QualityCheck = require('../models/QualityCheck');
const Farmer = require('../models/Farmer');
const { successResponse, errorResponse } = require('../utils/response');

/**
 * POST /api/bills/generate
 * Finalize procurement and generate official MSP invoice
 */
async function generateBill(req, res) {
  try {
    const { bookingId } = req.body;
    if (!bookingId) {
      return errorResponse(res, 400, 'bookingId is required.');
    }

    const booking = await Booking.findOne({
      $or: [{ bookingId: bookingId.toUpperCase() }, { _id: bookingId }]
    });

    if (!booking) {
      return errorResponse(res, 404, 'Booking not found.');
    }

    // 1. Fetch Verified Net Weight
    const weighment = await Weighment.findOne({ bookingId: booking._id });
    if (!weighment || weighment.stage !== 'COMPLETED' || weighment.netWeightQtl <= 0) {
      return errorResponse(res, 400, 'Cannot generate bill: Tare weighment is incomplete or Net Weight is 0.');
    }

    // 2. Fetch Quality Assay
    const quality = await QualityCheck.findOne({ bookingId: booking._id });
    if (quality && quality.status === 'REJECTED') {
      return errorResponse(res, 400, 'Cannot generate bill: Produce was rejected during quality inspection.');
    }

    const qualityDeductionPct = quality ? quality.deductionPct : 0;

    // 3. Compute Financial Calculations
    const calculations = Bill.calculateBill({
      crop: booking.crop,
      netQuantityQtl: weighment.netWeightQtl,
      qualityDeductionPct
    });

    const billNumber = `BILL-${booking.centerCode.replace(/[^A-Za-z0-9]/g, '')}-${Date.now().toString().slice(-6)}`;

    // 4. Create or Update Bill
    let bill = await Bill.findOne({ bookingId: booking._id });
    if (bill) {
      Object.assign(bill, calculations);
      bill.netQuantityQtl = weighment.netWeightQtl;
      bill.qualityDeductionPct = qualityDeductionPct;
      await bill.save();
    } else {
      bill = await Bill.create({
        billNumber,
        bookingId: booking._id,
        bookingCode: booking.bookingId,
        token: booking.token.displayToken,
        farmerId: booking.farmerId,
        farmerName: booking.farmerName,
        farmerPhone: booking.farmerPhone,
        centerId: booking.centerId,
        crop: booking.crop,
        netQuantityQtl: weighment.netWeightQtl,
        mspRatePerQtl: calculations.mspRatePerQtl,
        grossAmount: calculations.grossAmount,
        qualityDeductionPct,
        qualityDeductionAmount: calculations.qualityDeductionAmount,
        netPayableAmount: calculations.netPayableAmount,
        status: 'PAYMENT_PENDING',
        generatedBy: req.user._id
      });
    }

    booking.billId = bill._id;
    booking.transitionStatus(
      'BILL_GENERATED',
      req.user._id,
      `Official MSP Bill created: ₹${calculations.netPayableAmount} for ${weighment.netWeightQtl} Qtl ${booking.crop}`
    );
    await booking.save();

    return successResponse(res, 201, `Bill ${bill.billNumber} generated successfully!`, {
      bill,
      mspRatesReference: GOV_MSP_RATES
    });
  } catch (err) {
    return errorResponse(res, 500, 'Error generating bill.', err.message);
  }
}

/**
 * GET /api/bills/:bookingId
 * Retrieve invoice breakdown
 */
async function getBill(req, res) {
  try {
    const { bookingId } = req.params;
    const isMongo = bookingId.match(/^[0-9a-fA-F]{24}$/);
    const booking = await Booking.findOne(isMongo ? { _id: bookingId } : { bookingId: bookingId.toUpperCase() });

    if (!booking) return errorResponse(res, 404, 'Booking not found.');

    const bill = await Bill.findOne({ bookingId: booking._id })
      .populate('farmerId', 'name mobileNumber residence bankDetails')
      .populate('centerId', 'name centerId district state');

    if (!bill) return errorResponse(res, 404, 'No procurement bill generated yet for this booking.');

    return successResponse(res, 200, 'Bill retrieved.', { bill });
  } catch (err) {
    return errorResponse(res, 500, 'Error retrieving bill.', err.message);
  }
}

module.exports = {
  generateBill,
  getBill
};
