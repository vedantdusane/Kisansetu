/**
 * KisanSetu - Gate Check-In Controller
 * Handles physical vehicle arrivals, QR scanner verification, and yard intake logging.
 */

const Booking = require('../models/Booking');
const qrService = require('../services/qrService');
const { successResponse, errorResponse } = require('../utils/response');

/**
 * POST /api/checkin/scan
 * Security officer / Gate marshal scans digital pass or enters manual token
 */
async function scanAndCheckIn(req, res) {
  try {
    const { qrPayload, bookingId, displayToken, date, centerId, gateNumber = 'GATE-01', verifiedVehicleNumber } = req.body;

    let booking = null;

    // 1. Identify Booking from QR Payload OR Manual Fallback
    if (qrPayload) {
      // Find booking having this qrPayload
      booking = await Booking.findOne({ 'qrCode.qrPayload': qrPayload });

      if (!booking) {
        return errorResponse(res, 404, 'Invalid pass. No appointment matches this QR code.');
      }

      // Cryptographic verification
      const verifyResult = qrService.verifyQrPayload(qrPayload, booking.bookingId);
      if (!verifyResult.isValid) {
        return errorResponse(res, 400, `Security Alert: ${verifyResult.reason}`);
      }
    } else if (bookingId) {
      booking = await Booking.findOne({ bookingId: bookingId.toUpperCase() });
    } else if (displayToken && centerId) {
      const targetDate = date || new Date().toISOString().split('T')[0];
      booking = await Booking.findOne({
        centerId,
        date: targetDate,
        'token.displayToken': displayToken.toUpperCase()
      });
    }

    if (!booking) {
      return errorResponse(res, 404, 'Appointment booking not found. Please verify details.');
    }

    // 2. Validate current status
    if (booking.status === 'CHECKED_IN') {
      return errorResponse(res, 400, `Token ${booking.token.displayToken} has ALREADY checked in at ${booking.checkInTime ? booking.checkInTime.toLocaleTimeString() : 'the gate'}.`);
    }

    if (booking.status === 'CANCELLED') {
      return errorResponse(res, 400, 'This appointment was CANCELLED and cannot be admitted to the yard.');
    }

    if (booking.status !== 'BOOKED') {
      return errorResponse(res, 400, `Produce is already inside yard operations (Current status: ${booking.status}).`);
    }

    // 3. Update vehicle number if corrected by guard
    if (verifiedVehicleNumber && verifiedVehicleNumber.trim()) {
      booking.vehicle.vehicleNumber = verifiedVehicleNumber.trim().toUpperCase();
    }

    // 4. State transition to CHECKED_IN
    const guardNotes = `Gate QR scan verified at ${gateNumber} by Officer ${req.user.name || req.user.phone}`;
    booking.transitionStatus('CHECKED_IN', req.user._id, guardNotes);
    await booking.save();

    // 5. Calculate queue position ahead
    const aheadCount = await Booking.countDocuments({
      centerId: booking.centerId,
      date: booking.date,
      status: { $in: ['CHECKED_IN', 'WAITING'] },
      checkInTime: { $lt: booking.checkInTime }
    });

    const queuePosition = aheadCount + 1;
    const estimatedWaitMinutes = aheadCount * 6; // Average 6 mins per weighment cycle

    return successResponse(res, 200, `Vehicle verified! Token ${booking.token.displayToken} checked in to yard.`, {
      checkIn: {
        bookingId: booking.bookingId,
        token: booking.token.displayToken,
        farmerName: booking.farmerName,
        crop: booking.crop,
        quantityQtl: booking.expectedQuantityQtl,
        vehicleNumber: booking.vehicle.vehicleNumber,
        assignedLane: booking.vehicle.assignedLane,
        assignedBay: booking.vehicle.assignedBay,
        gateNumber,
        checkInTime: booking.checkInTime,
        queuePosition,
        estimatedWaitMinutes
      }
    });
  } catch (err) {
    return errorResponse(res, 500, 'Gate check-in failed.', err.message);
  }
}

/**
 * GET /api/checkin/today-stats
 * Gate summary dashboard
 */
async function getTodayGateStats(req, res) {
  try {
    const { centerId, date } = req.query;
    if (!centerId) {
      return errorResponse(res, 400, 'centerId query parameter is required.');
    }

    const todayDate = date || new Date().toISOString().split('T')[0];

    const [totalBooked, checkedIn, waiting, processing, completed] = await Promise.all([
      Booking.countDocuments({ centerId, date: todayDate }),
      Booking.countDocuments({ centerId, date: todayDate, status: 'CHECKED_IN' }),
      Booking.countDocuments({ centerId, date: todayDate, status: 'WAITING' }),
      Booking.countDocuments({ centerId, date: todayDate, status: { $in: ['CALLED', 'WEIGHING', 'QUALITY_CHECK'] } }),
      Booking.countDocuments({ centerId, date: todayDate, status: { $in: ['COMPLETED', 'BILL_GENERATED', 'APPROVED'] } })
    ]);

    return successResponse(res, 200, 'Gate statistics retrieved.', {
      stats: {
        date: todayDate,
        totalBooked,
        checkedIn,
        waiting,
        processing,
        completed,
        pendingArrival: Math.max(0, totalBooked - (checkedIn + waiting + processing + completed))
      }
    });
  } catch (err) {
    return errorResponse(res, 500, 'Error retrieving gate stats.', err.message);
  }
}

module.exports = {
  scanAndCheckIn,
  getTodayGateStats
};
