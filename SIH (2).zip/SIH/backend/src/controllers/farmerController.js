/**
 * KisanSetu - Farmer Profile Controller
 * Protected by requireAuth and requireRole('FARMER')
 */

const Farmer = require('../models/Farmer');
const User = require('../models/User');
const { successResponse, errorResponse } = require('../utils/response');

/**
 * @desc    Get logged-in farmer profile
 * @route   GET /api/farmers/profile
 * @access  Private (FARMER)
 */
const getProfile = async (req, res, next) => {
  try {
    const farmer = await Farmer.findOne({ userId: req.user._id }).populate('userId', 'name phone email preferredLanguage role');

    if (!farmer) {
      return errorResponse(res, 404, 'Farmer profile not found for this account.');
    }

    return successResponse(res, 200, 'Farmer profile retrieved successfully', farmer);
  } catch (error) {
    next(error);
  }
};

/**
 * @desc    Update farmer residence, land ratio, and vehicle info
 * @route   PUT /api/farmers/profile
 * @access  Private (FARMER)
 */
const updateProfile = async (req, res, next) => {
  try {
    const { name, residence, landDetails, crops, defaultVehicle, bankDetails, language } = req.body;

    let farmer = await Farmer.findOne({ userId: req.user._id });

    if (!farmer) {
      return errorResponse(res, 404, 'Farmer profile not found.');
    }

    if (name) {
      farmer.name = name;
      await User.findByIdAndUpdate(req.user._id, { name });
    }

    if (language) {
      farmer.language = language;
      await User.findByIdAndUpdate(req.user._id, { preferredLanguage: language });
    }

    if (residence) {
      farmer.residence = { ...farmer.residence.toObject(), ...residence };
    }

    if (landDetails) {
      // Auto-calculate Bigha equivalent if totalAcres changed
      if (landDetails.totalAcres) {
        landDetails.bighaEquivalent = `${(landDetails.totalAcres * 2.5).toFixed(2)} Bigha`;
      }
      farmer.landDetails = { ...farmer.landDetails.toObject(), ...landDetails };
    }

    if (crops && Array.isArray(crops)) {
      farmer.crops = crops;
    }

    if (defaultVehicle) {
      farmer.defaultVehicle = { ...farmer.defaultVehicle.toObject(), ...defaultVehicle };
    }

    if (bankDetails) {
      farmer.bankDetails = { ...farmer.bankDetails.toObject(), ...bankDetails };
    }

    await farmer.save();

    return successResponse(res, 200, 'Farmer profile updated successfully', farmer);
  } catch (error) {
    next(error);
  }
};

module.exports = {
  getProfile,
  updateProfile
};
