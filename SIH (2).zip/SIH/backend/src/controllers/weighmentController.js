/**
 * KisanSetu - Weighment Controller
 * Handles digital weighbridge scale inputs (Gross Weight & Empty Tare Weight).
 */

const Weighment = require('../models/Weighment');
const Booking = require('../models/Booking');
const { successResponse, errorResponse } = require('../utils/response');

/**
 * POST /api/weighment/gross
 * Record initial loaded truck weighment
 */
async function recordGrossWeight(req, res) {
  try {
    const { bookingId, grossWeightKg, weighbridgeLane = 'WB-01' } = req.body;
    if (!bookingId || !grossWeightKg) {
      return errorResponse(res, 400, 'bookingId and grossWeightKg are required.');
    }

    const booking = await Booking.findOne({
      $or: [{ bookingId: bookingId.toUpperCase() }, { _id: bookingId }]
    });

    if (!booking) {
      return errorResponse(res, 404, 'Booking not found.');
    }

    if (!['CHECKED_IN', 'CALLED', 'WAITING', 'WEIGHING'].includes(booking.status)) {
      return errorResponse(res, 400, `Cannot record gross weight in '${booking.status}' status.`);
    }

    const slipNumber = `WT-${booking.centerCode.replace(/[^A-Za-z0-9]/g, '')}-${Date.now().toString().slice(-6)}`;

    // Check if weighment record exists
    let weighment = await Weighment.findOne({ bookingId: booking._id });
    if (weighment) {
      weighment.grossWeightKg = Number(grossWeightKg);
      weighment.weighbridgeLane = weighbridgeLane;
      weighment.operatorId = req.user._id;
      await weighment.save();
    } else {
      weighment = await Weighment.create({
        weighmentSlipId: slipNumber,
        bookingId: booking._id,
        bookingCode: booking.bookingId,
        token: booking.token.displayToken,
        farmerId: booking.farmerId,
        farmerName: booking.farmerName,
        centerId: booking.centerId,
        vehicleNumber: booking.vehicle.vehicleNumber,
        grossWeightKg: Number(grossWeightKg),
        weighbridgeLane,
        operatorId: req.user._id,
        stage: 'FIRST_WEIGHT_PENDING_TARE'
      });
    }

    booking.weighmentId = weighment._id;
    booking.transitionStatus('WEIGHING', req.user._id, `Gross weight logged: ${grossWeightKg} KG at ${weighbridgeLane}`);
    await booking.save();

    return successResponse(res, 201, `Gross loaded weight recorded (${grossWeightKg} KG). Proceed to unloading bay.`, {
      weighmentSlip: weighment
    });
  } catch (err) {
    return errorResponse(res, 500, 'Error recording gross weight.', err.message);
  }
}

/**
 * POST /api/weighment/tare
 * Record empty vehicle weight after crop dump and calculate Net Quintals
 */
async function recordTareWeight(req, res) {
  try {
    const { bookingId, tareWeightKg } = req.body;
    if (!bookingId || tareWeightKg === undefined) {
      return errorResponse(res, 400, 'bookingId and tareWeightKg are required.');
    }

    const booking = await Booking.findOne({
      $or: [{ bookingId: bookingId.toUpperCase() }, { _id: bookingId }]
    });

    if (!booking) {
      return errorResponse(res, 404, 'Booking not found.');
    }

    const weighment = await Weighment.findOne({ bookingId: booking._id });
    if (!weighment) {
      return errorResponse(res, 400, 'Gross weight must be recorded first before tare weight can be measured.');
    }

    if (Number(tareWeightKg) >= weighment.grossWeightKg) {
      return errorResponse(res, 400, 'Tare weight cannot be greater than or equal to Gross loaded weight.');
    }

    weighment.tareWeightKg = Number(tareWeightKg);
    await weighment.save(); // Triggers pre-save net calculation

    booking.transitionStatus(
      'QUALITY_CHECK',
      req.user._id,
      `Tare weight logged: ${tareWeightKg} KG. Net Produce: ${weighment.netWeightQtl} Quintals (${weighment.netWeightKg} KG)`
    );
    await booking.save();

    return successResponse(res, 200, `Net weight verified: ${weighment.netWeightQtl} Quintals!`, {
      weighmentSlip: weighment
    });
  } catch (err) {
    return errorResponse(res, 500, 'Error recording tare weight.', err.message);
  }
}

/**
 * GET /api/weighment/:bookingId
 * Retrieve official weighment receipt
 */
async function getWeighmentSlip(req, res) {
  try {
    const { bookingId } = req.params;
    const isMongo = bookingId.match(/^[0-9a-fA-F]{24}$/);
    const booking = await Booking.findOne(isMongo ? { _id: bookingId } : { bookingId: bookingId.toUpperCase() });

    if (!booking) return errorResponse(res, 404, 'Booking not found.');

    const weighment = await Weighment.findOne({ bookingId: booking._id });
    if (!weighment) return errorResponse(res, 404, 'No weighment slip found for this appointment.');

    return successResponse(res, 200, 'Weighment slip retrieved.', { weighment });
  } catch (err) {
    return errorResponse(res, 500, 'Error retrieving weighment.', err.message);
  }
}

module.exports = {
  recordGrossWeight,
  recordTareWeight,
  getWeighmentSlip
};
