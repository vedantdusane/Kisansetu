/**
 * KisanSetu - Authentication Controller
 * Handles:
 * - OTP generation & dispatch (SMS / Mock)
 * - OTP verification & JWT issuance for Farmers
 * - Direct email/phone & password login for Officials & Admins
 * - Registration for all system roles
 */

const User = require('../models/User');
const Farmer = require('../models/Farmer');
const { successResponse, errorResponse } = require('../utils/response');
const config = require('../config/env');

/**
 * @desc    Send OTP to farmer's mobile number
 * @route   POST /api/auth/send-otp
 * @access  Public
 */
const sendOtp = async (req, res, next) => {
  try {
    const { phone } = req.body;

    if (!phone) {
      return errorResponse(res, 400, 'Phone number is required');
    }

    // Find existing user or prepare new farmer user
    let user = await User.findOne({ phone, role: 'FARMER' }).select('+otp.code +otp.expiresAt');

    if (!user) {
      user = new User({
        name: `Farmer (${phone.slice(-4)})`,
        phone,
        role: 'FARMER'
      });
    }

    // Generate 6-digit OTP (e.g. 849201 or deterministic demo code in demo mode)
    const generatedOtp = config.demoMode ? '849201' : Math.floor(100000 + Math.random() * 900000).toString();
    const expiresAt = new Date(Date.now() + 10 * 60 * 1000); // 10 minutes expiry

    user.otp = {
      code: generatedOtp,
      expiresAt
    };

    await user.save();

    // Log OTP for easy evaluation in SIH hackathon / local dev
    console.log(`📱 [SMS/OTP Dispatch] To: +91-${phone} | OTP: ${generatedOtp} | Expires in: 10 mins`);

    return successResponse(res, 200, 'OTP sent successfully to your mobile number', {
      phone,
      expiresIn: '10 minutes',
      demoOtp: config.demoMode ? generatedOtp : undefined
    });
  } catch (error) {
    next(error);
  }
};

/**
 * @desc    Verify OTP and log in / register farmer
 * @route   POST /api/auth/verify-otp
 * @access  Public
 */
const verifyOtp = async (req, res, next) => {
  try {
    const { phone, otp, name, preferredLanguage } = req.body;

    if (!phone || !otp) {
      return errorResponse(res, 400, 'Phone number and OTP code are required');
    }

    const user = await User.findOne({ phone, role: 'FARMER' }).select('+otp.code +otp.expiresAt');

    if (!user) {
      return errorResponse(res, 404, 'No account found with this phone number. Please request an OTP first.');
    }

    // Verify OTP code & expiration (also accept universal demo OTP '123456' / '849201' in demo mode)
    const isDemoOtp = config.demoMode && (otp === '123456' || otp === '849201');
    const isOtpValid = user.otp && user.otp.code === otp && user.otp.expiresAt > new Date();

    if (!isDemoOtp && !isOtpValid) {
      return errorResponse(res, 400, 'Invalid or expired OTP. Please enter the correct 6-digit code.');
    }

    // Clear used OTP and update login time
    user.otp = undefined;
    user.lastLogin = new Date();
    if (name && user.name.startsWith('Farmer (')) {
      user.name = name;
    }
    if (preferredLanguage) {
      user.preferredLanguage = preferredLanguage;
    }
    await user.save();

    // Ensure matching Farmer profile document exists
    let farmer = await Farmer.findOne({ userId: user._id });

    if (!farmer) {
      farmer = await Farmer.create({
        userId: user._id,
        farmerId: `KS-MP-IND-${phone.slice(-5)}`,
        name: user.name,
        mobileNumber: user.phone,
        language: user.preferredLanguage || 'hi',
        crops: [
          { name: 'Wheat', variety: 'Sharbati / Lok-1', sownAcres: 4.0, estimatedYieldQtl: 60 },
          { name: 'Soybean', variety: 'JS-9560', sownAcres: 2.5, estimatedYieldQtl: 35 }
        ]
      });
    }

    // Issue JWT token
    const token = user.generateAuthToken();

    return successResponse(res, 200, 'OTP verified successfully. Welcome to KisanSetu!', {
      token,
      user: {
        id: user._id,
        name: user.name,
        role: user.role,
        phone: user.phone,
        preferredLanguage: user.preferredLanguage
      },
      farmer: {
        id: farmer._id,
        farmerId: farmer.farmerId,
        residence: farmer.residence,
        landDetails: farmer.landDetails,
        crops: farmer.crops,
        verificationStatus: farmer.verificationStatus
      }
    });
  } catch (error) {
    next(error);
  }
};

/**
 * @desc    Universal Login using Email / Phone + Password (Officials & Admins)
 * @route   POST /api/auth/login
 * @access  Public
 */
const login = async (req, res, next) => {
  try {
    const { identifier, password, role } = req.body;

    if (!identifier || !password) {
      return errorResponse(res, 400, 'Please provide your email/phone and password');
    }

    // Search by email or phone
    const query = {
      $or: [{ email: identifier.toLowerCase().trim() }, { phone: identifier.trim() }]
    };

    if (role) {
      query.role = role;
    }

    const user = await User.findOne(query).select('+password');

    if (!user) {
      return errorResponse(res, 401, 'Invalid credentials. User not found.');
    }

    if (!user.isActive) {
      return errorResponse(res, 403, 'Your account has been deactivated. Please contact administrator.');
    }

    const isMatch = await user.matchPassword(password);
    if (!isMatch) {
      return errorResponse(res, 401, 'Invalid password. Please check your credentials.');
    }

    user.lastLogin = new Date();
    await user.save();

    const token = user.generateAuthToken();

    // Check if farmer profile exists (if role is FARMER)
    let farmerData = null;
    if (user.role === 'FARMER') {
      farmerData = await Farmer.findOne({ userId: user._id });
    }

    return successResponse(res, 200, 'Login successful. Welcome back!', {
      token,
      user: {
        id: user._id,
        name: user.name,
        role: user.role,
        email: user.email,
        phone: user.phone,
        assignedCenter: user.assignedCenter,
        assignedDistrict: user.assignedDistrict,
        preferredLanguage: user.preferredLanguage
      },
      farmer: farmerData
    });
  } catch (error) {
    next(error);
  }
};

/**
 * @desc    Register a new user (Farmer, Official, or Admin)
 * @route   POST /api/auth/register
 * @access  Public
 */
const register = async (req, res, next) => {
  try {
    const {
      name,
      role = 'FARMER',
      phone,
      email,
      password,
      assignedCenter,
      assignedDistrict,
      preferredLanguage = 'hi'
    } = req.body;

    // Check duplicate phone or email
    if (phone) {
      const existingPhone = await User.findOne({ phone, role });
      if (existingPhone) {
        return errorResponse(res, 409, `A ${role} account with phone number ${phone} already exists.`);
      }
    }

    if (email) {
      const existingEmail = await User.findOne({ email: email.toLowerCase() });
      if (existingEmail) {
        return errorResponse(res, 409, `An account with email address ${email} already exists.`);
      }
    }

    const user = await User.create({
      name,
      role,
      phone,
      email,
      password,
      assignedCenter: assignedCenter || null,
      assignedDistrict: assignedDistrict || null,
      preferredLanguage
    });

    let farmer = null;
    if (role === 'FARMER') {
      farmer = await Farmer.create({
        userId: user._id,
        farmerId: `KS-${phone ? phone.slice(-5) : Math.floor(10000 + Math.random() * 90000)}`,
        name: user.name,
        mobileNumber: user.phone || '9876543210',
        language: preferredLanguage
      });
    }

    const token = user.generateAuthToken();

    return successResponse(res, 201, 'Account created successfully', {
      token,
      user: {
        id: user._id,
        name: user.name,
        role: user.role,
        email: user.email,
        phone: user.phone,
        assignedCenter: user.assignedCenter,
        assignedDistrict: user.assignedDistrict
      },
      farmer
    });
  } catch (error) {
    next(error);
  }
};

module.exports = {
  sendOtp,
  verifyOtp,
  login,
  register
};
