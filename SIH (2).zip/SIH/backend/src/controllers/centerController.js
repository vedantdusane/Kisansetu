/**
 * KisanSetu - Procurement Center Controller
 * Manages APMC Mandi yards, storage metrics, and lane configurations.
 */

const Center = require('../models/Center');
const { successResponse, errorResponse } = require('../utils/response');

/**
 * @desc    Get all procurement centers (with optional state/district/crop filters)
 * @route   GET /api/centers
 * @access  Public / Authenticated
 */
const getCenters = async (req, res, next) => {
  try {
    const { state, district, crop, zone, active } = req.query;

    const filter = {};

    if (active !== undefined) {
      filter.active = active === 'true';
    } else {
      filter.active = true; // Return active centers by default
    }

    if (state && state !== 'All India') {
      filter.state = new RegExp(`^${state}$`, 'i');
    }

    if (district) {
      filter.district = new RegExp(`^${district}$`, 'i');
    }

    if (zone && zone !== 'All') {
      filter.zone = zone;
    }

    if (crop) {
      filter.acceptedCrops = { $in: [new RegExp(`^${crop}$`, 'i')] };
    }

    const centers = await Center.find(filter).sort({ state: 1, district: 1, name: 1 });

    return successResponse(res, 200, `Found ${centers.length} procurement center(s)`, centers);
  } catch (error) {
    next(error);
  }
};

/**
 * @desc    Get single center by ID or centerCode
 * @route   GET /api/centers/:id
 * @access  Public / Authenticated
 */
const getCenterById = async (req, res, next) => {
  try {
    const { id } = req.params;

    let center = null;

    // Check if ID is 24-character ObjectId or alphanumeric centerId (e.g. MP-IND-001)
    if (id.match(/^[0-9a-fA-F]{24}$/)) {
      center = await Center.findById(id);
    } else {
      center = await Center.findOne({ centerId: id.toUpperCase() });
    }

    if (!center) {
      return errorResponse(res, 404, `Procurement center not found with identifier: ${id}`);
    }

    return successResponse(res, 200, 'Center details retrieved successfully', center);
  } catch (error) {
    next(error);
  }
};

/**
 * @desc    Create new procurement center
 * @route   POST /api/centers
 * @access  Private (ADMIN, DISTRICT_OFFICER)
 */
const createCenter = async (req, res, next) => {
  try {
    const {
      centerId,
      name,
      district,
      state,
      zone = 'Central',
      address,
      operatingHours,
      dailyCapacity,
      acceptedCrops,
      storageCapacity,
      storageUsed,
      numberOfLanes,
      parkingBays
    } = req.body;

    const existingCenter = await Center.findOne({ centerId: centerId.toUpperCase() });
    if (existingCenter) {
      return errorResponse(res, 409, `A procurement center with code '${centerId}' already exists.`);
    }

    const center = await Center.create({
      centerId: centerId.toUpperCase(),
      name,
      district,
      state,
      zone,
      address,
      operatingHours,
      dailyCapacity,
      acceptedCrops,
      storageCapacity,
      storageUsed: storageUsed || 0,
      numberOfLanes,
      parkingBays
    });

    return successResponse(res, 201, 'Procurement center created successfully', center);
  } catch (error) {
    next(error);
  }
};

/**
 * @desc    Update procurement center details / congestion / storage
 * @route   PUT /api/centers/:id
 * @access  Private (ADMIN, DISTRICT_OFFICER, CENTER_OFFICIAL)
 */
const updateCenter = async (req, res, next) => {
  try {
    const { id } = req.params;

    const query = id.match(/^[0-9a-fA-F]{24}$/) ? { _id: id } : { centerId: id.toUpperCase() };

    const center = await Center.findOneAndUpdate(query, req.body, {
      new: true,
      runValidators: true
    });

    if (!center) {
      return errorResponse(res, 404, `Procurement center not found: ${id}`);
    }

    return successResponse(res, 200, 'Procurement center updated successfully', center);
  } catch (error) {
    next(error);
  }
};

module.exports = {
  getCenters,
  getCenterById,
  createCenter,
  updateCenter
};
