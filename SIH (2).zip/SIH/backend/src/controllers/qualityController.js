/**
 * KisanSetu - Quality Testing Controller
 * Official moisture assay, grain purity inspection, and FAQ grading.
 */

const QualityCheck = require('../models/QualityCheck');
const Booking = require('../models/Booking');
const { successResponse, errorResponse } = require('../utils/response');

/**
 * POST /api/quality/assay
 * Certified assayer records grain moisture and grading parameters
 */
async function recordQualityAssay(req, res) {
  try {
    const {
      bookingId,
      moisturePct,
      foreignMatterPct = 0.5,
      damagedGrainsPct = 1.0,
      weevilledGrainsPct = 0.0,
      remarks = ''
    } = req.body;

    if (!bookingId || moisturePct === undefined) {
      return errorResponse(res, 400, 'bookingId and moisturePct reading are required.');
    }

    const booking = await Booking.findOne({
      $or: [{ bookingId: bookingId.toUpperCase() }, { _id: bookingId }]
    });

    if (!booking) {
      return errorResponse(res, 404, 'Booking not found.');
    }

    const certId = `QC-${booking.centerCode.replace(/[^A-Za-z0-9]/g, '')}-${Date.now().toString().slice(-6)}`;
    const sampleId = `SMP-${Math.floor(100000 + Math.random() * 900000)}`;

    const qualityCheck = await QualityCheck.create({
      qcCertificateId: certId,
      bookingId: booking._id,
      bookingCode: booking.bookingId,
      token: booking.token.displayToken,
      farmerId: booking.farmerId,
      centerId: booking.centerId,
      crop: booking.crop,
      sampleId,
      moisturePct: Number(moisturePct),
      foreignMatterPct: Number(foreignMatterPct),
      damagedGrainsPct: Number(damagedGrainsPct),
      weevilledGrainsPct: Number(weevilledGrainsPct),
      assayerId: req.user._id,
      remarks
    });

    booking.qualityCheckId = qualityCheck._id;

    if (qualityCheck.status === 'APPROVED') {
      booking.transitionStatus(
        'APPROVED',
        req.user._id,
        `Quality Passed (${qualityCheck.grade}). Moisture: ${moisturePct}%. Deduction: ${qualityCheck.deductionPct}%`
      );
    } else {
      booking.transitionStatus(
        'REJECTED',
        req.user._id,
        `Quality Rejected: ${qualityCheck.rejectionReason}`
      );
    }

    await booking.save();

    return successResponse(
      res,
      201,
      qualityCheck.status === 'APPROVED'
        ? `Quality check passed! Grade: ${qualityCheck.grade}`
        : `Quality assay rejected: ${qualityCheck.rejectionReason}`,
      { certificate: qualityCheck }
    );
  } catch (err) {
    return errorResponse(res, 500, 'Error recording quality assay.', err.message);
  }
}

/**
 * GET /api/quality/:bookingId
 * Retrieve quality inspection report
 */
async function getQualityCertificate(req, res) {
  try {
    const { bookingId } = req.params;
    const isMongo = bookingId.match(/^[0-9a-fA-F]{24}$/);
    const booking = await Booking.findOne(isMongo ? { _id: bookingId } : { bookingId: bookingId.toUpperCase() });

    if (!booking) return errorResponse(res, 404, 'Booking not found.');

    const cert = await QualityCheck.findOne({ bookingId: booking._id });
    if (!cert) return errorResponse(res, 404, 'No quality inspection certificate on file for this booking.');

    return successResponse(res, 200, 'Quality certificate retrieved.', { certificate: cert });
  } catch (err) {
    return errorResponse(res, 500, 'Error retrieving quality check.', err.message);
  }
}

module.exports = {
  recordQualityAssay,
  getQualityCertificate
};
