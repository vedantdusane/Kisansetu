/**
 * KisanSetu - Booking Controller
 * HTTP request handlers for the procurement booking lifecycle.
 */

const bookingService = require('../services/bookingService');
const Booking = require('../models/Booking');
const { successResponse, errorResponse } = require('../utils/response');

/**
 * POST /api/bookings
 * Book a procurement slot for a farmer
 */
async function createBooking(req, res) {
  try {
    const booking = await bookingService.createBooking({
      user: req.user,
      bookingData: req.body
    });

    return successResponse(res, 201, 'Procurement slot booked successfully! Token generated.', {
      booking
    });
  } catch (err) {
    const status = err.statusCode || 500;
    return errorResponse(res, status, err.message);
  }
}

/**
 * GET /api/bookings
 * Fetch bookings with role-based filters and pagination
 */
async function getBookings(req, res) {
  try {
    const filters = {
      centerId: req.query.centerId,
      date: req.query.date,
      status: req.query.status,
      crop: req.query.crop
    };

    const pagination = {
      page: req.query.page,
      limit: req.query.limit
    };

    const result = await bookingService.getBookings({
      user: req.user,
      filters,
      pagination
    });

    return successResponse(res, 200, 'Bookings retrieved successfully.', result);
  } catch (err) {
    const status = err.statusCode || 500;
    return errorResponse(res, status, err.message);
  }
}

/**
 * GET /api/bookings/:id
 * Retrieve specific booking details
 */
async function getBookingById(req, res) {
  try {
    const booking = await bookingService.getBookingById(req.params.id, req.user);
    return successResponse(res, 200, 'Booking details retrieved successfully.', { booking });
  } catch (err) {
    const status = err.statusCode || 500;
    return errorResponse(res, status, err.message);
  }
}

/**
 * PATCH /api/bookings/:id/cancel
 * Cancel an active booking and release yard slot quota
 */
async function cancelBooking(req, res) {
  try {
    const reason = req.body?.reason || 'Cancelled by farmer';
    const booking = await bookingService.cancelBooking(req.params.id, req.user, reason);

    return successResponse(res, 200, 'Booking cancelled successfully. Slot quota released.', {
      booking
    });
  } catch (err) {
    const status = err.statusCode || 500;
    return errorResponse(res, status, err.message);
  }
}

/**
 * GET /api/bookings/track/:identifier
 * Public tracking endpoint for IVR / SMS / Kiosk pass lookup
 */
async function trackBooking(req, res) {
  try {
    const { identifier } = req.params;
    const isMongoId = identifier.match(/^[0-9a-fA-F]{24}$/);
    const query = isMongoId
      ? { _id: identifier }
      : {
          $or: [
            { bookingId: identifier.toUpperCase() },
            { 'token.fullTokenReference': identifier.toUpperCase() }
          ]
        };

    const booking = await Booking.findOne(query)
      .select(
        'bookingId farmerName crop date timeSlot token vehicle status statusHistory checkInTime priorityScore centerName centerCode'
      )
      .populate('centerId', 'name centerId district state');

    if (!booking) {
      return errorResponse(res, 404, 'No procurement pass found with provided token or booking reference.');
    }

    return successResponse(res, 200, 'Booking track status retrieved.', {
      tracking: {
        bookingId: booking.bookingId,
        farmerName: booking.farmerName,
        centerName: booking.centerName,
        centerCode: booking.centerCode,
        crop: booking.crop,
        date: booking.date,
        timeSlot: booking.timeSlot,
        token: booking.token.displayToken,
        status: booking.status,
        assignedLane: booking.vehicle?.assignedLane,
        assignedBay: booking.vehicle?.assignedBay,
        checkInTime: booking.checkInTime,
        statusHistory: booking.statusHistory
      }
    });
  } catch (err) {
    return errorResponse(res, 500, 'Error tracking booking.', err.message);
  }
}

module.exports = {
  createBooking,
  getBookings,
  getBookingById,
  cancelBooking,
  trackBooking
};
