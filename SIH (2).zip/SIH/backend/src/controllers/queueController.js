/**
 * KisanSetu - Queue & ETA Controller
 * HTTP handlers for real-time yard queue and farmer ETA tracking.
 */

const queueService = require('../services/queueService');
const { calculateBookingEta } = require('../services/etaService');
const { successResponse, errorResponse } = require('../utils/response');

/**
 * GET /api/queue/:centerId
 * Retrieve real-time yard queue state
 */
async function getLiveQueue(req, res) {
  try {
    const { centerId } = req.params;
    const { date } = req.query;

    const queueData = await queueService.getCenterLiveQueue(centerId, date);
    return successResponse(res, 200, 'Live yard queue retrieved successfully.', queueData);
  } catch (err) {
    const status = err.statusCode || 500;
    return errorResponse(res, status, err.message);
  }
}

/**
 * GET /api/queue/eta/:bookingId
 * Farmer live wait-time estimate
 */
async function getBookingEta(req, res) {
  try {
    const { bookingId } = req.params;
    const etaData = await calculateBookingEta(bookingId);

    return successResponse(res, 200, 'Live ETA calculated.', etaData);
  } catch (err) {
    const status = err.statusCode || 500;
    return errorResponse(res, status, err.message);
  }
}

/**
 * POST /api/queue/call-next
 * Yard Marshal calls next vehicle in waiting line to an assigned bay
 */
async function callNext(req, res) {
  try {
    const { centerId, lane, targetBay = 'BAY-01' } = req.body;
    if (!centerId) {
      return errorResponse(res, 400, 'centerId is required.');
    }

    const calledBooking = await queueService.callNextVehicle({
      centerId,
      officerUserId: req.user._id,
      lane,
      targetBay
    });

    return successResponse(
      res,
      200,
      `Token ${calledBooking.token.displayToken} called to ${targetBay}!`,
      {
        bookingId: calledBooking.bookingId,
        token: calledBooking.token.displayToken,
        farmerName: calledBooking.farmerName,
        assignedBay: calledBooking.vehicle.assignedBay,
        assignedLane: calledBooking.vehicle.assignedLane,
        status: calledBooking.status
      }
    );
  } catch (err) {
    const status = err.statusCode || 500;
    return errorResponse(res, status, err.message);
  }
}

/**
 * POST /api/queue/advance
 * Manually advance vehicle to WEIGHING or QUALITY_CHECK
 */
async function advanceStage(req, res) {
  try {
    const { bookingId, targetStatus, remarks } = req.body;
    if (!bookingId || !targetStatus) {
      return errorResponse(res, 400, 'bookingId and targetStatus are required.');
    }

    const updatedBooking = await queueService.advanceBookingStage(
      bookingId,
      targetStatus,
      req.user._id,
      remarks
    );

    return successResponse(
      res,
      200,
      `Booking ${updatedBooking.bookingId} advanced to ${targetStatus}.`,
      { booking: updatedBooking }
    );
  } catch (err) {
    const status = err.statusCode || 500;
    return errorResponse(res, status, err.message);
  }
}

module.exports = {
  getLiveQueue,
  getBookingEta,
  callNext,
  advanceStage
};
