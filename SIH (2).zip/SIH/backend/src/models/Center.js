/**
 * KisanSetu - Procurement Center (APMC Mandi) Model
 * Represents physical agricultural market yards across India.
 * Tracks location, daily quota, crop acceptance, vehicle lanes, and storage saturation.
 */

const mongoose = require('mongoose');

const centerSchema = new mongoose.Schema(
  {
    centerId: {
      type: String,
      required: [true, 'Center ID is required'],
      unique: true,
      trim: true,
      uppercase: true,
      index: true // e.g. MP-IND-001, MH-NSK-002
    },
    name: {
      type: String,
      required: [true, 'Center name is required'],
      trim: true
    },
    district: {
      type: String,
      required: [true, 'District is required'],
      trim: true,
      index: true
    },
    state: {
      type: String,
      required: [true, 'State is required'],
      trim: true,
      index: true
    },
    zone: {
      type: String,
      enum: ['North', 'West', 'Central', 'South', 'East'],
      default: 'Central',
      index: true
    },
    address: {
      type: String,
      required: [true, 'Center physical address is required']
    },
    location: {
      latitude: { type: Number, default: 22.7196 },
      longitude: { type: Number, default: 75.8577 }
    },
    operatingHours: {
      openTime: { type: String, default: '08:00 AM' },
      closeTime: { type: String, default: '06:00 PM' }
    },
    dailyCapacity: {
      type: Number,
      default: 250, // max vehicles per day
      min: 10
    },
    acceptedCrops: {
      type: [String],
      default: ['Wheat', 'Soybean', 'Chana', 'Mustard'],
      index: true
    },
    active: {
      type: Boolean,
      default: true,
      index: true
    },
    storageCapacity: {
      type: Number,
      default: 25000, // Metric Tonnes (MT)
      min: 100
    },
    storageUsed: {
      type: Number,
      default: 11000, // MT currently utilized
      min: 0
    },
    numberOfLanes: {
      type: Number,
      default: 4, // Weighing & inspection lanes
      min: 1
    },
    parkingBays: {
      total: { type: Number, default: 50 },
      occupied: { type: Number, default: 12 }
    },
    congestionLevel: {
      type: String,
      enum: ['LOW', 'MODERATE', 'HIGH', 'CRITICAL'],
      default: 'LOW',
      index: true
    },
    averageWaitMins: {
      type: Number,
      default: 20
    }
  },
  {
    timestamps: true,
    toJSON: { virtuals: true },
    toObject: { virtuals: true }
  }
);

// Virtual: Available godown capacity in MT
centerSchema.virtual('storageAvailable').get(function () {
  return Math.max(0, this.storageCapacity - this.storageUsed);
});

// Virtual: Storage saturation percentage
centerSchema.virtual('storageSaturationPct').get(function () {
  if (!this.storageCapacity || this.storageCapacity <= 0) return 0;
  return Math.round((this.storageUsed / this.storageCapacity) * 100);
});

// Compound indexes for fast geo/state queries
centerSchema.index({ state: 1, district: 1, active: 1 });
centerSchema.index({ acceptedCrops: 1, active: 1 });

const Center = mongoose.model('Center', centerSchema);

module.exports = Center;
