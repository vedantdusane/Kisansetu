/**
 * KisanSetu - Quality Testing / Moisture Assay Model
 * Enforces official Government Fair Average Quality (FAQ) parameters.
 */

const mongoose = require('mongoose');

const qualityCheckSchema = new mongoose.Schema(
  {
    qcCertificateId: {
      type: String,
      required: true,
      unique: true,
      trim: true,
      uppercase: true,
      index: true
    },
    bookingId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Booking',
      required: true,
      index: true
    },
    bookingCode: {
      type: String,
      required: true
    },
    token: {
      type: String,
      required: true
    },
    farmerId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Farmer',
      required: true
    },
    centerId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Center',
      required: true
    },
    crop: {
      type: String,
      required: true
    },
    sampleId: {
      type: String,
      required: true
    },
    moisturePct: {
      type: Number,
      required: [true, 'Moisture percentage reading is required'],
      min: 0,
      max: 100
    },
    foreignMatterPct: {
      type: Number,
      default: 0.5,
      min: 0,
      max: 100
    },
    damagedGrainsPct: {
      type: Number,
      default: 1.0,
      min: 0,
      max: 100
    },
    weevilledGrainsPct: {
      type: Number,
      default: 0.0,
      min: 0,
      max: 100
    },
    grade: {
      type: String,
      enum: ['GRADE_A_PREMIUM', 'FAQ_STANDARD', 'BELOW_FAQ_REJECTED'],
      default: 'FAQ_STANDARD'
    },
    status: {
      type: String,
      enum: ['APPROVED', 'REJECTED'],
      default: 'APPROVED'
    },
    rejectionReason: {
      type: String
    },
    deductionPct: {
      type: Number,
      default: 0
    },
    assayerId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User'
    },
    remarks: {
      type: String
    }
  },
  {
    timestamps: true
  }
);

// Pre-save FAQ Auto-Grading Hook
qualityCheckSchema.pre('save', function (next) {
  // Government FAQ Moisture Limit is 12% for Wheat & Soybean, 14% for Paddy
  const maxMoisture = this.crop.toLowerCase().includes('paddy') ? 14.0 : 12.0;

  if (this.moisturePct > maxMoisture + 2.0) {
    // Excessive moisture >14% (Wheat) or >16% (Paddy) -> Auto-Reject
    this.status = 'REJECTED';
    this.grade = 'BELOW_FAQ_REJECTED';
    this.rejectionReason = `Moisture ${this.moisturePct}% exceeds maximum permissible threshold of ${maxMoisture}%`;
    this.deductionPct = 0;
  } else if (this.moisturePct > maxMoisture) {
    // Minor moisture elevation (12.1% - 14.0%) -> Conditional approval with proportional value deduction
    this.status = 'APPROVED';
    this.grade = 'FAQ_STANDARD';
    this.deductionPct = parseFloat((this.moisturePct - maxMoisture).toFixed(2));
    this.rejectionReason = null;
  } else {
    // Premium Grade A
    this.status = 'APPROVED';
    this.grade = 'GRADE_A_PREMIUM';
    this.deductionPct = 0;
    this.rejectionReason = null;
  }

  next();
});

const QualityCheck = mongoose.model('QualityCheck', qualityCheckSchema);

module.exports = QualityCheck;
