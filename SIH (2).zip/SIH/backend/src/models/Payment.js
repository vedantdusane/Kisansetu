/**
 * KisanSetu - Direct Benefit Transfer (DBT) Payment Model
 * Tracks Aadhaar Payment Bridge (APB) / PFMS digital bank transfers to farmers.
 */

const mongoose = require('mongoose');

const paymentSchema = new mongoose.Schema(
  {
    dbtReferenceId: {
      type: String,
      required: true,
      unique: true,
      trim: true,
      uppercase: true,
      index: true // e.g. DBT-20260915-774921
    },
    billId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Bill',
      required: true,
      index: true
    },
    bookingId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Booking',
      required: true
    },
    farmerId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Farmer',
      required: true
    },
    amount: {
      type: Number,
      required: true,
      min: 1
    },
    beneficiary: {
      accountHolderName: { type: String, required: true },
      bankName: { type: String, default: 'State Bank of India' },
      accountNumberMasked: { type: String, default: 'XXXXXX5892' },
      ifscCode: { type: String, default: 'SBIN0001234' },
      aadhaarLinked: { type: Boolean, default: true }
    },
    paymentGateway: {
      type: String,
      enum: ['PFMS_AADHAAR_BRIDGE', 'NPCI_NACH', 'RBI_NEFT_DIRECT'],
      default: 'PFMS_AADHAAR_BRIDGE'
    },
    status: {
      type: String,
      enum: [
        'INITIATED',
        'PFMS_VERIFIED',
        'RBI_CLEARING',
        'BANK_CREDITED',
        'FAILED'
      ],
      default: 'INITIATED',
      index: true
    },
    utrNumber: {
      type: String,
      trim: true,
      uppercase: true
    },
    failureReason: {
      type: String
    },
    initiatedAt: {
      type: Date,
      default: Date.now
    },
    creditedAt: {
      type: Date
    }
  },
  {
    timestamps: true
  }
);

const Payment = mongoose.model('Payment', paymentSchema);

module.exports = Payment;
