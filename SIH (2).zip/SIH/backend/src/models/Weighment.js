/**
 * KisanSetu - Mandi Weighment Model
 * Digital Gross & Tare weight slips from electronic weighbridges.
 */

const mongoose = require('mongoose');

const weighmentSchema = new mongoose.Schema(
  {
    weighmentSlipId: {
      type: String,
      required: true,
      unique: true,
      trim: true,
      uppercase: true,
      index: true
    },
    bookingId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Booking',
      required: true,
      index: true
    },
    bookingCode: {
      type: String,
      required: true
    },
    token: {
      type: String,
      required: true
    },
    farmerId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Farmer',
      required: true
    },
    farmerName: {
      type: String,
      required: true
    },
    centerId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Center',
      required: true,
      index: true
    },
    vehicleNumber: {
      type: String,
      required: true,
      uppercase: true
    },
    grossWeightKg: {
      type: Number,
      required: [true, 'Gross loaded vehicle weight in KG is required'],
      min: 0
    },
    tareWeightKg: {
      type: Number,
      default: 0,
      min: 0
    },
    netWeightKg: {
      type: Number,
      default: 0
    },
    netWeightQtl: {
      type: Number,
      default: 0
    },
    weighbridgeLane: {
      type: String,
      default: 'WEIGHBRIDGE-01'
    },
    stage: {
      type: String,
      enum: ['FIRST_WEIGHT_PENDING_TARE', 'COMPLETED'],
      default: 'FIRST_WEIGHT_PENDING_TARE'
    },
    operatorId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User'
    },
    remarks: {
      type: String
    }
  },
  {
    timestamps: true
  }
);

// Pre-save calculation hook: Compute Net Weight automatically
weighmentSchema.pre('save', function (next) {
  if (this.grossWeightKg && this.tareWeightKg && this.tareWeightKg > 0) {
    this.netWeightKg = Math.max(0, this.grossWeightKg - this.tareWeightKg);
    this.netWeightQtl = parseFloat((this.netWeightKg / 100).toFixed(2));
    this.stage = 'COMPLETED';
  } else {
    this.netWeightKg = 0;
    this.netWeightQtl = 0;
  }
  next();
});

const Weighment = mongoose.model('Weighment', weighmentSchema);

module.exports = Weighment;
