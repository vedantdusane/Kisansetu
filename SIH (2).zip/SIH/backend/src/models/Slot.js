/**
 * KisanSetu - Slot Model
 * Time-window reservations per Mandi Center and Date.
 * Enforces hard capacity constraints to prevent APMC overbooking and yard choke.
 */

const mongoose = require('mongoose');

const slotSchema = new mongoose.Schema(
  {
    slotId: {
      type: String,
      unique: true,
      index: true,
      default: function () {
        const cleanTime = (this.startTime || '').replace(/[^a-zA-Z0-9]/g, '');
        return `SLOT-${this.centerCode || 'C'}-${this.date || 'D'}-${cleanTime}`;
      }
    },
    centerId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Center',
      required: [true, 'Center reference is required'],
      index: true
    },
    centerCode: {
      type: String,
      required: true,
      uppercase: true,
      trim: true
    },
    date: {
      type: String, // Format: YYYY-MM-DD (e.g. 2026-09-15)
      required: [true, 'Slot date is required (YYYY-MM-DD)'],
      index: true
    },
    startTime: {
      type: String, // e.g. "10:00 AM" or "10:00"
      required: [true, 'Slot start time is required']
    },
    endTime: {
      type: String, // e.g. "11:00 AM" or "11:00"
      required: [true, 'Slot end time is required']
    },
    maxBookings: {
      type: Number,
      default: 30,
      min: [1, 'Slot capacity must be at least 1']
    },
    currentBookings: {
      type: Number,
      default: 0,
      min: 0
    },
    status: {
      type: String,
      enum: ['AVAILABLE', 'FULL', 'CLOSED'],
      default: 'AVAILABLE',
      index: true
    },
    isBlocked: {
      type: Boolean,
      default: false
    }
  },
  {
    timestamps: true,
    toJSON: { virtuals: true },
    toObject: { virtuals: true }
  }
);

// Virtual: Available remaining capacity
slotSchema.virtual('availableSeats').get(function () {
  return Math.max(0, this.maxBookings - this.currentBookings);
});

// Pre-save hook: auto-generate deterministic slotId and update status
slotSchema.pre('save', function (next) {
  if (!this.slotId) {
    const cleanTime = this.startTime.replace(/[^a-zA-Z0-9]/g, '');
    this.slotId = `SLOT-${this.centerCode}-${this.date}-${cleanTime}`;
  }

  // Auto-transition status based on capacity or block flag
  if (this.isBlocked) {
    this.status = 'CLOSED';
  } else if (this.currentBookings >= this.maxBookings) {
    this.status = 'FULL';
  } else {
    this.status = 'AVAILABLE';
  }

  next();
});

// Compound Unique Index: Strictly prevents duplicate time slots for the same center on the same day
slotSchema.index({ centerId: 1, date: 1, startTime: 1 }, { unique: true });
slotSchema.index({ centerCode: 1, date: 1, status: 1 });

const Slot = mongoose.model('Slot', slotSchema);

module.exports = Slot;
