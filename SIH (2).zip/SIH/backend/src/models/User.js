/**
 * KisanSetu - User Model (Universal Authentication Collection)
 * Supports:
 * - Farmers (Phone + OTP or Password)
 * - Mandi Center Officials (Center assignment + Email/Username + Password)
 * - District Officers (District division scope + Email + Password)
 * - System Admins (Full authority)
 */

const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const config = require('../config/env');

const userSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: [true, 'Name is required'],
      trim: true,
      maxlength: [100, 'Name cannot exceed 100 characters']
    },
    role: {
      type: String,
      enum: {
        values: [
          'FARMER',
          'CENTER_OFFICIAL',
          'MANDI_OFFICER',
          'GATE_OPERATOR',
          'DISTRICT_OFFICER',
          'ADMIN'
        ],
        message: 'Invalid user role: {VALUE}'
      },
      default: 'FARMER',
      required: true,
      index: true
    },
    phone: {
      type: String,
      trim: true,
      match: [/^[6-9]\d{9}$/, 'Please provide a valid 10-digit Indian mobile number']
    },
    email: {
      type: String,
      trim: true,
      lowercase: true,
      match: [/^\S+@\S+\.\S+$/, 'Please provide a valid email address']
    },
    password: {
      type: String,
      minlength: [6, 'Password must be at least 6 characters long'],
      select: false // Never return password in queries unless explicitly requested
    },
    // Center assignment for CENTER_OFFICIAL
    assignedCenter: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Center',
      default: null
    },
    // District jurisdiction for DISTRICT_OFFICER
    assignedDistrict: {
      type: String,
      trim: true,
      default: null
    },
    // OTP verification store
    otp: {
      code: { type: String, select: false },
      expiresAt: { type: Date, select: false }
    },
    preferredLanguage: {
      type: String,
      enum: ['en', 'hi', 'mr', 'pa', 'gu', 'bn', 'ta'],
      default: 'hi'
    },
    isActive: {
      type: Boolean,
      default: true
    },
    lastLogin: {
      type: Date
    }
  },
  {
    timestamps: true
  }
);

// Compound indexes for clean unique phone or unique email lookups
userSchema.index({ phone: 1, role: 1 }, { unique: true, sparse: true });
userSchema.index({ email: 1 }, { unique: true, sparse: true });

// Pre-save hook: Hash password with bcrypt before saving
userSchema.pre('save', async function (next) {
  if (!this.isModified('password') || !this.password) {
    return next();
  }

  const salt = await bcrypt.genSalt(10);
  this.password = await bcrypt.hash(this.password, salt);
  next();
});

// Instance method: Verify entered password against hash
userSchema.methods.matchPassword = async function (enteredPassword) {
  if (!this.password) return false;
  return bcrypt.compare(enteredPassword, this.password);
};

// Instance method: Generate signed JWT containing userId, role, name
userSchema.methods.generateAuthToken = function () {
  return jwt.sign(
    {
      id: this._id,
      name: this.name,
      role: this.role,
      phone: this.phone,
      email: this.email,
      assignedCenter: this.assignedCenter,
      assignedDistrict: this.assignedDistrict,
      preferredLanguage: this.preferredLanguage
    },
    config.jwt.secret,
    {
      expiresIn: config.jwt.expiresIn
    }
  );
};

const User = mongoose.model('User', userSchema);

module.exports = User;
