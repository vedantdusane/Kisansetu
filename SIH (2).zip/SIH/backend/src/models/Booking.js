/**
 * KisanSetu - Core Procurement Booking Model
 * Enforces the 13-stage procurement state machine:
 * BOOKED -> CHECKED_IN -> WAITING -> CALLED -> WEIGHING -> QUALITY_CHECK ->
 * APPROVED -> BILL_GENERATED -> PAYMENT_PENDING -> PAYMENT_PROCESSING -> COMPLETED
 * (or CANCELLED / REJECTED)
 */

const mongoose = require('mongoose');

const bookingSchema = new mongoose.Schema(
  {
    bookingId: {
      type: String,
      required: true,
      unique: true,
      trim: true,
      uppercase: true,
      index: true // e.g. BK-MPIND001-20260915-A023
    },
    farmerId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Farmer',
      required: [true, 'Farmer reference is required'],
      index: true
    },
    farmerName: {
      type: String,
      required: true,
      trim: true
    },
    farmerPhone: {
      type: String,
      required: true,
      trim: true,
      index: true
    },
    centerId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Center',
      required: [true, 'Center reference is required'],
      index: true
    },
    centerCode: {
      type: String,
      required: true,
      uppercase: true,
      trim: true
    },
    centerName: {
      type: String,
      required: true
    },
    slotId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Slot',
      required: [true, 'Slot reference is required'],
      index: true
    },
    crop: {
      type: String,
      required: [true, 'Crop type is required'],
      trim: true // e.g. Wheat, Soybean, Chana
    },
    expectedQuantityQtl: {
      type: Number,
      required: [true, 'Expected quantity in quintals is required'],
      min: [1, 'Quantity must be at least 1 Quintal']
    },
    vehicle: {
      vehicleType: {
        type: String,
        enum: [
          'TRACTOR_TROLLEY',
          'PICKUP',
          'MINI_TRUCK',
          'SIX_WHEELER',
          'BULLOCK_CART',
          'OTHER'
        ],
        default: 'TRACTOR_TROLLEY'
      },
      vehicleNumber: {
        type: String,
        trim: true,
        uppercase: true,
        default: 'MP-09-AB-1234'
      },
      assignedLane: {
        type: String,
        default: 'LANE_1_TRACTOR'
      },
      assignedBay: {
        type: String,
        default: 'BAY-01'
      }
    },
    date: {
      type: String, // Format: YYYY-MM-DD
      required: true,
      index: true
    },
    timeSlot: {
      type: String, // e.g. "10:00 AM - 11:00 AM"
      required: true
    },
    token: {
      displayToken: {
        type: String,
        required: true,
        trim: true,
        uppercase: true // e.g. "A023"
      },
      sequenceNumber: {
        type: Number,
        required: true
      },
      fullTokenReference: {
        type: String,
        required: true // e.g. "MP-IND-001-2026-09-15-A023"
      }
    },
    qrCode: {
      qrPayload: {
        type: String,
        required: true // Secure tamper-proof verification hash
      },
      qrImageBase64: {
        type: String // Offline data URI for instant pass rendering
      }
    },
    status: {
      type: String,
      enum: {
        values: [
          'BOOKED',
          'CHECKED_IN',
          'WAITING',
          'CALLED',
          'WEIGHING',
          'QUALITY_CHECK',
          'APPROVED',
          'BILL_GENERATED',
          'PAYMENT_PENDING',
          'PAYMENT_PROCESSING',
          'COMPLETED',
          'CANCELLED',
          'REJECTED'
        ],
        message: 'Invalid procurement status: {VALUE}'
      },
      default: 'BOOKED',
      index: true
    },
    statusHistory: [
      {
        status: { type: String, required: true },
        timestamp: { type: Date, default: Date.now },
        updatedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
        remarks: { type: String }
      }
    ],
    priorityScore: {
      type: Number,
      default: 100 // Managed by fair-share scheduling service
    },
    checkInTime: {
      type: Date
    },
    weighmentId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Weighment'
    },
    qualityCheckId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'QualityCheck'
    },
    billId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Bill'
    },
    paymentId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Payment'
    },
    cancellationReason: {
      type: String
    }
  },
  {
    timestamps: true
  }
);

// Method: Record verified status transition with audit history
bookingSchema.methods.transitionStatus = function (newStatus, updatedByUserId = null, remarks = '') {
  this.status = newStatus;
  this.statusHistory.push({
    status: newStatus,
    timestamp: new Date(),
    updatedBy: updatedByUserId,
    remarks: remarks || `Transitioned to ${newStatus}`
  });

  if (newStatus === 'CHECKED_IN' && !this.checkInTime) {
    this.checkInTime = new Date();
  }

  return this;
};

// Compound unique token index: Prevents two farmers having token A023 for the same center on the same day
bookingSchema.index({ centerId: 1, date: 1, 'token.displayToken': 1 }, { unique: true });

// Anti-duplicate active booking index
bookingSchema.index({ farmerId: 1, centerId: 1, date: 1, crop: 1, status: 1 });

const Booking = mongoose.model('Booking', bookingSchema);

module.exports = Booking;
