/**
 * KisanSetu - Mandi Procurement Bill Model
 * Calculates official MSP disbursements, moisture grade deductions, and net payable value.
 */

const mongoose = require('mongoose');

// Official Government Minimum Support Price (MSP) Registry (₹ / Quintal)
const GOV_MSP_RATES = {
  Wheat: 2275,
  Soybean: 4892,
  Chana: 5440,
  Mustard: 5650,
  Paddy: 2300,
  'Paddy (Common)': 2300,
  'Paddy (Grade A)': 2320,
  Maize: 2090,
  Moong: 8558,
  Tur: 7550,
  Urad: 7400,
  Onion: 2100,
  DEFAULT: 2275
};

const billSchema = new mongoose.Schema(
  {
    billNumber: {
      type: String,
      required: true,
      unique: true,
      trim: true,
      uppercase: true,
      index: true
    },
    bookingId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Booking',
      required: true,
      index: true
    },
    bookingCode: {
      type: String,
      required: true
    },
    token: {
      type: String,
      required: true
    },
    farmerId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Farmer',
      required: true
    },
    farmerName: {
      type: String,
      required: true
    },
    farmerPhone: {
      type: String,
      required: true
    },
    centerId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Center',
      required: true
    },
    crop: {
      type: String,
      required: true
    },
    netQuantityQtl: {
      type: Number,
      required: true,
      min: 0.1
    },
    mspRatePerQtl: {
      type: Number,
      required: true
    },
    grossAmount: {
      type: Number,
      required: true
    },
    qualityDeductionPct: {
      type: Number,
      default: 0
    },
    qualityDeductionAmount: {
      type: Number,
      default: 0
    },
    mandiCessAmount: {
      type: Number,
      default: 0 // In APMC MSP procurement, government covers cess
    },
    netPayableAmount: {
      type: Number,
      required: true
    },
    status: {
      type: String,
      enum: ['GENERATED', 'PAYMENT_PENDING', 'PAYMENT_PROCESSING', 'SETTLED'],
      default: 'GENERATED'
    },
    generatedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User'
    }
  },
  {
    timestamps: true
  }
);

// Calculation Helper
billSchema.statics.calculateBill = function ({ crop, netQuantityQtl, qualityDeductionPct = 0 }) {
  const mspRate = GOV_MSP_RATES[crop] || GOV_MSP_RATES.DEFAULT;
  const gross = parseFloat((netQuantityQtl * mspRate).toFixed(2));
  const deduction = parseFloat(((gross * qualityDeductionPct) / 100).toFixed(2));
  const netPayable = parseFloat((gross - deduction).toFixed(2));

  return {
    mspRatePerQtl: mspRate,
    grossAmount: gross,
    qualityDeductionAmount: deduction,
    netPayableAmount: netPayable
  };
};

const Bill = mongoose.model('Bill', billSchema);

module.exports = { Bill, GOV_MSP_RATES };
