/**
 * KisanSetu - Mandi Yard Queue Management Service
 * Controls vehicle sequencing, lane prioritization, and stage dispatching.
 */

const Booking = require('../models/Booking');
const { calculateBookingEta } = require('./etaService');

/**
 * Fetch full real-time yard queue state for an APMC Mandi
 */
async function getCenterLiveQueue(centerId, date) {
  const targetDate = date || new Date().toISOString().split('T')[0];

  const [activeQueue, calledList, inProgressList, completedTodayCount] = await Promise.all([
    // In waiting yard
    Booking.find({
      centerId,
      date: targetDate,
      status: { $in: ['CHECKED_IN', 'WAITING'] }
    })
      .select('bookingId token farmerName crop vehicle expectedQuantityQtl status checkInTime priorityScore')
      .sort({ priorityScore: -1, checkInTime: 1 }),

    // Currently called to bays
    Booking.find({
      centerId,
      date: targetDate,
      status: 'CALLED'
    }).select('bookingId token farmerName crop vehicle checkInTime'),

    // In weighment or QC
    Booking.find({
      centerId,
      date: targetDate,
      status: { $in: ['WEIGHING', 'QUALITY_CHECK'] }
    }).select('bookingId token farmerName crop vehicle status checkInTime'),

    // Finished today
    Booking.countDocuments({
      centerId,
      date: targetDate,
      status: { $in: ['APPROVED', 'BILL_GENERATED', 'COMPLETED'] }
    })
  ]);

  // Aggregate lane counts
  const laneCounts = {
    LANE_1_TRACTOR: 0,
    LANE_2_LIGHT_TRUCK: 0,
    LANE_3_HEAVY_TRUCK: 0,
    LANE_4_TRADITIONAL: 0,
    OTHER: 0
  };

  activeQueue.forEach((item) => {
    const lane = item.vehicle?.assignedLane || 'LANE_1_TRACTOR';
    if (laneCounts[lane] !== undefined) {
      laneCounts[lane]++;
    } else {
      laneCounts.OTHER++;
    }
  });

  return {
    date: targetDate,
    summary: {
      totalWaiting: activeQueue.length,
      currentlyCalled: calledList.length,
      underProcessing: inProgressList.length,
      completedToday: completedTodayCount,
      laneCounts
    },
    calledVehicles: calledList,
    inProgressVehicles: inProgressList,
    waitingQueue: activeQueue
  };
}

/**
 * Call the next vehicle in line to proceed to an active weighbridge bay
 */
async function callNextVehicle({ centerId, officerUserId, lane, targetBay = 'BAY-01' }) {
  const today = new Date().toISOString().split('T')[0];

  const query = {
    centerId,
    date: today,
    status: { $in: ['CHECKED_IN', 'WAITING'] }
  };

  if (lane) {
    query['vehicle.assignedLane'] = lane;
  }

  // Pick next vehicle with highest priority, then earliest checkInTime
  const nextBooking = await Booking.findOne(query).sort({ priorityScore: -1, checkInTime: 1 });

  if (!nextBooking) {
    const error = new Error(`No waiting vehicles available in queue${lane ? ` for ${lane}` : ''}.`);
    error.statusCode = 404;
    throw error;
  }

  nextBooking.vehicle.assignedBay = targetBay;
  nextBooking.transitionStatus('CALLED', officerUserId, `Called to ${targetBay} by Yard Marshal`);
  await nextBooking.save();

  return nextBooking;
}

/**
 * Dispatch booking forward along the 13-stage pipeline
 */
async function advanceBookingStage(bookingId, targetStatus, officerUserId, remarks = '') {
  const booking = await Booking.findOne({
    $or: [{ bookingId: bookingId.toUpperCase() }, { _id: bookingId }]
  });

  if (!booking) {
    const error = new Error('Booking not found.');
    error.statusCode = 404;
    throw error;
  }

  booking.transitionStatus(targetStatus, officerUserId, remarks);
  await booking.save();

  return booking;
}

module.exports = {
  getCenterLiveQueue,
  callNextVehicle,
  advanceBookingStage
};
