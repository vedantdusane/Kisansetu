/**
 * KisanSetu - QR Code Generation & Verification Service
 * Produces cryptographic, tamper-proof QR code payloads and offline Data URIs
 * for gate scanning and paper printouts.
 */

const QRCode = require('qrcode');
const crypto = require('crypto');
const config = require('../config/env');

/**
 * Generate HMAC SHA256 signature for the pass payload
 */
function createPayloadSignature(bookingId, centerCode, date, displayToken) {
  return crypto
    .createHmac('sha256', config.jwt.secret)
    .update(`${bookingId}:${centerCode}:${date}:${displayToken}`)
    .digest('hex')
    .substring(0, 16)
    .toUpperCase();
}

/**
 * Generate standardized tamper-proof payload string
 * Format: KISANSETU:<centerCode>:<date>:<displayToken>:<signature>
 */
function buildQrPayload({ bookingId, centerCode, date, displayToken }) {
  const signature = createPayloadSignature(bookingId, centerCode, date, displayToken);
  return `KISANSETU:${centerCode}:${date}:${displayToken}:${signature}`;
}

/**
 * Verify cryptographic validity of scanned QR string
 */
function verifyQrPayload(rawPayload, bookingId) {
  if (!rawPayload || !rawPayload.startsWith('KISANSETU:')) {
    return { isValid: false, reason: 'Invalid KisanSetu QR structure' };
  }

  const parts = rawPayload.split(':');
  if (parts.length < 5) {
    return { isValid: false, reason: 'Incomplete QR data segments' };
  }

  const [, centerCode, date, displayToken, signature] = parts;
  const expectedSignature = createPayloadSignature(bookingId, centerCode, date, displayToken);

  if (signature !== expectedSignature) {
    return { isValid: false, reason: 'QR signature mismatch! Possible forged or altered gate pass.' };
  }

  return {
    isValid: true,
    data: { centerCode, date, displayToken }
  };
}

/**
 * Generate Base64 Data URI PNG for offline rendering on Farmer App or printouts
 */
async function generateQrDataUri(payloadText) {
  try {
    return await QRCode.toDataURL(payloadText, {
      errorCorrectionLevel: 'H',
      type: 'image/png',
      quality: 0.95,
      margin: 2,
      color: {
        dark: '#14532d', // Forest green matching brand theme
        light: '#ffffff'
      },
      width: 320
    });
  } catch (err) {
    console.error('Error generating QR Data URI:', err);
    return null;
  }
}

/**
 * Generate SVG string for high-resolution vector printout
 */
async function generateQrSvg(payloadText) {
  try {
    return await QRCode.toString(payloadText, {
      type: 'svg',
      margin: 1,
      color: {
        dark: '#14532d',
        light: '#ffffff'
      }
    });
  } catch (err) {
    console.error('Error generating QR SVG:', err);
    return null;
  }
}

module.exports = {
  buildQrPayload,
  verifyQrPayload,
  generateQrDataUri,
  generateQrSvg
};
