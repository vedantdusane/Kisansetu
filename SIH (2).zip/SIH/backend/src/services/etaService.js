/**
 * KisanSetu - Smart Live ETA Calculation Engine
 * Estimates queue wait times based on:
 * - Specific vehicle category intake speed
 * - Number of active weighbridge bays operating
 * - Real-time mandi storage saturation slowdown factor
 */

const Booking = require('../models/Booking');
const Center = require('../models/Center');

// Standard average weighment and QC processing minutes by vehicle class
const VEHICLE_PROCESSING_TIME_MINS = {
  TRACTOR_TROLLEY: 7,
  PICKUP: 5,
  MINI_TRUCK: 5,
  SIX_WHEELER: 10,
  BULLOCK_CART: 4,
  OTHER: 6
};

/**
 * Calculate dynamic live ETA for a specific booking
 */
async function calculateBookingEta(bookingId) {
  const booking = await Booking.findOne({ bookingId });
  if (!booking) {
    return { etaMinutes: 0, statusMessage: 'Booking not found' };
  }

  // If already at or past weighing
  if (['WEIGHING', 'QUALITY_CHECK', 'APPROVED', 'BILL_GENERATED', 'COMPLETED'].includes(booking.status)) {
    return {
      etaMinutes: 0,
      aheadCount: 0,
      statusMessage: `Vehicle is currently undergoing ${booking.status.replace(/_/g, ' ')}`
    };
  }

  if (booking.status === 'CALLED') {
    return {
      etaMinutes: 1,
      aheadCount: 0,
      statusMessage: `Your token has been CALLED! Proceed immediately to ${booking.vehicle.assignedBay || 'Gate Bay'}.`
    };
  }

  if (booking.status === 'BOOKED') {
    return {
      etaMinutes: null,
      aheadCount: 0,
      statusMessage: 'Appointment scheduled. Please arrive at the APMC gate during your assigned time window.'
    };
  }

  // Count vehicles checked in ahead of this booking in the same center today
  const aheadBookings = await Booking.find({
    centerId: booking.centerId,
    date: booking.date,
    status: { $in: ['CHECKED_IN', 'WAITING'] },
    checkInTime: { $lt: booking.checkInTime || new Date() }
  }).select('vehicle expectedQuantityQtl');

  const aheadCount = aheadBookings.length;

  // Retrieve Mandi operational parameters
  const center = await Center.findById(booking.centerId);
  const activeBays = (center?.gates && center.gates.length > 0) ? center.gates.length : 3;

  // Sum processing times of preceding vehicles
  let rawWaitMinutes = 0;
  aheadBookings.forEach((v) => {
    const vType = v.vehicle?.vehicleType || 'TRACTOR_TROLLEY';
    rawWaitMinutes += VEHICLE_PROCESSING_TIME_MINS[vType] || 6;
  });

  // Divide by parallel operational weighment bays
  let estimatedWait = Math.ceil(rawWaitMinutes / Math.max(1, activeBays));

  // Congestion multiplier if yard storage is near full (>80%)
  if (center && center.storageSaturationPct > 80) {
    estimatedWait = Math.ceil(estimatedWait * 1.25); // +25% delay due to godown stacking bottlenecks
  }

  // Minimum floor if vehicles are ahead
  if (aheadCount > 0 && estimatedWait < 3) {
    estimatedWait = 3;
  }

  return {
    etaMinutes: estimatedWait,
    aheadCount,
    estimatedTurnTime: new Date(Date.now() + estimatedWait * 60000),
    statusMessage: aheadCount === 0
      ? 'You are next in line! Prepare your vehicle.'
      : `${aheadCount} vehicles ahead of you in yard queue.`
  };
}

module.exports = {
  calculateBookingEta,
  VEHICLE_PROCESSING_TIME_MINS
};
