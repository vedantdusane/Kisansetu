/**
 * KisanSetu - Procurement Booking Service
 * Core business logic for:
 * - Fair-share slot capacity reservations & concurrency control
 * - Anti-duplicate crop appointment checks
 * - Deterministic token generation (A001..A999 per mandi per day)
 * - Yard lane and unloading bay assignments
 * - Cryptographic QR verification hash generation
 * - 13-stage lifecycle state transitions & cancellations
 */

const crypto = require('crypto');
const config = require('../config/env');
const Booking = require('../models/Booking');
const Center = require('../models/Center');
const Slot = require('../models/Slot');
const Farmer = require('../models/Farmer');
const tokenService = require('./tokenService');
const qrService = require('./qrService');

/**
 * Assign traffic lane based on vehicle type
 */
function assignVehicleLane(vehicleType) {
  switch (vehicleType) {
    case 'TRACTOR_TROLLEY':
      return 'LANE_1_TRACTOR';
    case 'PICKUP':
    case 'MINI_TRUCK':
      return 'LANE_2_LIGHT_TRUCK';
    case 'SIX_WHEELER':
      return 'LANE_3_HEAVY_TRUCK';
    case 'BULLOCK_CART':
      return 'LANE_4_TRADITIONAL';
    default:
      return 'LANE_1_GENERAL';
  }
}

/**
 * Assign unloading bay deterministically based on sequence number
 */
function assignUnloadingBay(sequenceNumber) {
  const bayIndex = ((sequenceNumber - 1) % 4) + 1;
  return `BAY-0${bayIndex}`;
}

/**
 * Generate tamper-proof QR code verification payload
 */
function generateQrPayload(bookingId, centerCode, date, displayToken) {
  const hash = crypto
    .createHmac('sha256', config.jwt.secret)
    .update(`${bookingId}:${centerCode}:${date}:${displayToken}`)
    .digest('hex')
    .substring(0, 16)
    .toUpperCase();

  return `KISANSETU:${centerCode}:${date}:${displayToken}:${hash}`;
}

/**
 * Create a new procurement booking with strict capacity locking
 */
async function createBooking({ user, bookingData }) {
  // 1. Resolve Farmer Profile
  let farmer = null;
  if (user.role === 'FARMER') {
    farmer = await Farmer.findOne({ userId: user._id });
    if (!farmer) {
      const error = new Error('Farmer profile not found. Please complete your registration first.');
      error.statusCode = 404;
      throw error;
    }
  } else if (bookingData.farmerId) {
    // Official booking on behalf of farmer (e.g. CSC or Gate Operator)
    farmer = await Farmer.findById(bookingData.farmerId);
    if (!farmer) {
      const error = new Error('Specified farmer not found in records.');
      error.statusCode = 404;
      throw error;
    }
  } else {
    const error = new Error('Farmer identification required to create a booking.');
    error.statusCode = 400;
    throw error;
  }

  // 2. Validate Center
  const center = await Center.findById(bookingData.centerId);
  if (!center || !center.active) {
    const error = new Error('Procurement center is inactive or does not exist.');
    error.statusCode = 404;
    throw error;
  }

  // Check crop acceptance
  if (!center.acceptedCrops.includes(bookingData.crop)) {
    const error = new Error(
      `Center "${center.name}" is not currently procuring "${bookingData.crop}". Accepted crops: ${center.acceptedCrops.join(', ')}`
    );
    error.statusCode = 400;
    throw error;
  }

  // 3. Validate Slot
  const slot = await Slot.findById(bookingData.slotId);
  if (!slot) {
    const error = new Error('Selected appointment slot not found.');
    error.statusCode = 404;
    throw error;
  }

  if (slot.centerId.toString() !== center._id.toString()) {
    const error = new Error('Slot does not belong to the selected procurement center.');
    error.statusCode = 400;
    throw error;
  }

  if (slot.isBlocked || slot.status === 'CLOSED') {
    const error = new Error('Selected slot is closed due to center maintenance or capacity limits.');
    error.statusCode = 400;
    throw error;
  }

  // 4. Anti-Duplicate Fair-Share Check
  const existingActiveBooking = await Booking.findOne({
    farmerId: farmer._id,
    date: slot.date,
    crop: bookingData.crop,
    status: { $nin: ['CANCELLED', 'REJECTED'] }
  });

  if (existingActiveBooking) {
    const error = new Error(
      `You already have an active appointment (Token: ${existingActiveBooking.token.displayToken}) for ${bookingData.crop} on ${slot.date}. Duplicate bookings on the same date are restricted.`
    );
    error.statusCode = 409;
    throw error;
  }

  // 5. Atomic Capacity Lock on Slot
  const updatedSlot = await Slot.findOneAndUpdate(
    {
      _id: slot._id,
      isBlocked: false,
      status: { $ne: 'CLOSED' },
      currentBookings: { $lt: slot.maxBookings }
    },
    { $inc: { currentBookings: 1 } },
    { new: true }
  );

  if (!updatedSlot) {
    const error = new Error('The selected slot just filled up! Please pick another time window.');
    error.statusCode = 409;
    throw error;
  }

  // Auto-mark FULL if capacity limit reached
  if (updatedSlot.currentBookings >= updatedSlot.maxBookings && updatedSlot.status !== 'FULL') {
    updatedSlot.status = 'FULL';
    await updatedSlot.save();
  }

  try {
    // 6. Generate Deterministic Daily Sequence & Token
    const tokenInfo = await tokenService.allocateNextToken(center._id, center.centerId, slot.date);
    const { bookingId, displayToken, sequenceNumber, fullTokenReference } = tokenInfo;

    // 7. Physical Yard Logistics Allocation
    const vehicleType = bookingData.vehicle?.vehicleType || 'TRACTOR_TROLLEY';
    const vehicleNumber = bookingData.vehicle?.vehicleNumber || 'MP-09-AB-1234';
    const assignedLane = assignVehicleLane(vehicleType);
    const assignedBay = assignUnloadingBay(sequenceNumber);

    // 8. Cryptographic QR Verification Payload & Base64 Pass Data URI
    const qrPayload = qrService.buildQrPayload({
      bookingId,
      centerCode: center.centerId,
      date: slot.date,
      displayToken
    });
    const qrImageBase64 = await qrService.generateQrDataUri(qrPayload);

    // 9. Persist Procurement Booking Record
    const booking = await Booking.create({
      bookingId,
      farmerId: farmer._id,
      farmerName: farmer.name,
      farmerPhone: farmer.mobileNumber,
      centerId: center._id,
      centerCode: center.centerId,
      centerName: center.name,
      slotId: slot._id,
      crop: bookingData.crop,
      expectedQuantityQtl: bookingData.expectedQuantityQtl,
      vehicle: {
        vehicleType,
        vehicleNumber,
        assignedLane,
        assignedBay
      },
      date: slot.date,
      timeSlot: `${slot.startTime} - ${slot.endTime}`,
      token: {
        displayToken,
        sequenceNumber,
        fullTokenReference
      },
      qrCode: {
        qrPayload,
        qrImageBase64
      },
      status: 'BOOKED',
      statusHistory: [
        {
          status: 'BOOKED',
          timestamp: new Date(),
          updatedBy: user._id,
          remarks: 'Slot booked online by farmer'
        }
      ]
    });

    return booking;
  } catch (err) {
    // Rollback atomic slot reservation on failure
    await Slot.findByIdAndUpdate(slot._id, {
      $inc: { currentBookings: -1 },
      status: 'AVAILABLE'
    });
    throw err;
  }
}

/**
 * Fetch bookings with role-based filtering & pagination
 */
async function getBookings({ user, filters = {}, pagination = {} }) {
  const query = {};

  if (user.role === 'FARMER') {
    const farmer = await Farmer.findOne({ userId: user._id });
    if (!farmer) return { bookings: [], total: 0 };
    query.farmerId = farmer._id;
  } else {
    // Mandi Officials / Admin filters
    if (filters.centerId) query.centerId = filters.centerId;
    if (filters.date) query.date = filters.date;
    if (filters.status) query.status = filters.status;
    if (filters.crop) query.crop = filters.crop;
  }

  const page = Math.max(1, parseInt(pagination.page, 10) || 1);
  const limit = Math.min(100, Math.max(1, parseInt(pagination.limit, 10) || 20));
  const skip = (page - 1) * limit;

  const [bookings, total] = await Promise.all([
    Booking.find(query)
      .populate('farmerId', 'name mobileNumber residence')
      .populate('centerId', 'name centerId district state')
      .sort({ date: -1, 'token.sequenceNumber': 1 })
      .skip(skip)
      .limit(limit),
    Booking.countDocuments(query)
  ]);

  return {
    bookings,
    pagination: {
      total,
      page,
      limit,
      pages: Math.ceil(total / limit)
    }
  };
}

/**
 * Get single booking by MongoDB _id or Human-readable bookingId
 */
async function getBookingById(identifier, user) {
  const isMongoId = identifier.match(/^[0-9a-fA-F]{24}$/);
  const query = isMongoId ? { _id: identifier } : { bookingId: identifier };

  const booking = await Booking.findOne(query)
    .populate('farmerId', 'name mobileNumber residence landDetails')
    .populate('centerId', 'name centerId district state gates')
    .populate('slotId');

  if (!booking) {
    const error = new Error('Booking not found.');
    error.statusCode = 404;
    throw error;
  }

  // Access control: Farmers can only access their own bookings
  if (user.role === 'FARMER') {
    const farmer = await Farmer.findOne({ userId: user._id });
    if (!farmer || booking.farmerId._id.toString() !== farmer._id.toString()) {
      const error = new Error('Access denied. You can only view your own procurement bookings.');
      error.statusCode = 403;
      throw error;
    }
  }

  return booking;
}

/**
 * Cancel a booking with atomic slot release
 */
async function cancelBooking(identifier, user, reason = 'Cancelled by farmer') {
  const isMongoId = identifier.match(/^[0-9a-fA-F]{24}$/);
  const query = isMongoId ? { _id: identifier } : { bookingId: identifier };

  const booking = await Booking.findOne(query);
  if (!booking) {
    const error = new Error('Booking not found.');
    error.statusCode = 404;
    throw error;
  }

  // Access check: Farmer ownership
  if (user.role === 'FARMER') {
    const farmer = await Farmer.findOne({ userId: user._id });
    if (!farmer || booking.farmerId.toString() !== farmer._id.toString()) {
      const error = new Error('Access denied. You can only cancel your own bookings.');
      error.statusCode = 403;
      throw error;
    }
  }

  // Can only cancel if produce has not physically arrived at the gate
  if (booking.status !== 'BOOKED') {
    const error = new Error(
      `Cannot cancel booking in '${booking.status}' state. Only unarrived 'BOOKED' passes can be cancelled.`
    );
    error.statusCode = 400;
    throw error;
  }

  // 1. Release capacity on slot
  await Slot.findByIdAndUpdate(booking.slotId, {
    $inc: { currentBookings: -1 },
    status: 'AVAILABLE'
  });

  // 2. Transition status with audit entry
  booking.transitionStatus('CANCELLED', user._id, reason);
  booking.cancellationReason = reason;
  await booking.save();

  return booking;
}

module.exports = {
  createBooking,
  getBookings,
  getBookingById,
  cancelBooking,
  generateQrPayload,
  assignVehicleLane,
  assignUnloadingBay
};
