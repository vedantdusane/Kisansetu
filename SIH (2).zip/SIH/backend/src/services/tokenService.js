/**
 * KisanSetu - Dedicated Token Generation Service
 * Manages daily center-isolated sequence counters and formatted token identifiers.
 */

const Booking = require('../models/Booking');

/**
 * Format sequence number into daily alphanumeric token (e.g. 1 -> A001, 1000 -> B001)
 */
function formatDisplayToken(sequenceNumber) {
  const seriesIndex = Math.floor((sequenceNumber - 1) / 999);
  const seriesLetter = String.fromCharCode(65 + seriesIndex); // 'A', 'B', etc.
  const numericPart = ((sequenceNumber - 1) % 999) + 1;
  return `${seriesLetter}${String(numericPart).padStart(3, '0')}`;
}

/**
 * Generate human-readable full token reference and unique booking identifier
 */
function buildTokenIdentifiers(centerCode, date, displayToken, sequenceNumber) {
  const cleanCenter = centerCode.replace(/[^A-Za-z0-9]/g, '').toUpperCase();
  const cleanDate = date.replace(/[^0-9]/g, '');

  const bookingId = `BK-${cleanCenter}-${cleanDate}-${displayToken}`;
  const fullTokenReference = `${centerCode}-${date}-${displayToken}`;

  return {
    bookingId,
    displayToken,
    sequenceNumber,
    fullTokenReference
  };
}

/**
 * Allocate next sequential token for a specific Mandi Center on a given date
 */
async function allocateNextToken(centerId, centerCode, date) {
  // Count active or registered bookings for this center on this specific date
  const count = await Booking.countDocuments({
    centerId,
    date
  });

  const nextSequence = count + 1;
  const displayToken = formatDisplayToken(nextSequence);

  return buildTokenIdentifiers(centerCode, date, displayToken, nextSequence);
}

/**
 * Parse token string back into components
 */
function parseToken(tokenStr) {
  const match = tokenStr.match(/^([A-Z])(\d{3})$/);
  if (!match) return null;
  const series = match[1];
  const number = parseInt(match[2], 10);
  const globalSeq = (series.charCodeAt(0) - 65) * 999 + number;
  return { series, number, globalSeq };
}

module.exports = {
  formatDisplayToken,
  buildTokenIdentifiers,
  allocateNextToken,
  parseToken
};
