/**
 * KisanSetu - Multi-lingual SMS / IVR Notification Dispatcher
 * Sends localized updates across 7 Indian languages (hi, mr, pa, gu, bn, ta, en)
 * to ensure feature-phone accessibility for smallholder farmers.
 */

const { emitFarmerNotification } = require('../socket/socketHandler');

const TEMPLATES = {
  BOOKING_CONFIRMED: {
    hi: (d) => `[किसानसेतु] स्लॉट बुक हो गया! आपका टोकन: ${d.token} | APMC: ${d.centerName} | दिनांक: ${d.date} (${d.timeSlot}) | लेन: ${d.lane}।`,
    mr: (d) => `[किसानसेतू] स्लॉट आरक्षित! तुमचा टोकन: ${d.token} | APMC: ${d.centerName} | दिनांक: ${d.date} (${d.timeSlot}) | लेन: ${d.lane}.`,
    pa: (d) => `[ਕਿਸਾਨਸੇਤੂ] ਸਲਾਟ ਬੁੱਕ ਹੋ ਗਿਆ! ਤੁਹਾਡਾ ਟੋਕਨ: ${d.token} | APMC: ${d.centerName} | ਮਿਤੀ: ${d.date} (${d.timeSlot}).`,
    gu: (d) => `[કિસાનસેતુ] સ્લોટ બુક થઈ ગયો! તમારો ટોકન: ${d.token} | APMC: ${d.centerName} | તારીખ: ${d.date}.`,
    en: (d) => `[KisanSetu] Appointment confirmed! Token: ${d.token} | Mandi: ${d.centerName} | Date: ${d.date} (${d.timeSlot}) | Lane: ${d.lane}.`
  },
  TOKEN_CALLED: {
    hi: (d) => `🚨 [किसानसेतु] आपका टोकन ${d.token} बुलाया गया है! कृपया अपना वाहन तुरंत ${d.bay} पर ले जाएं।`,
    mr: (d) => `🚨 [किसानसेतू] तुमचा टोकन ${d.token} पुकारला आहे! कृपया तुमचे वाहन त्वरित ${d.bay} वर घेऊन या.`,
    en: (d) => `🚨 [KisanSetu] Alert! Token ${d.token} has been CALLED to ${d.bay}. Proceed immediately.`
  },
  DBT_CREDITED: {
    hi: (d) => `💰 [किसानसेतु] DBT भुगतान सफल! ₹${d.amount} आपके ${d.bankName} खाते में जमा कर दिए गए हैं। UTR: ${d.utrNumber}। धन्यवाद!`,
    mr: (d) => `💰 [किसानसेतू] DBT रक्कम जमा! ₹${d.amount} तुमच्या ${d.bankName} खात्यात जमा झाली आहे. UTR: ${d.utrNumber}. आभार!`,
    en: (d) => `💰 [KisanSetu] DBT Payment Credited! ₹${d.amount} sent to your ${d.bankName} account. UTR: ${d.utrNumber}. Thank you!`
  }
};

/**
 * Dispatch SMS / IVR Notification
 */
async function sendNotification({ farmerId, phone, lang = 'hi', type, data = {} }) {
  const language = ['hi', 'mr', 'pa', 'gu', 'en'].includes(lang) ? lang : 'hi';
  const templateFn = TEMPLATES[type]?.[language] || TEMPLATES[type]?.['en'] || ((d) => `[KisanSetu Update] ${JSON.stringify(d)}`);

  const messageText = templateFn(data);

  // 1. Console SMS Display Log (Hackathon Demo Visibility)
  console.log('------------------------------------------------------------');
  console.log(`📱 [SMS/IVR SIMULATOR] To: ${phone} (${language.toUpperCase()})`);
  console.log(`💬 Message: ${messageText}`);
  console.log('------------------------------------------------------------');

  // 2. Real-time push to Farmer's App via WebSocket
  if (farmerId) {
    emitFarmerNotification(farmerId.toString(), {
      type,
      message: messageText,
      timestamp: new Date().toISOString(),
      data
    });
  }

  // 3. Dispatch Live Cellular Voice Call via Twilio if configured
  const config = require('../config/env');
  if (config.twilio && config.twilio.accountSid && config.twilio.authToken) {
    const rawSid = config.twilio.accountSid.replace(/^q/i, '').trim();
    const token = config.twilio.authToken.trim();
    const twilioFrom = config.twilio.phoneNumber;
    const targetPhone = phone && phone.startsWith('+') ? phone : (config.twilio.demoFarmerPhone || '+919067741198');

    if (twilioFrom && targetPhone) {
      try {
        const https = require('https');
        const authHeader = 'Basic ' + Buffer.from(`${rawSid}:${token}`).toString('base64');
        const twiml = `
          <Response>
            <Pause length="1"/>
            <Say voice="Polly.Aditi" language="hi-IN">${messageText}</Say>
            <Pause length="1"/>
            <Say voice="alice" language="en-IN">Notification from KisanSetu APMC Mandi. Thank you.</Say>
          </Response>
        `.trim().replace(/\s+/g, ' ');

        const postData = new URLSearchParams({
          To: targetPhone,
          From: twilioFrom,
          Twiml: twiml
        }).toString();

        const req = https.request({
          hostname: 'api.twilio.com',
          port: 443,
          path: `/2010-04-01/Accounts/${rawSid}/Calls.json`,
          method: 'POST',
          headers: {
            'Authorization': authHeader,
            'Content-Type': 'application/x-www-form-urlencoded',
            'Content-Length': Buffer.byteLength(postData)
          }
        }, (res) => {
          let b = '';
          res.on('data', d => b += d);
          res.on('end', () => {
            if (res.statusCode >= 200 && res.statusCode < 300) {
              console.log(`📞 [TWILIO CELLULAR CALL PLACED]: Call dispatched to ${targetPhone}`);
            } else {
              console.warn(`⚠️ [TWILIO CALL PENDING]: ${b}`);
            }
          });
        });
        req.on('error', (e) => console.warn(`⚠️ [Twilio Network Error]: ${e.message}`));
        req.write(postData);
        req.end();
      } catch (twErr) {
        console.warn('Twilio dispatch error:', twErr.message);
      }
    }
  }

  return {
    success: true,
    channel: 'SMS_WEBSOCKET_AND_TWILIO',
    recipient: phone,
    message: messageText
  };
}

module.exports = {
  sendNotification,
  TEMPLATES
};
