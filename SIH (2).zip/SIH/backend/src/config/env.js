/**
 * KisanSetu - Environment Config & Validator
 * Loads environment variables from .env and exposes a clean immutable object.
 */

const dotenv = require('dotenv');
const path = require('path');

// Ensure .env is read from the backend root folder
dotenv.config({ path: path.join(__dirname, '../../.env') });

const config = {
  port: parseInt(process.env.PORT, 10) || 5000,
  nodeEnv: process.env.NODE_ENV || 'development',
  frontendUrl: process.env.FRONTEND_URL || 'http://localhost:3000',

  mongoUri: process.env.MONGO_URI || 'mongodb://127.0.0.1:27017/kisansetu',

  jwt: {
    secret: process.env.JWT_SECRET || 'kisansetu_fallback_secret_sih2026',
    expiresIn: process.env.JWT_EXPIRES_IN || '7d'
  },

  demoMode: process.env.DEMO_MODE === 'true',
  mockSms: process.env.MOCK_SMS === 'true',
  mockIvr: process.env.MOCK_IVR === 'true',

  telephony: {
    smsApiKey: process.env.SMS_API_KEY || '',
    ivrApiKey: process.env.IVR_API_KEY || '',
    ivrNumber: process.env.IVR_NUMBER || '+911800547267'
  },

  twilio: {
    accountSid: process.env.TWILIO_ACCOUNT_SID || '',
    authToken: process.env.TWILIO_AUTH_TOKEN || '',
    phoneNumber: process.env.TWILIO_PHONE_NUMBER || '',
    demoFarmerPhone: process.env.DEMO_FARMER_PHONE || '+919067741198'
  },

  defaults: {
    language: process.env.DEFAULT_LANGUAGE || 'hi',
    avgProcessingTimeMins: parseInt(process.env.AVERAGE_PROCESSING_TIME_MINS, 10) || 5,
    maxSlotCapacity: parseInt(process.env.MAX_SLOT_CAPACITY_DEFAULT, 10) || 30
  }
};

module.exports = config;
