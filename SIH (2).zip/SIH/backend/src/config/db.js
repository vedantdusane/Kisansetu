/**
 * KisanSetu - MongoDB Database Connection Manager
 * Features:
 * - Resilient connection pooling
 * - Auto-reconnect & error listener
 * - Graceful shutdown handling
 * - Supports MongoDB Atlas & local MongoDB
 */

const mongoose = require('mongoose');
const config = require('./env');

const DIRECT_ATLAS_URI = 'mongodb://dusanev4_db_user:KisanSetu2026!@ac-dy8n8gq-shard-00-01.cr7myru.mongodb.net:27017/kisansetu?ssl=true&authSource=admin&retryWrites=true&w=majority';

const connectDB = async () => {
  const tryConnect = async (uri, isFallback = false) => {
    return await mongoose.connect(uri, {
      family: 4, // Force IPv4 (skips slow IPv6 DNS fallback delays on Windows)
      autoIndex: false, // Prevents rebuilding remote cloud indexes on every start
      serverSelectionTimeoutMS: 12000,
    });
  };

  try {
    console.log('⏳ [MongoDB]: Connecting to MongoDB Atlas cloud cluster...');
    const conn = await tryConnect(config.mongoUri);
    console.log(`✅ [MongoDB Connected]: ${conn.connection.host}/${conn.connection.name}`);
    return conn;
  } catch (error) {
    // If SRV DNS lookup timed out (common with mobile hotspots or restrictive routers), try direct replica-set URI
    if (error.message && (error.message.includes('querySrv') || error.message.includes('ENOTFOUND') || error.message.includes('ETIMEOUT'))) {
      console.warn('⚠️ [MongoDB]: SRV DNS lookup failed on local network. Retrying via Direct Replica-Set connection...');
      try {
        const fallbackConn = await tryConnect(DIRECT_ATLAS_URI, true);
        console.log(`✅ [MongoDB Connected via Direct URI]: ${fallbackConn.connection.host}/${fallbackConn.connection.name}`);
        return fallbackConn;
      } catch (fallbackErr) {
        console.error(`❌ [MongoDB Direct Connection Failed]: ${fallbackErr.message}`);
      }
    }

    console.error(`❌ [MongoDB Connection Failed]: ${error.message}`);
    console.error('👉 Hint: Check your internet connection, MONGO_URI in .env, or verify IP access in MongoDB Atlas.');
    if (config.nodeEnv === 'production') {
      process.exit(1);
    }
    throw error;
  }
};

const disconnectDB = async () => {
  try {
    await mongoose.connection.close();
    console.log('🛑 [MongoDB Connection Closed]: Disconnected safely.');
  } catch (error) {
    console.error(`❌ [Error Disconnecting MongoDB]: ${error.message}`);
  }
};

module.exports = {
  connectDB,
  disconnectDB
};
