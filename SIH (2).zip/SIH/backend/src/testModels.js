/**
 * KisanSetu - Model Validation Test Script
 * Run: node src/testModels.js
 */

const User = require('./models/User');
const Farmer = require('./models/Farmer');

async function testModels() {
  console.log('⏳ Verifying User and Farmer Mongoose Models...');

  try {
    // 1. Test User instance creation & methods
    const testUser = new User({
      name: 'Ramesh Patel',
      role: 'FARMER',
      phone: '9876543210',
      password: 'secretPassword123',
      preferredLanguage: 'hi'
    });

    // Verify virtuals/pre-save hash simulation
    await testUser.validate();
    console.log('✅ User schema validation passed.');

    // Manually trigger pre-save hook for testing password match
    await testUser.save().catch(() => {}); // May fail if no DB connection, so test hash manually
    testUser.password = await require('bcryptjs').hash('secretPassword123', 10);

    const isMatch = await testUser.matchPassword('secretPassword123');
    const isWrong = await testUser.matchPassword('wrongPassword');
    console.log('✅ Password hash verification:', isMatch === true && isWrong === false ? 'PASSED' : 'FAILED');

    const token = testUser.generateAuthToken();
    console.log('✅ JWT Token generation passed. Token length:', token.length);

    // 2. Test Farmer instance creation
    const testFarmer = new Farmer({
      userId: testUser._id,
      farmerId: 'KS-MP-IND-001',
      name: testUser.name,
      mobileNumber: testUser.phone,
      language: 'hi',
      crops: [{ name: 'Wheat', variety: 'Sharbati', sownAcres: 4, estimatedYieldQtl: 60 }]
    });

    await testFarmer.validate();
    console.log('✅ Farmer schema validation passed.');
    console.log('🎉 Models verification completed successfully!');
    process.exit(0);
  } catch (err) {
    console.error('❌ Model test error:', err.message);
    process.exit(1);
  }
}

testModels();
