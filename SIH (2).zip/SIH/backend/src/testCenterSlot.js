/**
 * KisanSetu - Center & Slot Model Diagnostic Test
 * Run: node src/testCenterSlot.js
 */

const { connectDB, disconnectDB } = require('./config/db');
const Center = require('./models/Center');
const Slot = require('./models/Slot');

async function testCenterSlot() {
  console.log('⏳ Running Center and Slot Model Tests...\n');

  try {
    await connectDB();

    // Clean any previous test data
    await Slot.deleteMany({ centerCode: 'TEST-IND-999' });
    await Center.deleteMany({ centerId: 'TEST-IND-999' });

    // 1. Create Center instance
    console.log('1️⃣  [TEST]: Creating Procurement Center...');
    const center = await Center.create({
      centerId: 'TEST-IND-999',
      name: 'Sanwer Model APMC Yard',
      district: 'Indore',
      state: 'Madhya Pradesh',
      zone: 'Central',
      address: 'Khandwa-Ujjain Bypass, Sanwer',
      dailyCapacity: 200,
      storageCapacity: 20000,
      storageUsed: 15000, // 75% utilized
      acceptedCrops: ['Wheat', 'Soybean']
    });

    console.log(`   ✓ Center Created: ${center.name} (${center.centerId})`);
    console.log(`   ✓ Storage Available: ${center.storageAvailable} MT`);
    console.log(`   ✓ Storage Saturation: ${center.storageSaturationPct}%`);

    // 2. Create Slot instance
    console.log('\n2️⃣  [TEST]: Creating Capacity Slot...');
    const slot = new Slot({
      centerId: center._id,
      centerCode: center.centerId,
      date: '2026-09-15',
      startTime: '10:00 AM',
      endTime: '11:00 AM',
      maxBookings: 25,
      currentBookings: 24
    });

    await slot.save();
    console.log(`   ✓ Slot Created: ${slot.slotId}`);
    console.log(`   ✓ Available Seats: ${slot.availableSeats} / ${slot.maxBookings}`);
    console.log(`   ✓ Status: ${slot.status}`);

    // 3. Test Capacity Auto-Transition to FULL
    slot.currentBookings = 25;
    await slot.save();
    console.log(`   ✓ When booked to capacity, status automatically became: ${slot.status} (Expected: FULL)`);

    // Clean up
    await Slot.deleteMany({ centerCode: 'TEST-IND-999' });
    await Center.deleteMany({ centerId: 'TEST-IND-999' });

    console.log('\n🎉 CENTER & SLOT MODELS VALIDATED WITH 100% SUCCESS!\n');
    await disconnectDB();
    process.exit(0);
  } catch (err) {
    console.error('❌ Center/Slot test error:', err);
    await disconnectDB();
    process.exit(1);
  }
}

testCenterSlot();
