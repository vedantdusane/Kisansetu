/**
 * KisanSetu - Center & Slot API Diagnostic Test
 * Run: node src/testCenterSlotApi.js
 */

const { connectDB, disconnectDB } = require('./config/db');
const Center = require('./models/Center');
const Slot = require('./models/Slot');
const User = require('./models/User');

async function testCenterSlotApi() {
  console.log('⏳ Running Center & Slot API Workflow Tests...\n');

  try {
    await connectDB();

    // Clean up past test data
    await Slot.deleteMany({ centerCode: 'API-TEST-01' });
    await Center.deleteMany({ centerId: 'API-TEST-01' });

    // 1. Create a Mandi Center
    console.log('1️⃣  [TEST]: Creating Procurement Center (APMC Mandi)');
    const center = await Center.create({
      centerId: 'API-TEST-01',
      name: 'Lasalgaon Model Onion & Grain APMC',
      district: 'Nashik',
      state: 'Maharashtra',
      zone: 'West',
      address: 'Main Yard, Lasalgaon, Niphad',
      dailyCapacity: 300,
      storageCapacity: 40000,
      storageUsed: 22000,
      acceptedCrops: ['Onion', 'Wheat', 'Soybean', 'Maize']
    });

    console.log(`   ✓ Center Created: ${center.name} (${center.centerId})`);
    console.log(`   ✓ State: ${center.state} | Zone: ${center.zone}`);
    console.log(`   ✓ Storage Saturation: ${center.storageSaturationPct}% (${center.storageAvailable} MT free)`);

    // 2. Query Centers by State and Crop
    console.log('\n2️⃣  [TEST]: Querying Centers (Filter: Maharashtra & Wheat)');
    const filteredCenters = await Center.find({
      state: 'Maharashtra',
      acceptedCrops: { $in: ['Wheat'] },
      active: true
    });
    console.log(`   ✓ Centers matching criteria: ${filteredCenters.length} found.`);

    // 3. Batch Generate Daily Slots (09:00 AM to 05:00 PM)
    console.log('\n3️⃣  [TEST]: Generating Daily Appointment Slots for 2026-09-15');
    const standardHours = [
      { start: '09:00 AM', end: '10:00 AM' },
      { start: '10:00 AM', end: '11:00 AM' },
      { start: '11:00 AM', end: '12:00 PM' },
      { start: '12:00 PM', end: '01:00 PM' },
      { start: '02:00 PM', end: '03:00 PM' },
      { start: '03:00 PM', end: '04:00 PM' },
      { start: '04:00 PM', end: '05:00 PM' }
    ];

    for (const h of standardHours) {
      await Slot.create({
        centerId: center._id,
        centerCode: center.centerId,
        date: '2026-09-15',
        startTime: h.start,
        endTime: h.end,
        maxBookings: 25
      });
    }

    const slots = await Slot.find({ centerCode: 'API-TEST-01', date: '2026-09-15' }).sort({ startTime: 1 });
    console.log(`   ✓ Successfully generated ${slots.length} appointment slots for the day!`);
    console.log(`   ✓ First slot: ${slots[0].startTime} - ${slots[0].endTime} | Available: ${slots[0].availableSeats} / ${slots[0].maxBookings}`);

    // 4. Test Emergency Block on a slot
    console.log('\n4️⃣  [TEST]: Emergency Slot Block (e.g. Weighbridge Maintenance)');
    const slotToBlock = slots[1]; // 10:00 - 11:00 AM
    slotToBlock.isBlocked = true;
    await slotToBlock.save();
    console.log(`   ✓ Slot ${slotToBlock.startTime} blocked. Status became: ${slotToBlock.status} (Expected: CLOSED)`);

    // Clean up
    await Slot.deleteMany({ centerCode: 'API-TEST-01' });
    await Center.deleteMany({ centerId: 'API-TEST-01' });

    console.log('\n🎉 ALL CENTER & SLOT API WORKFLOW TESTS PASSED SUCCESSFULLY!\n');
    await disconnectDB();
    process.exit(0);
  } catch (err) {
    console.error('❌ Center/Slot API test error:', err);
    await disconnectDB();
    process.exit(1);
  }
}

testCenterSlotApi();
