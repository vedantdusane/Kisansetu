/**
 * KisanSetu - Server Bootstrapper
 * Initializes HTTP Server, Connects to MongoDB, and Gracefully Handles Process Signals.
 */

const http = require('http');
const app = require('./app');
const config = require('./config/env');
const { connectDB, disconnectDB } = require('./config/db');
const { initSocket } = require('./socket/socketHandler');

const server = http.createServer(app);

// Initialize Socket.IO
initSocket(server);

const startServer = async () => {
  // 1. Start HTTP Server immediately so Nodemon & API are always active
  server.listen(config.port, () => {
    console.log('================================================================');
    console.log(`🌾 [KisanSetu Backend OS Running]`);
    console.log(`🚀 Server Address: http://localhost:${config.port}`);
    console.log(`⚡ WebSocket URL:  ws://localhost:${config.port}`);
    console.log(`🩺 Health Check:   http://localhost:${config.port}/api/health`);
    console.log(`🛡️  Auth Base:     http://localhost:${config.port}/api/auth`);
    console.log(`⚙️  Mode:          ${config.nodeEnv.toUpperCase()} | Demo Mode: ${config.demoMode}`);
    console.log('================================================================');
  });

  // 2. Connect to Database with auto-retry resilience
  try {
    await connectDB();
  } catch (err) {
    console.warn(`⚠️  [Database Connection Pending]: Will auto-retry in 5 seconds...`);
    const retryInterval = setInterval(async () => {
      try {
        await connectDB();
        clearInterval(retryInterval);
      } catch (retryErr) {
        // Continue retrying in background
      }
    }, 5000);
  }
};

// Graceful Shutdown Handlers
const handleGracefulShutdown = async (signal) => {
  console.log(`\n⚠️  Received ${signal}. Shutting down gracefully...`);
  server.close(async () => {
    await disconnectDB();
    console.log('👋 Process terminated successfully.');
    process.exit(0);
  });
};

process.on('SIGINT', () => handleGracefulShutdown('SIGINT'));
process.on('SIGTERM', () => handleGracefulShutdown('SIGTERM'));

process.on('unhandledRejection', (err) => {
  console.error(`💥 Unhandled Promise Rejection: ${err.message}`);
  // In production, log and safely terminate or notify alert webhook
});

startServer();

module.exports = { server, app };
