/**
 * KisanSetu - Intelligent MongoDB Connectivity Diagnostic
 * Tests standard SRV and direct shard connections.
 * Automatically saves the working URI to .env.
 */

const mongoose = require('mongoose');
const fs = require('fs');
const path = require('path');
const net = require('net');

function checkTcpPort(host, port = 27017, timeout = 3500) {
  return new Promise((resolve) => {
    const socket = new net.Socket();
    socket.setTimeout(timeout);
    socket.on('connect', () => {
      socket.destroy();
      resolve({ open: true });
    });
    socket.on('timeout', () => {
      socket.destroy();
      resolve({ open: false, reason: 'TIMED_OUT (Firewall / ISP blocked port 27017)' });
    });
    socket.on('error', (err) => {
      socket.destroy();
      resolve({ open: false, reason: err.code || err.message });
    });
    socket.connect(port, host);
  });
}

const candidates = [
  {
    name: '1. Local Offline MongoDB (127.0.0.1:27017)',
    uri: 'mongodb://127.0.0.1:27017/kisansetu'
  },
  {
    name: '2. Standard SRV URI (Cloud Cluster)',
    uri: 'mongodb+srv://dusanev4_db_user:KisanSetu2026!@cluster0.cr7myru.mongodb.net/kisansetu?retryWrites=true&w=majority'
  },
  {
    name: '3. Direct Shard 01 (Auto-Discover Replica Set)',
    uri: 'mongodb://dusanev4_db_user:KisanSetu2026!@ac-dy8n8gq-shard-00-01.cr7myru.mongodb.net:27017/kisansetu?ssl=true&authSource=admin&retryWrites=true&w=majority'
  }
];

async function runDiagnostic() {
  console.log('🌾 =========================================================');
  console.log('🌾 [KisanSetu - MongoDB Intelligent Connectivity Test]');
  console.log('🌾 =========================================================\n');

  // Check local MongoDB port 27017
  process.stdout.write('📡 Probing Local MongoDB (127.0.0.1:27017)... ');
  const localTcp = await checkTcpPort('127.0.0.1', 27017, 2000);
  if (localTcp.open) {
    console.log('✅ Local MongoDB is active and running!');
  } else {
    console.log(`⚠️ Local MongoDB port not active yet: ${localTcp.reason}`);
  }
  console.log('');

  let workingConn = null;
  let workingUri = null;

  for (const candidate of candidates) {
    process.stdout.write(`⏳ Testing [${candidate.name}]... `);
    try {
      const conn = await mongoose.connect(candidate.uri, {
        family: 4,
        serverSelectionTimeoutMS: 6000,
        autoIndex: false
      });
      console.log('✅ CONNECTED!');
      workingConn = conn;
      workingUri = candidate.uri;
      break;
    } catch (err) {
      console.log('❌ Failed!');
      if (err.reason && err.reason.servers) {
        for (const [server, desc] of err.reason.servers) {
          const errDetail = desc.error ? desc.error.message || desc.error : (desc.type || 'Unknown status');
          console.log(`      ➔ [${server}]: ${errDetail}`);
        }
      } else {
        console.log(`      ➔ ${err.message}`);
      }
      try { await mongoose.disconnect(); } catch (e) {}
    }
  }

  if (workingConn) {
    console.log('\n🎉 SUCCESS! MongoDB Atlas connection established.');
    console.log(`   Connected Host: ${workingConn.connection.host}`);
    console.log(`   Database Name:  ${workingConn.connection.name}`);

    // Update .env with the working URI so all subsequent commands work seamlessly
    const envPath = path.join(__dirname, '../.env');
    if (fs.existsSync(envPath)) {
      let envContent = fs.readFileSync(envPath, 'utf8');
      envContent = envContent.replace(/MONGO_URI=.*/g, `MONGO_URI=${workingUri}`);
      fs.writeFileSync(envPath, envContent, 'utf8');
      console.log('   ✓ Updated backend/.env with the verified working connection string.');
    }

    await mongoose.disconnect();
    console.log('\n👉 You can now run: npm run dev');
    process.exit(0);
  } else {
    console.log('\n❌ All connection candidates were rejected by MongoDB Atlas.');
    console.log('========================================================================');
    console.log('💡 CAUSE: Your current IP address is not whitelisted in MongoDB Atlas.');
    console.log('   (This happens when a mobile hotspot or Wi-Fi reconnects with a new dynamic IP)');
    console.log('========================================================================');
    console.log('👉 Quick 1-minute Fix:');
    console.log('   1. Open: https://cloud.mongodb.com/');
    console.log('   2. In the left sidebar under "SECURITY", click "Network Access"');
    console.log('   3. Click "+ ADD IP ADDRESS" (green button)');
    console.log('   4. Click "ALLOW ACCESS FROM ANYWHERE" (it automatically enters 0.0.0.0/0)');
    console.log('   5. Click "Confirm"');
    console.log('   6. Wait 30 seconds for Atlas to apply, then re-run: npm run test:db');
    console.log('========================================================================\n');
    process.exit(1);
  }
}

runDiagnostic();
