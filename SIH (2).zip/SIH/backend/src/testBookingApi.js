/**
 * KisanSetu - Booking API & Service Diagnostic Test
 * Run: node src/testBookingApi.js
 */

const { connectDB, disconnectDB } = require('./config/db');
const User = require('./models/User');
const Farmer = require('./models/Farmer');
const Center = require('./models/Center');
const Slot = require('./models/Slot');
const Booking = require('./models/Booking');
const bookingService = require('./services/bookingService');

async function testBookingApi() {
  console.log('⏳ Running Booking API & Fair-Share Reservation Tests...\n');

  try {
    await connectDB();

    // 0. Clean up previous test runs
    await Booking.deleteMany({ bookingId: /^BK-BKTEST/ });
    await Slot.deleteMany({ centerCode: 'BK-TEST-01' });
    await Center.deleteMany({ centerId: 'BK-TEST-01' });
    await Farmer.deleteMany({ mobileNumber: '9998887776' });
    await User.deleteMany({ phone: '9998887776' });

    // 1. Setup Test User & Farmer
    console.log('1️⃣  [TEST]: Creating Test Farmer Account');
    const user = await User.create({
      phone: '9998887776',
      name: 'Ramesh Patel (Test)',
      role: 'FARMER',
      isPhoneVerified: true
    });

    const farmer = await Farmer.create({
      userId: user._id,
      farmerId: 'KS-TEST-001',
      name: user.name,
      mobileNumber: user.phone,
      language: 'hi',
      residence: {
        state: 'Madhya Pradesh',
        district: 'Indore',
        tehsil: 'Sanwer',
        village: 'Kshipra'
      }
    });
    console.log(`   ✓ Farmer Profile Created: ${farmer.name} (${farmer.farmerId})`);

    // 2. Setup Test APMC Center
    console.log('\n2️⃣  [TEST]: Creating APMC Mandi Center');
    const center = await Center.create({
      centerId: 'BK-TEST-01',
      name: 'Indore Test Model Mandi',
      district: 'Indore',
      state: 'Madhya Pradesh',
      zone: 'Central',
      address: 'Sanwer Road, Indore',
      dailyCapacity: 100,
      storageCapacity: 25000,
      storageUsed: 10000,
      acceptedCrops: ['Wheat', 'Soybean', 'Chana']
    });
    console.log(`   ✓ Mandi Created: ${center.name} (${center.centerId})`);

    // 3. Setup Test Slot
    console.log('\n3️⃣  [TEST]: Creating Capacity-Restricted Slot');
    const slot = await Slot.create({
      centerId: center._id,
      centerCode: center.centerId,
      date: '2026-09-20',
      startTime: '10:00 AM',
      endTime: '11:00 AM',
      maxBookings: 2,
      currentBookings: 0
    });
    console.log(`   ✓ Slot Created: ${slot.startTime} - ${slot.endTime} | Max Capacity: ${slot.maxBookings}`);

    // 4. Create Procurement Booking
    console.log('\n4️⃣  [TEST]: Reserving Slot via bookingService.createBooking');
    const bookingData = {
      centerId: center._id.toString(),
      slotId: slot._id.toString(),
      crop: 'Wheat',
      expectedQuantityQtl: 45,
      vehicle: {
        vehicleType: 'TRACTOR_TROLLEY',
        vehicleNumber: 'MP-09-AA-5555'
      }
    };

    const booking = await bookingService.createBooking({ user, bookingData });
    console.log(`   ✓ Booking Created: ${booking.bookingId}`);
    console.log(`   ✓ Token Issued: ${booking.token.displayToken} (Seq: ${booking.token.sequenceNumber})`);
    console.log(`   ✓ Vehicle Lane Assigned: ${booking.vehicle.assignedLane}`);
    console.log(`   ✓ Unloading Bay Assigned: ${booking.vehicle.assignedBay}`);
    console.log(`   ✓ QR Payload Generated: ${booking.qrCode.qrPayload}`);
    console.log(`   ✓ Initial Status: ${booking.status}`);

    // 5. Verify Slot Capacity Atomic Increment
    console.log('\n5️⃣  [TEST]: Verifying Slot Atomic Capacity Lock');
    const refreshedSlot = await Slot.findById(slot._id);
    console.log(`   ✓ Slot currentBookings: ${refreshedSlot.currentBookings} / ${refreshedSlot.maxBookings}`);
    if (refreshedSlot.currentBookings !== 1) {
      throw new Error(`Expected slot bookings to be 1, got ${refreshedSlot.currentBookings}`);
    }

    // 6. Test Anti-Duplicate Reservation Protection
    console.log('\n6️⃣  [TEST]: Testing Anti-Duplicate Fair-Share Check');
    let duplicateBlocked = false;
    try {
      await bookingService.createBooking({ user, bookingData });
    } catch (err) {
      duplicateBlocked = true;
      console.log(`   ✓ Duplicate attempt successfully blocked: "${err.message}"`);
    }

    if (!duplicateBlocked) {
      throw new Error('Anti-duplicate check failed! Allowed duplicate booking for same crop on same date.');
    }

    // 7. Test Public Booking Tracking
    console.log('\n7️⃣  [TEST]: Testing Public Tracking Lookup');
    const trackedBooking = await Booking.findOne({ bookingId: booking.bookingId });
    if (!trackedBooking) throw new Error('Could not find created booking for tracking!');
    console.log(`   ✓ Track verified for booking ${trackedBooking.bookingId} - Token: ${trackedBooking.token.displayToken}`);

    // 8. Test Cancellation & Atomic Capacity Rollback
    console.log('\n8️⃣  [TEST]: Testing Booking Cancellation & Slot Quota Rollback');
    const cancelledBooking = await bookingService.cancelBooking(
      booking.bookingId,
      user,
      'Heavy rain, unable to transport produce'
    );
    console.log(`   ✓ Booking Status after cancellation: ${cancelledBooking.status}`);
    console.log(`   ✓ Cancellation Reason: "${cancelledBooking.cancellationReason}"`);

    const slotAfterCancel = await Slot.findById(slot._id);
    console.log(`   ✓ Slot capacity after cancellation rollback: ${slotAfterCancel.currentBookings} / ${slotAfterCancel.maxBookings}`);
    if (slotAfterCancel.currentBookings !== 0) {
      throw new Error(`Expected slot bookings to rollback to 0, got ${slotAfterCancel.currentBookings}`);
    }

    // 9. Clean up
    console.log('\n9️⃣  [TEST]: Cleaning Up Test Fixtures');
    await Booking.deleteMany({ bookingId: /^BK-BKTEST/ });
    await Slot.deleteMany({ centerCode: 'BK-TEST-01' });
    await Center.deleteMany({ centerId: 'BK-TEST-01' });
    await Farmer.deleteMany({ mobileNumber: '9998887776' });
    await User.deleteMany({ phone: '9998887776' });
    console.log('   ✓ Test database cleaned.');

    console.log('\n🎉 ALL BOOKING SERVICE & API WORKFLOW TESTS PASSED 100%!\n');
    await disconnectDB();
    process.exit(0);
  } catch (err) {
    console.error('❌ Booking API diagnostic error:', err);
    await disconnectDB();
    process.exit(1);
  }
}

testBookingApi();
