/**
 * KisanSetu - Real-Time Socket.IO Server & Event Dispatcher
 * Manages WebSocket rooms for Mandi Centers, Farmers, and District Officers.
 */

const { Server } = require('socket.io');

let io = null;

/**
 * Initialize Socket.IO with HTTP server
 */
function initSocket(httpServer) {
  io = new Server(httpServer, {
    cors: {
      origin: '*',
      methods: ['GET', 'POST']
    }
  });

  io.on('connection', (socket) => {
    // Join Center-specific room (for gate marshals, yard displays, queue watchers)
    socket.on('join:center', (centerId) => {
      if (centerId) {
        socket.join(`center:${centerId}`);
        console.log(`🔌 Client ${socket.id} joined room: center:${centerId}`);
      }
    });

    // Join Farmer-specific personal room (for personal token updates & alerts)
    socket.on('join:farmer', (farmerId) => {
      if (farmerId) {
        socket.join(`farmer:${farmerId}`);
        console.log(`🔌 Farmer client ${socket.id} joined room: farmer:${farmerId}`);
      }
    });

    // Join District-wide command room (for real-time heatmap & congestion alerts)
    socket.on('join:district', (districtName) => {
      if (districtName) {
        socket.join(`district:${districtName.toLowerCase()}`);
        console.log(`🔌 District Officer ${socket.id} joined room: district:${districtName}`);
      }
    });

    socket.on('disconnect', () => {
      // Clean disconnect
    });
  });

  return io;
}

/**
 * Access the global Socket.IO instance
 */
function getIO() {
  if (!io) {
    // Return mock fallback if called before server starts
    return {
      to: () => ({ emit: () => {} }),
      emit: () => {}
    };
  }
  return io;
}

/**
 * Broadcast live queue update to everyone watching the Mandi Center
 */
function emitQueueUpdate(centerId, queueData) {
  if (io) {
    io.to(`center:${centerId}`).emit('queue:updated', queueData);
  }
}

/**
 * Broadcast when a token is called to a bay (for audio chime & electronic display)
 */
function emitTokenCalled(centerId, tokenData) {
  if (io) {
    io.to(`center:${centerId}`).emit('token:called', tokenData);
  }
}

/**
 * Send targeted update to a specific farmer
 */
function emitFarmerNotification(farmerId, payload) {
  if (io) {
    io.to(`farmer:${farmerId}`).emit('notification', payload);
  }
}

/**
 * Broadcast district telemetrics update
 */
function emitDistrictAlert(districtName, alertData) {
  if (io) {
    io.to(`district:${districtName.toLowerCase()}`).emit('district:alert', alertData);
  }
}

module.exports = {
  initSocket,
  getIO,
  emitQueueUpdate,
  emitTokenCalled,
  emitFarmerNotification,
  emitDistrictAlert
};
