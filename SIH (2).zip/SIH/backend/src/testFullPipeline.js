/**
 * KisanSetu - Master End-to-End Pipeline Diagnostic
 * Runs the entire 13-stage agricultural lifecycle from booking to bank payout.
 * Run: node src/testFullPipeline.js
 */

const { connectDB, disconnectDB } = require('./config/db');
const User = require('./models/User');
const Farmer = require('./models/Farmer');
const Center = require('./models/Center');
const Slot = require('./models/Slot');
const Booking = require('./models/Booking');
const Weighment = require('./models/Weighment');
const QualityCheck = require('./models/QualityCheck');
const { Bill } = require('./models/Bill');
const Payment = require('./models/Payment');
const bookingService = require('./services/bookingService');
const { calculateBookingEta } = require('./services/etaService');
const queueService = require('./services/queueService');

async function testFullPipeline() {
  console.log('🌾 ====================================================================');
  console.log('🌾 [KisanSetu - Master 13-Stage End-to-End Pipeline Verification]');
  console.log('🌾 ====================================================================\n');

  try {
    await connectDB();

    // 0. Clean temporary test data
    await Promise.all([
      Booking.deleteMany({ bookingId: /^BK-E2E/ }),
      Slot.deleteMany({ centerCode: 'E2E-MANDI' }),
      Center.deleteMany({ centerId: 'E2E-MANDI' }),
      Farmer.deleteMany({ mobileNumber: '9111222333' }),
      User.deleteMany({ phone: '9111222333' })
    ]);

    // 1. Setup Actor: Farmer
    console.log('1️⃣  [STAGE 1]: Creating Farmer & Procurement Mandi Hub...');
    const user = await User.create({
      name: 'Balram Yadav',
      phone: '9111222333',
      role: 'FARMER',
      isPhoneVerified: true
    });

    const farmer = await Farmer.create({
      userId: user._id,
      farmerId: 'KS-E2E-001',
      name: user.name,
      mobileNumber: user.phone,
      language: 'hi',
      residence: {
        state: 'Madhya Pradesh',
        district: 'Indore',
        tehsil: 'Depalpur',
        village: 'Betma'
      },
      bankDetails: {
        accountHolderName: 'Balram Yadav',
        bankName: 'State Bank of India',
        accountNumberMasked: 'XXXXXX1089',
        ifscCode: 'SBIN0000451',
        aadhaarLinked: true
      }
    });

    // Setup Mandi Center & Slot
    const center = await Center.create({
      centerId: 'E2E-MANDI',
      name: 'Indore Super APMC Terminal Yard',
      district: 'Indore',
      state: 'Madhya Pradesh',
      zone: 'Central',
      address: 'Indore Ring Road Hub',
      dailyCapacity: 300,
      storageCapacity: 50000,
      storageUsed: 21000,
      acceptedCrops: ['Wheat', 'Soybean', 'Chana']
    });

    const today = new Date().toISOString().split('T')[0];
    const slot = await Slot.create({
      centerId: center._id,
      centerCode: center.centerId,
      date: today,
      startTime: '10:00 AM',
      endTime: '11:00 AM',
      maxBookings: 20,
      currentBookings: 0
    });
    console.log(`   ✓ Mandi & Slot initialized: ${center.name} (${slot.startTime})`);

    // 2. Stage: BOOKED
    console.log('\n2️⃣  [STAGE 2]: Farmer Books Slot (Status: BOOKED)...');
    const booking = await bookingService.createBooking({
      user,
      bookingData: {
        centerId: center._id.toString(),
        slotId: slot._id.toString(),
        crop: 'Wheat',
        expectedQuantityQtl: 60,
        vehicle: {
          vehicleType: 'TRACTOR_TROLLEY',
          vehicleNumber: 'MP-09-CD-7788'
        }
      }
    });
    console.log(`   ✓ Booking Created: ${booking.bookingId}`);
    console.log(`   ✓ Token: ${booking.token.displayToken} | Lane: ${booking.vehicle.assignedLane}`);
    console.log(`   ✓ Status: ${booking.status}`);

    // 3. Stage: CHECKED_IN
    console.log('\n3️⃣  [STAGE 3]: Tractor Arrives at Mandi Gate (Status: CHECKED_IN)...');
    booking.transitionStatus('CHECKED_IN', user._id, 'Gate 1 QR scan confirmed');
    await booking.save();
    console.log(`   ✓ Status: ${booking.status} | Check-in Time: ${booking.checkInTime.toISOString()}`);

    // 4. Live ETA & Queue Verification
    console.log('\n4️⃣  [STAGE 4]: Calculating Live Yard ETA...');
    const eta = await calculateBookingEta(booking.bookingId);
    console.log(`   ✓ Live ETA: ${eta.etaMinutes} mins | ${eta.statusMessage}`);

    // 5. Stage: CALLED
    console.log('\n5️⃣  [STAGE 5]: Yard Marshal Calls Vehicle to Weighbridge (Status: CALLED)...');
    booking.transitionStatus('CALLED', user._id, 'Proceed to Weighbridge BAY-01');
    booking.vehicle.assignedBay = 'BAY-01';
    await booking.save();
    console.log(`   ✓ Status: ${booking.status} | Target Bay: ${booking.vehicle.assignedBay}`);

    // 6. Stage: WEIGHING (Gross & Tare)
    console.log('\n6️⃣  [STAGE 6]: Recording Weighbridge Scale (Status: WEIGHING)...');
    const weighment = await Weighment.create({
      weighmentSlipId: `WT-${Date.now().toString().slice(-6)}`,
      bookingId: booking._id,
      bookingCode: booking.bookingId,
      token: booking.token.displayToken,
      farmerId: farmer._id,
      farmerName: farmer.name,
      centerId: center._id,
      vehicleNumber: booking.vehicle.vehicleNumber,
      grossWeightKg: 8500, // 8.5 MT
      tareWeightKg: 2500,  // 2.5 MT
      weighbridgeLane: 'WEIGHBRIDGE-01'
    });
    booking.weighmentId = weighment._id;
    booking.transitionStatus('WEIGHING', user._id, `Net Produce: ${weighment.netWeightQtl} Qtl (${weighment.netWeightKg} KG)`);
    await booking.save();
    console.log(`   ✓ Gross: ${weighment.grossWeightKg} KG | Tare: ${weighment.tareWeightKg} KG`);
    console.log(`   ✓ Verified Net Weight: ${weighment.netWeightQtl} Quintals`);

    // 7. Stage: QUALITY_CHECK & APPROVED
    console.log('\n7️⃣  [STAGE 7]: Laboratory Moisture & FAQ Grain Assay (Status: APPROVED)...');
    const quality = await QualityCheck.create({
      qcCertificateId: `QC-${Date.now().toString().slice(-6)}`,
      bookingId: booking._id,
      bookingCode: booking.bookingId,
      token: booking.token.displayToken,
      farmerId: farmer._id,
      centerId: center._id,
      crop: 'Wheat',
      sampleId: 'SMP-TEST-99',
      moisturePct: 11.2, // Below 12% limit -> Grade A Premium
      assayerId: user._id
    });
    booking.qualityCheckId = quality._id;
    booking.transitionStatus('APPROVED', user._id, `Quality Passed: ${quality.grade} (Moisture ${quality.moisturePct}%)`);
    await booking.save();
    console.log(`   ✓ Moisture: ${quality.moisturePct}% | Grade: ${quality.grade} | Status: ${quality.status}`);

    // 8. Stage: BILL_GENERATED
    console.log('\n8️⃣  [STAGE 8]: Generating Official MSP Purchase Invoice (Status: BILL_GENERATED)...');
    const billCalc = Bill.calculateBill({
      crop: 'Wheat',
      netQuantityQtl: weighment.netWeightQtl,
      qualityDeductionPct: quality.deductionPct
    });

    const bill = await Bill.create({
      billNumber: `BILL-${Date.now().toString().slice(-6)}`,
      bookingId: booking._id,
      bookingCode: booking.bookingId,
      token: booking.token.displayToken,
      farmerId: farmer._id,
      farmerName: farmer.name,
      farmerPhone: farmer.mobileNumber,
      centerId: center._id,
      crop: 'Wheat',
      netQuantityQtl: weighment.netWeightQtl,
      mspRatePerQtl: billCalc.mspRatePerQtl,
      grossAmount: billCalc.grossAmount,
      qualityDeductionPct: 0,
      qualityDeductionAmount: 0,
      netPayableAmount: billCalc.netPayableAmount,
      status: 'PAYMENT_PENDING'
    });
    booking.billId = bill._id;
    booking.transitionStatus('BILL_GENERATED', user._id, `MSP Bill: ₹${bill.netPayableAmount}`);
    await booking.save();
    console.log(`   ✓ Rate: ₹${bill.mspRatePerQtl}/Qtl | Net Payable: ₹${bill.netPayableAmount}`);

    // 9. Stage: PAYMENT_PROCESSING & COMPLETED (DBT Direct Benefit Transfer)
    console.log('\n9️⃣  [STAGE 9]: Direct Benefit Transfer (DBT) to Bank Account (Status: COMPLETED)...');
    const payment = await Payment.create({
      dbtReferenceId: `DBT-${Date.now().toString().slice(-8)}`,
      billId: bill._id,
      bookingId: booking._id,
      farmerId: farmer._id,
      amount: bill.netPayableAmount,
      beneficiary: farmer.bankDetails,
      status: 'BANK_CREDITED',
      utrNumber: 'UTR2026E2E99001144',
      creditedAt: new Date()
    });
    booking.paymentId = payment._id;
    booking.transitionStatus('COMPLETED', user._id, `DBT Funds Credited via PFMS! UTR: ${payment.utrNumber}`);
    await booking.save();
    console.log(`   ✓ Beneficiary Bank: ${payment.beneficiary.bankName} (${payment.beneficiary.accountNumberMasked})`);
    console.log(`   ✓ Bank UTR: ${payment.utrNumber}`);
    console.log(`   ✓ Final Booking Status: ${booking.status}`);

    // 10. Audit History Verification
    console.log('\n🔟 [STAGE 10]: Auditing Complete 13-Stage State Machine Log...');
    const auditRecord = await Booking.findById(booking._id);
    console.log(`   ✓ Total Audit Trail Steps: ${auditRecord.statusHistory.length}`);
    auditRecord.statusHistory.forEach((h, i) => {
      console.log(`     [${i + 1}] -> ${h.status.padEnd(16)} | ${h.remarks}`);
    });

    // Cleanup test fixtures
    await Promise.all([
      Booking.deleteMany({ bookingId: /^BK-E2E/ }),
      Slot.deleteMany({ centerCode: 'E2E-MANDI' }),
      Center.deleteMany({ centerId: 'E2E-MANDI' }),
      Farmer.deleteMany({ mobileNumber: '9111222333' }),
      User.deleteMany({ phone: '9111222333' })
    ]);

    console.log('\n🌾 ====================================================================');
    console.log('🎉 [SUCCESS]: FULL 13-STAGE KISANSETU BACKEND ENGINE 100% OPERATIONAL!');
    console.log('🌾 ====================================================================\n');

    await disconnectDB();
    process.exit(0);
  } catch (err) {
    console.error('❌ E2E Pipeline failure:', err);
    await disconnectDB();
    process.exit(1);
  }
}

testFullPipeline();
