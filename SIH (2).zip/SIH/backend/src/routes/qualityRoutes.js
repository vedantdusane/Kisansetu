/**
 * KisanSetu - Quality Testing Routes
 * Endpoints for recording laboratory assays and retrieving inspection certificates.
 */

const express = require('express');
const qualityController = require('../controllers/qualityController');
const { requireAuth } = require('../middleware/auth');
const { requireRole } = require('../middleware/role');

const router = express.Router();

router.use(requireAuth);

// Record Quality Assay (Officials & Certified Assayers)
router.post('/assay', requireRole('MANDI_OFFICER', 'ADMIN'), qualityController.recordQualityAssay);

// Retrieve Inspection Certificate (Farmers and Officials)
router.get('/:bookingId', qualityController.getQualityCertificate);

module.exports = router;
