/**
 * KisanSetu - DBT Payment Routes
 * Endpoints for initiating and tracking government bank disbursements.
 */

const express = require('express');
const paymentController = require('../controllers/paymentController');
const { requireAuth } = require('../middleware/auth');
const { requireRole } = require('../middleware/role');

const router = express.Router();

router.use(requireAuth);

// Initiate DBT Payment (District / Mandi Accounts Officers & Admins)
router.post('/initiate', requireRole('DISTRICT_OFFICER', 'MANDI_OFFICER', 'ADMIN'), paymentController.initiatePayment);

// Simulate Bank Settlement Confirmation (Simulates PFMS webhook / RBI clearing)
router.post('/simulate-credit', requireRole('DISTRICT_OFFICER', 'MANDI_OFFICER', 'ADMIN'), paymentController.simulateCredit);

// View Payment status by Bill ID
router.get('/bill/:billId', paymentController.getPaymentByBill);

module.exports = router;
