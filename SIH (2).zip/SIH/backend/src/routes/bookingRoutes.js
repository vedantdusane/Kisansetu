/**
 * KisanSetu - Booking Routes
 * Endpoints for creating, listing, cancelling, and tracking procurement appointments.
 */

const express = require('express');
const Joi = require('joi');
const bookingController = require('../controllers/bookingController');
const { requireAuth } = require('../middleware/auth');
const validate = require('../middleware/validate');

const router = express.Router();

// Joi Validation Schemas
const createBookingSchema = Joi.object({
  centerId: Joi.string().required().messages({
    'any.required': 'Procurement center ID is required'
  }),
  slotId: Joi.string().required().messages({
    'any.required': 'Appointment slot ID is required'
  }),
  crop: Joi.string().trim().required().messages({
    'any.required': 'Crop type is required'
  }),
  expectedQuantityQtl: Joi.number().min(1).max(1000).required().messages({
    'number.min': 'Expected quantity must be at least 1 Quintal',
    'number.max': 'Expected quantity cannot exceed 1000 Quintals per appointment',
    'any.required': 'Expected quantity in quintals is required'
  }),
  vehicle: Joi.object({
    vehicleType: Joi.string()
      .valid('TRACTOR_TROLLEY', 'PICKUP', 'MINI_TRUCK', 'SIX_WHEELER', 'BULLOCK_CART', 'OTHER')
      .default('TRACTOR_TROLLEY'),
    vehicleNumber: Joi.string().trim().uppercase().default('MP-09-AB-1234')
  }).default({
    vehicleType: 'TRACTOR_TROLLEY',
    vehicleNumber: 'MP-09-AB-1234'
  }),
  farmerId: Joi.string().optional() // For CSC / Official booking on behalf of farmer
});

const cancelBookingSchema = Joi.object({
  reason: Joi.string().trim().max(250).default('Cancelled by farmer')
});

// 1. Public Kiosk / SMS / IVR Tracking (No Login Required)
router.get('/track/:identifier', bookingController.trackBooking);

// 2. Authenticated Endpoints
router.use(requireAuth);

router.post('/', validate(createBookingSchema), bookingController.createBooking);
router.get('/', bookingController.getBookings);
router.get('/:id', bookingController.getBookingById);
router.patch('/:id/cancel', validate(cancelBookingSchema), bookingController.cancelBooking);

module.exports = router;
