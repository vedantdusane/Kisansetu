/**
 * KisanSetu - Gate Check-In Routes
 * Secured endpoints for Mandi Gate Operators and Officers to verify and intake vehicles.
 */

const express = require('express');
const checkinController = require('../controllers/checkinController');
const { requireAuth } = require('../middleware/auth');
const { requireRole } = require('../middleware/role');

const router = express.Router();

// Require official authentication for check-in actions
router.use(requireAuth);
router.use(requireRole('MANDI_OFFICER', 'GATE_OPERATOR', 'ADMIN'));

// QR Scan Gate Check-In
router.post('/scan', checkinController.scanAndCheckIn);

// Daily gate throughput metrics
router.get('/today-stats', checkinController.getTodayGateStats);

module.exports = router;
