/**
 * KisanSetu - Procurement Center Routes
 * Mounts: /api/centers
 */

const express = require('express');
const router = express.Router();
const Joi = require('joi');
const centerController = require('../controllers/centerController');
const { requireAuth } = require('../middleware/auth');
const { requireRole } = require('../middleware/role');
const validate = require('../middleware/validate');

const createCenterSchema = Joi.object({
  centerId: Joi.string().trim().uppercase().required(),
  name: Joi.string().trim().required(),
  district: Joi.string().trim().required(),
  state: Joi.string().trim().required(),
  zone: Joi.string().valid('North', 'West', 'Central', 'South', 'East').default('Central'),
  address: Joi.string().trim().required(),
  operatingHours: Joi.object({
    openTime: Joi.string().default('08:00 AM'),
    closeTime: Joi.string().default('06:00 PM')
  }).optional(),
  dailyCapacity: Joi.number().min(10).default(250),
  acceptedCrops: Joi.array().items(Joi.string()).default(['Wheat', 'Soybean', 'Chana']),
  storageCapacity: Joi.number().min(100).default(25000),
  storageUsed: Joi.number().min(0).default(0),
  numberOfLanes: Joi.number().min(1).default(4),
  parkingBays: Joi.object({
    total: Joi.number().default(50),
    occupied: Joi.number().default(0)
  }).optional()
});

// Public / Authenticated Read Endpoints
router.get('/', centerController.getCenters);
router.get('/:id', centerController.getCenterById);

// Protected Write Endpoints
router.post(
  '/',
  requireAuth,
  requireRole('ADMIN', 'DISTRICT_OFFICER'),
  validate(createCenterSchema),
  centerController.createCenter
);

router.put(
  '/:id',
  requireAuth,
  requireRole('ADMIN', 'DISTRICT_OFFICER', 'CENTER_OFFICIAL'),
  centerController.updateCenter
);

module.exports = router;
