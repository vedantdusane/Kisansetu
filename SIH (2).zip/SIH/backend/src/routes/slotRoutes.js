/**
 * KisanSetu - Slot Management REST Routes
 * Mounts: /api/slots
 */

const express = require('express');
const router = express.Router();
const Joi = require('joi');
const slotController = require('../controllers/slotController');
const { requireAuth } = require('../middleware/auth');
const { requireRole } = require('../middleware/role');
const validate = require('../middleware/validate');

const createSlotSchema = Joi.object({
  centerId: Joi.string().hex().length(24).required(),
  date: Joi.string().pattern(/^\d{4}-\d{2}-\d{2}$/).required().messages({
    'string.pattern.base': 'Date must follow YYYY-MM-DD format (e.g. 2026-09-15)'
  }),
  startTime: Joi.string().required(),
  endTime: Joi.string().required(),
  maxBookings: Joi.number().min(1).default(30)
});

const generateDaySchema = Joi.object({
  centerId: Joi.string().hex().length(24).required(),
  date: Joi.string().pattern(/^\d{4}-\d{2}-\d{2}$/).required(),
  capacityPerSlot: Joi.number().min(1).default(30)
});

// Read Endpoints (Farmers & Public)
router.get('/', slotController.getSlots);

// Write Endpoints (Officials & Admins)
router.post(
  '/',
  requireAuth,
  requireRole('ADMIN', 'CENTER_OFFICIAL'),
  validate(createSlotSchema),
  slotController.createSlot
);

router.post(
  '/generate-day',
  requireAuth,
  requireRole('ADMIN', 'CENTER_OFFICIAL'),
  validate(generateDaySchema),
  slotController.generateDailySlots
);

router.put(
  '/:id',
  requireAuth,
  requireRole('ADMIN', 'CENTER_OFFICIAL'),
  slotController.updateSlot
);

module.exports = router;
