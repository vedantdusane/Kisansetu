/**
 * KisanSetu - Authentication REST Routes
 * Mounts: /api/auth
 */

const express = require('express');
const router = express.Router();
const Joi = require('joi');
const authController = require('../controllers/authController');
const validate = require('../middleware/validate');

// --- Joi Validation Schemas ---
const sendOtpSchema = Joi.object({
  phone: Joi.string()
    .pattern(/^[6-9]\d{9}$/)
    .required()
    .messages({
      'string.pattern.base': 'Phone number must be a valid 10-digit Indian mobile number',
      'any.required': 'Phone number is required'
    })
});

const verifyOtpSchema = Joi.object({
  phone: Joi.string()
    .pattern(/^[6-9]\d{9}$/)
    .required()
    .messages({
      'string.pattern.base': 'Phone number must be a valid 10-digit Indian mobile number',
      'any.required': 'Phone number is required'
    }),
  otp: Joi.string()
    .min(4)
    .max(6)
    .required()
    .messages({
      'any.required': 'OTP code is required'
    }),
  name: Joi.string().trim().max(100).optional(),
  preferredLanguage: Joi.string().valid('en', 'hi', 'mr', 'pa', 'gu', 'bn', 'ta').optional()
});

const loginSchema = Joi.object({
  identifier: Joi.string().trim().required().messages({
    'any.required': 'Email or phone number is required'
  }),
  password: Joi.string().required().messages({
    'any.required': 'Password is required'
  }),
  role: Joi.string().valid('FARMER', 'CENTER_OFFICIAL', 'DISTRICT_OFFICER', 'ADMIN').optional()
});

const registerSchema = Joi.object({
  name: Joi.string().trim().min(2).max(100).required(),
  role: Joi.string().valid('FARMER', 'CENTER_OFFICIAL', 'DISTRICT_OFFICER', 'ADMIN').default('FARMER'),
  phone: Joi.string().pattern(/^[6-9]\d{9}$/).optional(),
  email: Joi.string().email().optional(),
  password: Joi.string().min(6).required(),
  assignedCenter: Joi.string().hex().length(24).optional(),
  assignedDistrict: Joi.string().trim().optional(),
  preferredLanguage: Joi.string().valid('en', 'hi', 'mr', 'pa', 'gu', 'bn', 'ta').default('hi')
});

// --- Routes Definition ---
router.post('/send-otp', validate(sendOtpSchema), authController.sendOtp);
router.post('/verify-otp', validate(verifyOtpSchema), authController.verifyOtp);
router.post('/login', validate(loginSchema), authController.login);
router.post('/register', validate(registerSchema), authController.register);

module.exports = router;
