/**
 * KisanSetu - District Telemetrics & Heatmap Routes
 * Endpoints for state & district level macro-analytics and congestion alerts.
 */

const express = require('express');
const districtController = require('../controllers/districtController');
const { requireAuth } = require('../middleware/auth');
const { requireRole } = require('../middleware/role');

const router = express.Router();

// Heatmap can be publicly accessible for farmers & drivers planning their trips
router.get('/heatmap', districtController.getMandiHeatmap);

// Administrative Telemetrics & Alerts (Secured)
router.get('/overview', requireAuth, requireRole('DISTRICT_OFFICER', 'ADMIN'), districtController.getDistrictOverview);
router.get('/alerts', requireAuth, requireRole('DISTRICT_OFFICER', 'ADMIN'), districtController.getCongestionAlerts);

module.exports = router;
