/**
 * KisanSetu - Queue & ETA Routes
 * Public queue view for electronic yard displays and secured officer dispatching.
 */

const express = require('express');
const queueController = require('../controllers/queueController');
const { requireAuth } = require('../middleware/auth');
const { requireRole } = require('../middleware/role');

const router = express.Router();

// 1. Public Displays & Farmer ETA (Read-Only)
router.get('/:centerId', queueController.getLiveQueue);
router.get('/eta/:bookingId', queueController.getBookingEta);

// 2. Secured Dispatch Actions (Yard Marshals, Mandi Officers, Admins)
router.post('/call-next', requireAuth, requireRole('MANDI_OFFICER', 'GATE_OPERATOR', 'ADMIN'), queueController.callNext);
router.post('/advance', requireAuth, requireRole('MANDI_OFFICER', 'GATE_OPERATOR', 'ADMIN'), queueController.advanceStage);

module.exports = router;
