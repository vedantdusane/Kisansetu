/**
 * KisanSetu - Farmer Protected Routes
 * Mounts: /api/farmers
 * Protected by requireAuth & requireRole('FARMER')
 */

const express = require('express');
const router = express.Router();
const farmerController = require('../controllers/farmerController');
const { requireAuth } = require('../middleware/auth');
const { requireRole } = require('../middleware/role');

// Apply authentication to all farmer routes
router.use(requireAuth);

// Farmer Profile Endpoints
router.get('/profile', requireRole('FARMER'), farmerController.getProfile);
router.put('/profile', requireRole('FARMER'), farmerController.updateProfile);

module.exports = router;
