/**
 * KisanSetu - MSP Billing Routes
 * Endpoints for invoice generation and settlement tracking.
 */

const express = require('express');
const billController = require('../controllers/billController');
const { requireAuth } = require('../middleware/auth');
const { requireRole } = require('../middleware/role');

const router = express.Router();

router.use(requireAuth);

// Generate Bill (Mandi Officers & Admins)
router.post('/generate', requireRole('MANDI_OFFICER', 'ADMIN'), billController.generateBill);

// View Bill by Booking (Farmers and Officials)
router.get('/:bookingId', billController.getBill);

module.exports = router;
