/**
 * KisanSetu - Weighment Routes
 * Endpoints for recording weighbridge weight receipts and viewing weighment slips.
 */

const express = require('express');
const weighmentController = require('../controllers/weighmentController');
const { requireAuth } = require('../middleware/auth');
const { requireRole } = require('../middleware/role');

const router = express.Router();

router.use(requireAuth);

// Record Gross and Tare weights (Officials & Weighbridge Operators)
router.post('/gross', requireRole('MANDI_OFFICER', 'GATE_OPERATOR', 'ADMIN'), weighmentController.recordGrossWeight);
router.post('/tare', requireRole('MANDI_OFFICER', 'GATE_OPERATOR', 'ADMIN'), weighmentController.recordTareWeight);

// View weighment receipt (Farmers and Officials)
router.get('/:bookingId', weighmentController.getWeighmentSlip);

module.exports = router;
