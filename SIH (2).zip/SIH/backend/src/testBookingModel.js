/**
 * KisanSetu - Booking Model Diagnostic Test
 * Run: node src/testBookingModel.js
 */

const { connectDB, disconnectDB } = require('./config/db');
const Booking = require('./models/Booking');
const mongoose = require('mongoose');

async function testBookingModel() {
  console.log('⏳ Running Booking Model & State Machine Tests...\n');

  try {
    await connectDB();

    const dummyCenterId = new mongoose.Types.ObjectId();
    const dummyFarmerId = new mongoose.Types.ObjectId();
    const dummySlotId = new mongoose.Types.ObjectId();

    // 1. Create Booking Instance
    console.log('1️⃣  [TEST]: Creating Procurement Booking with State Machine');
    const booking = new Booking({
      bookingId: 'BK-MPIND001-20260915-A023',
      farmerId: dummyFarmerId,
      farmerName: 'Ramesh Patel',
      farmerPhone: '9876543210',
      centerId: dummyCenterId,
      centerCode: 'MP-IND-001',
      centerName: 'Indore Laxmibai Nagar APMC',
      slotId: dummySlotId,
      crop: 'Wheat',
      expectedQuantityQtl: 50,
      date: '2026-09-15',
      timeSlot: '10:00 AM - 11:00 AM',
      token: {
        displayToken: 'A023',
        sequenceNumber: 23,
        fullTokenReference: 'MP-IND-001-2026-09-15-A023'
      },
      qrCode: {
        qrPayload: 'KISANSETU:MP-IND-001:20260915:A023:SECUREHASH8821'
      },
      status: 'BOOKED'
    });

    await booking.validate();
    console.log(`   ✓ Booking Schema Validated! ID: ${booking.bookingId}`);
    console.log(`   ✓ Initial Status: ${booking.status}`);
    console.log(`   ✓ Token Assigned: ${booking.token.displayToken} (#${booking.token.sequenceNumber})`);

    // 2. Test State Machine Transition to CHECKED_IN
    console.log('\n2️⃣  [TEST]: Testing State Transition Method (BOOKED -> CHECKED_IN)');
    booking.transitionStatus('CHECKED_IN', null, 'Gate QR scan verified by Security Officer');
    console.log(`   ✓ New Status: ${booking.status}`);
    console.log(`   ✓ Check-In Timestamp Recorded: ${booking.checkInTime.toISOString()}`);
    console.log(`   ✓ Audit History Entries: ${booking.statusHistory.length}`);
    console.log(`   ✓ Audit Note: "${booking.statusHistory[0].remarks}"`);

    // 3. Test Invalid Status Rejection
    console.log('\n3️⃣  [TEST]: Testing Invalid Status Rejection');
    let errorCaught = false;
    try {
      booking.status = 'FLYING_AIRPLANE'; // Invalid enum value
      await booking.validate();
    } catch (err) {
      errorCaught = true;
      console.log(`   ✓ Invalid status correctly blocked: "${err.errors.status.message}"`);
    }

    if (!errorCaught) {
      throw new Error('Invalid status was not blocked by Mongoose enum!');
    }

    console.log('\n🎉 BOOKING MODEL & STATE MACHINE VALIDATED WITH 100% SUCCESS!\n');
    await disconnectDB();
    process.exit(0);
  } catch (err) {
    console.error('❌ Booking test error:', err);
    await disconnectDB();
    process.exit(1);
  }
}

testBookingModel();
