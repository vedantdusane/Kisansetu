/**
 * KisanSetu - Standard API Response Wrapper
 * Ensures 100% predictable payload structure for all REST endpoints:
 * Success: { success: true, message, data }
 * Error:   { success: false, message, errors }
 */

const successResponse = (res, statusCode = 200, message = 'Operation successful', data = null) => {
  const payload = {
    success: true,
    message
  };

  if (data !== null) {
    payload.data = data;
  }

  return res.status(statusCode).json(payload);
};

const errorResponse = (res, statusCode = 500, message = 'An unexpected error occurred', errors = null) => {
  const payload = {
    success: false,
    message
  };

  if (errors !== null) {
    payload.errors = errors;
  }

  return res.status(statusCode).json(payload);
};

module.exports = {
  successResponse,
  errorResponse
};
